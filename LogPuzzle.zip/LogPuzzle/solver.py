__author__ = 'Ittay Levit'
import re
from urllib.request import urlretrieve

spl_path = r'splendorous-yeot-444d7e.netlify.app.log'
ast_path = r'astonishing-dusk-071a64.netlify.app.log'
new_html_page = r'image1.html'


def get_url_set_ex1(log_txt):
    reg = r'"GET \/cyberbit\/.*. HTTP\/1.0" [0-9]*'
    log_list = re.findall(reg, log_txt)
    tog = ''.join(log_list)
    tog_list = tog.split('cyberbit')
    tog_list = tog_list[1:]
    for t in range(len(tog_list)):
        tog_list[t] = tog_list[t].split(' ')[0][1:]
    url_set = set(tog_list)
    url_set = sorted(url_set)
    return url_set


def get_url_set_ex2(log_txt):
    reg = r'"GET \/cyberbit\/.*. HTTP\/1.0" [0-9]*'
    log_list = re.findall(reg, log_txt)
    tog = ''.join(log_list)
    tog_list = tog.split('cyberbit')
    tog_list = tog_list[1:]
    for t in range(len(tog_list)):
        tog_list[t] = tog_list[t].split(' ')[0][1:]
    url_set = set(tog_list)
    url_set = sorted(url_set, key=return_key_to_sorted_ex2)
    print(url_set)
    return url_set


def return_key_to_sorted_ex2(url):
    return url.split('-')[1]


def create_write_page(url_set, num_of_ex):
    if num_of_ex == 1:
        new_page = new_html_page[:5] + '1' + new_html_page[6:]
    else:
        new_page = new_html_page[:5] + '2' + new_html_page[6:]

    with open(new_page, 'w') as file:
        file.write('<html>\n<head>\n<title>Full Image</title>\n</head>\n<body>\n')
        for url in url_set:
            cur_url = ''
            if num_of_ex == 1:
                cur_url = spl_path
            else:
                cur_url = ast_path
            cur_url += url
            print(cur_url)
            urlretrieve(cur_url, url)
            new_url = '<img src="e:\\Networks\\LogPuzzle\\' + url + '"/>'
            file.write(new_url)
        file.write('</body>\n</html>')


def main():
    with open(spl_path, 'r') as file:
        log_txt = file.read()
    url_set = get_url_set_ex1(log_txt)
    create_write_page(url_set, 1)


if __name__ == '__main__':
    main()
