from scapy.all import *

dst_ip = '172.66.43.3'  # IP of web.mashov.info


def filter_exceeded_ttl(pck):
	return IP in pck and ICMP in pck and pck[ICMP].type == 11 or pck[ICMP].type == 0


def main():
	global dst_ip
	print('Starting tracert...')
	for cur_ttl in range(1, 0xFF):
		pck = IP(ttl=cur_ttl, dst=dst_ip)/ICMP()
		send(pck, verbose=False)
		pck = sniff(count=1, lfilter=filter_exceeded_ttl)
		pck = pck[len(pck)-1]
		ip = pck[IP].src
		print(ip)
		if ip == dst_ip:
			break
	print('Finished!')


if __name__ == '__main__':
	main()
