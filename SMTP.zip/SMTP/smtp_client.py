__author__ = 'Ittay_Levit'
import socket
import base64
# global vars
server_ip = '10.68.121.181'
smtp_port = 25
buffer_size = 64 * 1024
list_to_send = ['EHLO',
                'EHLO PC-LRXR',
                f'AUTH PLAIN {base64.b64encode(b'Ittay/special_password').decode()}',
                'MAIL FROM:<yonatansegal@gmx.com>',
                'RCPT TO:seagull@mail.com',
                'DATA',
                'Subject: I love yonatan segal\r\n\r\nHELLO\r\n.',
                'QUIT',
                '']


def client():
    global server_ip
    global smtp_port
    global buffer_size
    global list_to_send
    sck = socket.socket()
    sck.connect((server_ip, smtp_port))
    print('Connected to server')
    try:
        for i in list_to_send:
            i += '\r\n'
            # RECV
            data = get_recv(sck)
            # SEND
            print('C:' + i)
            sck.send(i.encode())
            # data = base64.b64decode(data)
    except Exception as err:
        print('Error!\r\n%s' % str(err))
    print('disconnected from server, goodbye!')


def get_recv(sck):
    global buffer_size
    data = sck.recv(buffer_size)
    data = data.decode()
    print('S:' + data)
    return data


def main():
    client()


if __name__ == '__main__':
    main()
