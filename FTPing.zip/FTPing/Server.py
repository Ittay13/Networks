from scapy.all import *
import os
import random

'''Main Program'''
file_path = os.getcwd() + r'\Server.jpg'


def filter_icmp(pck):
    return IP in pck and ICMP in pck and Raw in pck


def main():
    while True:
        pck = sniff(count=1, lfilter=filter_icmp)
        pck = pck[0]
        i = random.randint(1, 10)
        if i == 1:
            pass
        else:
            chunk = pck[Raw].load
            ip = pck[IP].src
            ip_pck = IP(dst=ip)
            icmp_pck = ICMP(type='echo-reply') / 'ack_server_Ittay'  # ack package
            new_pck = ip_pck / icmp_pck
            send(new_pck)
            with open(file_path, 'ab') as my_file:
                my_file.write(chunk)


if __name__ == '__main__':
    main()
