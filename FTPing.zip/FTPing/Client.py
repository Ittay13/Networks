from scapy.all import *
import os
import random


'''Main Program'''
file_path = os.getcwd() + r'\Client.jpg'
server_ip = '10.68.121.86'
ip_pck = IP(dst=server_ip)
buffer = 1000
timeout_sec = 0.1


def filter_icmp(pck):
	return ICMP in pck and Raw in pck


def main():
	global buffer
	global timeout_sec
	with open(file_path, 'rb') as my_file:
		file = my_file.read()  # file = bytes of file
	pointer = 0
	size = len(file)
	while pointer <= size:
		chunk = file[pointer:pointer+buffer]
		icmp_pck = ICMP(type='echo-request')/chunk
		pck = ip_pck/icmp_pck
		pck.summary()
		send(pck)
		ack_pck = sniff(count=1, lfilter=filter_icmp, timeout=timeout_sec)
		pointer += 1000
		try:
			if ack_pck[0][Raw].load == b'ack_server_Ittay':
				pass
			else:
				pointer -= 1000
		except Exception as err:
			pointer -= 1000
		print(pointer)


if __name__ == '__main__':
	main()
