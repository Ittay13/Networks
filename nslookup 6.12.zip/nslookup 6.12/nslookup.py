__author__ = 'Ittay_Levit'
from scapy.all import *

my_port = 5555
DNS_ip = '8.8.8.8'
DNS_port = 53


def main():
	print('Enter address to find IP of: ', end='')
	address_to_find = input()
	packet_to_send = IP(dst=DNS_ip)/UDP(sport=my_port,dport=DNS_port)/DNS(qdcount=1, qd=DNSQR(qname=address_to_find))
	DNSpacket = sr1(packet_to_send)
	answers = DNSpacket['DNS'].an
	found = False
	for i in answers:
		if i.type == 1:
			print('IP is: ' + i.rdata)
			found = True
			break
	if not found:
		print('IP was not found')


main()
