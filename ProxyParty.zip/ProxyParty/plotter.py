
import networkx as nx
import matplotlib.pyplot as plt
 
g = nx.Graph()
 
g.add_node("1.1.1.1")
g.add_node("192.168.2.2")
g.add_node("192.168.3.3")
g.add_node("4.4.4.4")

g.add_edge("1.1.1.1", "192.168.2.2")
g.add_edge("192.168.2.2", "4.4.4.4")
g.add_edge("192.168.3.3", "4.4.4.4")
g.add_edge("1.1.1.1", "4.4.4.4")

pos = nx.spring_layout(g)

nx.draw_networkx_nodes(g, pos, margins=0.1, linewidths=0, node_size=[600, 600, 300, 900], node_color=['r', 'b', 'b', 'r'])
nx.draw_networkx_labels(g, pos, font_weight="bold")
nx.draw_networkx_edges(g, pos)
nx.draw_networkx_edge_labels(g, pos, edge_labels={
    ("1.1.1.1", "192.168.2.2"): "80 <-> 27323",
    ("192.168.2.2", "4.4.4.4"): "35217 <-> 443",
    ("192.168.3.3", "4.4.4.4"): "23164 <-> 443",
    ("1.1.1.1", "4.4.4.4"): "52892<-> 443"})

plt.savefig("graph.png")