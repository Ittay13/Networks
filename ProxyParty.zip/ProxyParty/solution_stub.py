import os, sys, time, datetime, random

LOG_DIR = "generated_report\\"

class NetstatEntry:
    def __init__(self, source_ip, source_port, dest_ip, dest_port, state, process_id):
        self.souce_ip = source_ip
        self.source_port = source_port
        self.dest_ip = dest_ip
        self.dest_port = dest_port
        self.state = state
        self.process_id = process_id

    def __repr__(self):
        s = self.souce_ip + ", "
        s += self.source_port + ", "
        s += self.dest_ip + ", "
        s += self.dest_port + ", "
        s += self.state + ", "
        s += self.process_id + ", "
        return s


def get_connections(ip) -> list:
    """
    :param ip:
    :return list of NetstatEntry objects for each  established tcp connection:
    """
    fn = os.path.join(LOG_DIR, ip.replace('.', '_') + ".txt")
    if not os.path.isfile(fn):
        return None
    pass



def get_pid_by_port1(cons, port1) -> str:
    """
    :param cons: list
    :param port1: local port
    :return: pid that work with this local port
    """
    pass


def get_other_con(cons, pid, port1) -> NetstatEntry:
    """
    :param cons:
    :param pid:
    :param port1: local port
    :return: NetstatEntry
    return other connection. same pid but another ports and Foreign IP
    """
    pass


def get_other_ipport(cons, ip, port)-> (str, str):
    """
    :param cons:
    :param ip:
    :param port:
    :return: ip, port of next computer
    1. get pid using port
    2. find the second connection line in the same computer using same pid
    3. return the new ip port of the new connection
    4. if it is last computer (hackear ) return None, None
    """
    pass


def get_path(ip, port) -> str:
    """

       :param ip:
       :param port: from last computer:
       :return:
                 1. path = ''
                 2. while ip is valid
                     2.1 open file if exist using ip
                     2.2 path += ip + '(' + port + '),'  (concatenate string)
                     2.3 get next ip next port using current ip, port
                     2.4 ip = next ip , port = next_port
                 3. the return path
    """
    pass


def main(start_ip):
    path_by_port = {}
    cons = get_connections(start_ip)
    if cons:
        for con in cons:
            path_by_port[con.source_port] = get_path(con.dest_ip, con.dest_port)

    for k,v in path_by_port.items():
        print(k, len(v.split(", ")), "\t->", v)


if __name__ == "__main__":
    if len(sys.argv) >= 2:
        main(sys.argv[1])
    else:
        main("10.68.120.15")

