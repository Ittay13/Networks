def txt_file_to_list(txt):  # txt as readline. return list [my_ip, my_port, foreign_ip, foreign_port, PID]
    txt = txt[3:]
    for line_index in range(len(txt)):
        lines = txt[line_index].split()
        my_ip = lines[1].split(':')[0]
        my_port = lines[1].split(':')[1]
        foreign_ip = lines[2].split(':')[0]
        foreign_port = lines[2].split(':')[1]
        pid = lines[4]
        txt[line_index] = [my_ip, my_port, foreign_ip, foreign_port, pid]
    return txt


def ex_1():
    ''' TCP    10.68.117.244:25969    24.74.144.225:443      ESTABLISHED     2360'''
    my_ip = '10.68.118.194'
    my_port = '39498'
    foreign_ip = '10.68.120.15'
    foreign_port = '22206'
    pid = 0
    counter = 0
    path = 'E:\\Networks\\ProxyParty\\generated_report'
    try:
        cont = True
        while cont:
            # open file
            name = path + '\\' + '_'.join(my_ip.split('.')) + '.txt'  # ip to file name
            with open(name, 'r') as my_file:
                # search for PID, 2 searches found - then take the one with the unfamiliar ip
                txt = my_file.readlines()  # txt is a list with each line
                txt = txt_file_to_list(txt)
                for line in txt:
                    if line[0] == my_ip and line[1] == my_port:  # Find the PID
                        pid = line[4]
                        break

                for line_index in range(len(txt)):  # Find the previous IP - same PID but without foreign IP
                    if txt[line_index][4] == pid and\
                       txt[line_index][1] != my_port:
                        my_ip = txt[line_index][2]
                        my_port = txt[line_index][3]
                        counter += 1
                        print(f'ip:port {my_ip}:{my_port} counter: {counter}')
                        break
                    if line_index == len(txt) - 1:  # If no more connections
                        cont = False
                my_file.close()
    except Exception as exc:
        print(f"Error!\nip:port = {my_ip}:{my_port}\n    pid = {pid}\nException: {exc}")
    # print(f'Finished!\nip:port = {my_ip}:{my_port}\n    pid = {pid}\ncounter = {counter}')


def main():
    ex_1()


if __name__ == '__main__':
    main()
