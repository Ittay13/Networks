import socket, base64
import sys

if len(sys.argv) < 3:
    print("Usage <ip> <port>")
else:

    s = socket.socket()

    s.connect((sys.argv[1], int(sys.argv[2])))

    data = s.recv(2048).decode()
    print("GOT:", data)
    print("\n=================================")
    s.send("ProxyParty".encode())
    data = s.recv(10000000)
    print("len data  =", len(data))
    pic = base64.b64decode(data)
    print("len pic  =", len(pic))
    if data:
        with open("pic_from_srv.png", 'wb') as f:
            f.write(pic)

    s.close()
print("Bye")
