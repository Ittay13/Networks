import socket
import threading

server_ip = '0.0.0.0'
server_port = 5555
thread_list = []


def handle_client(sck, addr):
    while True:
        data = sck.recv(1024)
        if data == b'':
            break
        data = data.decode()
        if data == '\n\n':
            break
        print(f'Received from {addr}: {data}')
        data = data.upper()
        print(f'Sending to {addr}: {data}')
        sck.send(data.encode())
    sck.close()


def main():
    main_sck = socket.socket()
    main_sck.bind((server_ip, server_port))
    main_sck.listen(100)
    while True:
        client, addr = main_sck.accept()
        print('New client: ' + str(addr))
        t = threading.Thread(target=handle_client, args=(client, addr))
        thread_list.append(t)
        t.start()


if __name__ == '__main__':
    main()
