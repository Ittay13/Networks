import socket
import threading

my_ip = '0.0.0.0'
my_port = 10003
other_server_ip = '10.68.121.52'
other_server_port = 5555
response_msg = f'ECHO_SERVER#{other_server_ip}#{other_server_port}'.encode()
thread_list = []


def main():
    global response_msg
    main_sck = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    main_sck.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    main_sck.bind((my_ip, my_port))
    while True:
        data, addr = main_sck.recvfrom(1024)
        print(f'Received from {addr}, ', end='')
        if len(data) > 0 and data == b'SRCH_ITTAY':
            print(f'sending him: {response_msg}')
            main_sck.sendto(response_msg, addr)
        else:
            print(f'sending him nothing')
            main_sck.sendto(b'', addr)


if __name__ == '__main__':
    main()
