import socket

broadcast_server_pc_ip = '10.68.121.52'
subnet_mask = '255.255.255.0'


# Returns broadcast IP
def calculate_broadcast():
    global subnet_mask
    global broadcast_server_pc_ip
    subnet_str = subnet_mask.split('.')
    subnet = [int(x) for x in subnet_str]
    broadcast_server_pc_ip_str = broadcast_server_pc_ip.split('.')
    broadcast_ip = [int(x) for x in broadcast_server_pc_ip_str]
    broadcast_mask = [0] * 4
    broadcast_mask = [255-x for x in subnet]# 0.0.0.255
    broadcast_ip = [x & y for x, y in zip(broadcast_ip, subnet)]# 10.68.121.0
    broadcast_ip = [x + y for x, y in zip(broadcast_ip, broadcast_mask)]  # 10.68.121.255
    broadcast_ip = [str(x) for x in broadcast_ip]
    return '.'.join(broadcast_ip)


# Returns (IP:PORT) of server
def broadcast():
    broadcast_ip = calculate_broadcast()
    sck = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sck.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sck.sendto(b'SRCH_ITTAY', (broadcast_ip, 10003))
    data, addr = sck.recvfrom(1024)
    print(f'Received from broadcast server: {data.decode()}')
    if data == b'':
        return '0', 0
    data = data.split(b'#')
    ip = data[1].decode()
    port = data[2]
    port = int(port)
    return ip, port


def main():
    server_ip, server_port = broadcast()
    if server_ip == '0':
        print('Broadcast error!')
    else:
        sck = socket.socket()
        sck.connect((server_ip, server_port))
        while True:
            print('Enter msg to send, enter q to exit: ', end='')
            data = input()
            if data == 'q':
                break
            sck.send(data.encode())
            data = sck.recv(1024)
            data = data.decode()
            print(f'Server response: {data}')
        sck.send(b'\n\n')
        sck.close()
        print('GOODBYE')


if __name__ == '__main__':
    main()
