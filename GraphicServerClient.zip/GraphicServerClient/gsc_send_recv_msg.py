__author__ = 'Ittay Levit'
import socket
import struct
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization, hashes


# Sends msg with socket
# Builds according to protocol
# encrypt_key = b'' --> no encryption
def send_msg(msg, sock, encrypt_key=b''):
	if type(msg) != bytes:
		msg = msg.encode()
	if encrypt_key != b'':
		msg = encrypt_aes_ecb(msg, encrypt_key)
	size = struct.pack('I', len(msg))
	msg = size + msg
	print(msg)
	sock.send(msg)
	return


# Receives msg with socket
# Parsing according to protocol - returns only the message itself (without size header)
# encrypt_key = b'' --> no encryption
def recv_msg(sock, decrypt_key=b''):
	sock.settimeout(10)  # If no answer in 10 seconds - server having trouble
	size = b''
	chunk = b''
	while len(size) != 4:
		chunk = sock.recv(4-len(size))
		if chunk == b'':
			return b''
		size += chunk
	size = struct.unpack('I', size)
	data = b''
	size = size[0]
	while len(data) != size:
		chunk = sock.recv(size-len(data))
		if chunk == b'':
			return b''
		data += chunk
	print(data)
	if decrypt_key != b'':
		data = decrypt_aes_ecb(data, decrypt_key)
	return data


# Receives data (bytes) and key
# Encrypts data with AES mode ECB
def encrypt_aes_ecb(data, key_e):
	print('encryption key: ' + key_e.hex())
	cipher = Cipher(algorithms.AES(key_e), modes.ECB(), backend=default_backend())
	encryptor = cipher.encryptor()
	padded_data = data.ljust((len(data) // 16 + 1) * 16, b'\x05')  # Manual padding of byte 0h
	encrypted_bytes = encryptor.update(padded_data) + encryptor.finalize()
	print(encrypted_bytes)
	return encrypted_bytes


# Receives encrypted data (bytes) and key
# Decrypts data with AES mode ECB
def decrypt_aes_ecb(data, key_d):
	print('decryption key: ' + key_d.hex())
	cipher = Cipher(algorithms.AES(key_d), modes.ECB(), backend=default_backend())
	decryptor = cipher.decryptor()
	decrypted_bytes = decryptor.update(data) + decryptor.finalize()
	print(decrypted_bytes)
	return decrypted_bytes.rstrip(b'\x05')


# Gets key from other side and sends him key
# Returns key according to DP Helman
# Receives g, p, private_number
# side = server/client
# Server sends g, then p
def get_dph_key(sock, private_number, side, g=0, p=0):
	if side == 'server':
		send_msg(str(g).encode(), sock)
		send_msg(str(p).encode(), sock)
	else:  # side == 'client'
		g = int(recv_msg(sock).decode())
		p = int(recv_msg(sock).decode())
	calc1 = power_dph(g, private_number, p)
	send_msg(str(calc1).encode(), sock)
	other_side_calc = int(recv_msg(sock).decode())
	if other_side_calc == b'':
		return b'error'
	final_key = power_dph(other_side_calc, private_number, p)
	return str(final_key).encode()


# Power functions used in DP-Helman
def power_dph(base, exp, prime):
	if exp == 0:
		return 1
	half = power_dph(base, exp//2, prime)
	half = (half*half) % prime
	if exp % 2 == 1:
		half = (half*base) % prime
	return half


# Returns key after getting one from client with RSA
def get_key_rsa_server(sck, exp):
	private_key = rsa.generate_private_key(public_exponent=exp, key_size=2048)
	public_key = private_key.public_key()
	public_pem = public_key.public_bytes(encoding=serialization.Encoding.PEM,
										format=serialization.PublicFormat.SubjectPublicKeyInfo)
	send_msg(public_pem, sck)
	encrypted_key = recv_msg(sck)
	decrypted_key = private_key.decrypt(encrypted_key,
		padding.OAEP(
			mgf=padding.MGF1(algorithm=hashes.SHA256()),
			algorithm=hashes.SHA256(),
			label=None))
	return decrypted_key


# Sends key to server with RSA
# receives key as bytes
def send_key_rsa_client(sck, msg):
	public_pem = recv_msg(sck)
	public_key = serialization.load_pem_public_key(public_pem)
	encrypted_msg = public_key.encrypt(msg,
		padding.OAEP(
			mgf=padding.MGF1(algorithm=hashes.SHA256()),
			algorithm=hashes.SHA256(),
			label=None))
	send_msg(encrypted_msg, sck)
