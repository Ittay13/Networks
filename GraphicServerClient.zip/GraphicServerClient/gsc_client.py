# CLIENT
__author__ = 'Ittay_Levit'

import socket
import tkinter
import threading
import socket
import time
import hashlib
import send_recv_msg
import random
import datetime
# Global variables
server_ip = '127.0.0.1'
server_port = 13072
my_address = 0
signup_width_size = 300
signup_height_size = 200
login_width_size = 300
login_height_size = 150
response_width_size = 170
response_height_size = 110
verify_email_width_size = 260
verify_email_height_size = 120
main_background_color = 'lavender blush'
return_screen = 'login'
return_email = ''
replace_password = '*'
current_password_show = ''
connection_required_buttons = ['login', 'signup', 'send_code_again',
                               'verify_code', 'forgot_password', 'reset_password',
                               'exit', 'exchange_key_method']

# AES Encryption key
aes_encryption_key = b''
key_id = ''       # The ID to send so server knows which key to use
# DPH variables
DPH_private_list = [48563, 48571, 48589, 48593, 48611, 48619,
48647, 48649, 48661, 48673, 48677, 48679,
48733, 48751, 48757, 48761, 48767, 48779,
48787, 48799, 48809, 48817, 48821, 48823,
48857, 48859, 48869, 48871, 48883, 48889,
48947, 48953, 48973, 48989, 48991, 49003,
49019, 49031, 49033, 49037, 49043, 49057,
49081, 49103, 49109, 49117, 49121, 49123,
49157, 49169, 49171, 49177, 49193, 49199,
49207, 49211, 49223, 49253, 49261, 49277,
49297, 49307, 49331, 49333, 49339, 49363,
49369, 49391, 49393, 49409, 49411, 49417,
49433, 49451, 49459, 49463, 49477, 49481,
49523, 49529, 49531, 49537, 49547, 49549,
49597, 49603, 49613, 49627, 49633, 49639,
49667, 49669, 49681, 49697, 49711, 49727,
49741, 49747, 49757, 49783, 49787, 49789,
49807, 49811, 49823, 49831, 49843, 49853,
49877, 49891, 49919, 49921, 49927, 49937,
49943, 49957, 49991, 49993, 49999, 50021,
50033, 50047, 50051, 50053, 50069, 50077,
50093, 50101, 50111, 50119, 50123, 50129,
50147, 50153, 50159, 50177, 50207, 50221,
50231, 50261, 50263, 50273, 50287, 50291,
50321, 50329, 50333, 50341, 50359, 50363,
50383, 50387, 50411, 50417, 50423, 50441,
50461, 50497, 50503, 50513, 50527, 50539,
50549, 50551, 50581, 50587, 50591, 50593,
50627, 50647, 50651, 50671, 50683, 50707,
50741, 50753, 50767, 50773, 50777, 50789,
50833, 50839, 50849, 50857, 50867, 50873,
50893, 50909, 50923, 50929, 50951, 50957,
50971, 50989, 50993, 51001, 51031, 51043,
51059, 51061, 51071, 51109, 51131, 51133,
51151, 51157, 51169, 51193, 51197, 51199,
51217, 51229, 51239, 51241, 51257, 51263,
51287, 51307, 51329, 51341, 51343, 51347,
51361, 51383, 51407, 51413, 51419, 51421,
51431, 51437, 51439, 51449, 51461, 51473,
51481, 51487, 51503, 51511, 51517, 51521,
51551, 51563, 51577, 51581, 51593, 51599,
51613, 51631, 51637, 51647, 51659, 51673,
51683, 51691, 51713, 51719, 51721, 51749,
51769, 51787, 51797, 51803, 51817, 51827,
51839, 51853, 51859, 51869, 51871, 51893,
51907, 51913, 51929, 51941, 51949, 51971,
51977, 51991, 52009, 52021, 52027, 52051,
52067, 52069, 52081, 52103, 52121, 52127,
52153, 52163, 52177, 52181, 52183, 52189,
52223, 52237, 52249, 52253, 52259, 52267,
52291, 52301, 52313, 52321, 52361, 52363,
52379, 52387, 52391, 52433, 52453, 52457,
52501, 52511, 52517, 52529, 52541, 52543,
52561, 52567, 52571, 52579, 52583, 52609,
52631, 52639, 52667, 52673, 52691, 52697,
52711, 52721, 52727, 52733, 52747, 52757,
52783, 52807, 52813, 52817, 52837, 52859,
52879, 52883, 52889, 52901, 52903, 52919,
52951, 52957, 52963, 52967, 52973, 52981,
53003, 53017, 53047, 53051, 53069, 53077,
53089, 53093, 53101, 53113, 53117, 53129,
53149, 53161, 53171, 53173, 53189, 53197,
53231, 53233, 53239, 53267, 53269, 53279,
53299, 53309, 53323, 53327, 53353, 53359,
53381, 53401, 53407, 53411, 53419, 53437,
53453, 53479, 53503, 53507, 53527, 53549,
53569, 53591, 53593, 53597, 53609, 53611,
53623, 53629, 53633, 53639, 53653, 53657,
53693, 53699, 53717, 53719, 53731, 53759,
53777, 53783, 53791, 53813, 53819, 53831,
53857, 53861, 53881, 53887, 53891, 53897,
53917, 53923, 53927, 53939, 53951, 53959,
53993, 54001, 54011, 54013, 54037, 54049,
54083, 54091, 54101, 54121, 54133, 54139,
54163, 54167, 54181, 54193, 54217, 54251,
54277, 54287, 54293, 54311, 54319, 54323,
54347, 54361, 54367, 54371, 54377, 54401,
54409, 54413, 54419, 54421, 54437, 54443,
54469, 54493, 54497, 54499, 54503, 54517,
54539, 54541, 54547, 54559, 54563, 54577,
54583, 54601, 54617, 54623, 54629, 54631,
54667, 54673, 54679, 54709, 54713, 54721,
54751, 54767, 54773, 54779, 54787, 54799,
54833, 54851, 54869, 54877, 54881, 54907,
54919, 54941, 54949, 54959, 54973, 54979,
55001, 55009, 55021, 55049, 55051, 55057,
55073, 55079, 55103, 55109, 55117, 55127,
55163, 55171, 55201, 55207, 55213, 55217,
55229, 55243, 55249, 55259, 55291, 55313,
55333, 55337, 55339, 55343, 55351, 55373,
55399, 55411, 55439, 55441, 55457, 55469,
55501, 55511, 55529, 55541, 55547, 55579,
55603, 55609, 55619, 55621, 55631, 55633,
55661, 55663, 55667, 55673, 55681, 55691,
55711, 55717, 55721, 55733, 55763, 55787,
55799, 55807, 55813, 55817, 55819, 55823,
55837, 55843, 55849, 55871, 55889, 55897,
55903, 55921, 55927, 55931, 55933, 55949,
55987, 55997, 56003, 56009, 56039, 56041,
56081, 56087, 56093, 56099, 56101, 56113,
56131, 56149, 56167, 56171, 56179, 56197,
56209, 56237, 56239, 56249, 56263, 56267,
56299, 56311, 56333, 56359, 56369, 56377,
56393, 56401, 56417, 56431, 56437, 56443,
56467, 56473, 56477, 56479, 56489, 56501,
56509, 56519, 56527, 56531, 56533, 56543,
56591, 56597, 56599, 56611, 56629, 56633,
56663, 56671, 56681, 56687, 56701, 56711,
56731, 56737, 56747, 56767, 56773, 56779,
56807, 56809, 56813, 56821, 56827, 56843,
56873, 56891, 56893, 56897, 56909, 56911,
56923, 56929, 56941, 56951, 56957, 56963,
56989, 56993, 56999, 57037, 57041, 57047,
57073, 57077, 57089, 57097, 57107, 57119,
57139, 57143, 57149, 57163, 57173, 57179,
57193, 57203, 57221, 57223, 57241, 57251,
57269, 57271, 57283, 57287, 57301, 57329,
57347, 57349, 57367, 57373, 57383, 57389,
57413, 57427, 57457, 57467, 57487, 57493,
57527, 57529, 57557, 57559, 57571, 57587,
57601, 57637, 57641, 57649, 57653, 57667,
57689, 57697, 57709, 57713, 57719, 57727,
57737, 57751, 57773, 57781, 57787, 57791,
57803, 57809, 57829, 57839, 57847, 57853,
57881, 57899, 57901, 57917, 57923, 57943,
57973, 57977, 57991, 58013, 58027, 58031,
58049, 58057, 58061, 58067, 58073, 58099,
58111, 58129, 58147, 58151, 58153, 58169,
58189, 58193, 58199, 58207, 58211, 58217,
58231, 58237, 58243, 58271, 58309, 58313,
58337, 58363, 58367, 58369, 58379, 58391,
58403, 58411, 58417, 58427, 58439, 58441,
58453, 58477, 58481, 58511, 58537, 58543,
58567, 58573, 58579, 58601, 58603, 58613,
58657, 58661, 58679, 58687, 58693, 58699,
58727, 58733, 58741, 58757, 58763, 58771,
58789, 58831, 58889, 58897, 58901, 58907,
58913, 58921, 58937, 58943, 58963, 58967,
58991, 58997, 59009, 59011, 59021, 59023,
59051, 59053, 59063, 59069, 59077, 59083,
59107, 59113, 59119, 59123, 59141, 59149,
59167, 59183, 59197, 59207, 59209, 59219,
59233, 59239, 59243, 59263, 59273, 59281,
59341, 59351, 59357, 59359, 59369, 59377,
59393, 59399, 59407, 59417, 59419, 59441,
59447, 59453, 59467, 59471, 59473, 59497,
59513, 59539, 59557, 59561, 59567, 59581,
59617, 59621, 59627, 59629, 59651, 59659,
59669, 59671, 59693, 59699, 59707, 59723,
59743, 59747, 59753, 59771, 59779, 59791,
59809, 59833, 59863, 59879, 59887, 59921,
59951, 59957, 59971, 59981, 59999, 60013,
60029, 60037, 60041, 60077, 60083, 60089,
60101, 60103, 60107, 60127, 60133, 60139,
60161, 60167, 60169, 60209, 60217, 60223,
60257, 60259, 60271, 60289, 60293, 60317,
60337, 60343, 60353, 60373, 60383, 60397,
60427, 60443, 60449, 60457, 60493, 60497,
60521, 60527, 60539, 60589, 60601, 60607,
60617, 60623, 60631, 60637, 60647, 60649,
60661, 60679, 60689, 60703, 60719, 60727,
60737, 60757, 60761, 60763, 60773, 60779,
60811, 60821, 60859, 60869, 60887, 60889,
60901, 60913, 60917, 60919, 60923, 60937,
60953, 60961, 61001, 61007, 61027, 61031,
61051, 61057, 61091, 61099, 61121, 61129,
61151, 61153, 61169, 61211, 61223, 61231,
61261, 61283, 61291, 61297, 61331, 61333,
61343, 61357, 61363, 61379, 61381, 61403,
61417, 61441, 61463, 61469, 61471, 61483,
61493, 61507, 61511, 61519, 61543, 61547,
61559, 61561, 61583, 61603, 61609, 61613,
61631, 61637, 61643, 61651, 61657, 61667,
61681, 61687, 61703, 61717, 61723, 61729,
61757, 61781, 61813, 61819, 61837, 61843,
61871, 61879, 61909, 61927, 61933, 61949,
61967, 61979, 61981, 61987, 61991, 62003,
62017, 62039, 62047, 62053, 62057, 62071,
62099, 62119, 62129, 62131, 62137, 62141,
62171, 62189, 62191, 62201, 62207, 62213,
62233, 62273, 62297, 62299, 62303, 62311,
62327, 62347, 62351, 62383, 62401, 62417,
62459, 62467, 62473, 62477, 62483, 62497,
62507, 62533, 62539, 62549, 62563, 62581,
62597, 62603, 62617, 62627, 62633, 62639,
62659, 62683, 62687, 62701, 62723, 62731,
62753, 62761, 62773, 62791, 62801, 62819,
62851, 62861, 62869, 62873, 62897, 62903,
62927, 62929, 62939, 62969, 62971, 62981,
62987, 62989, 63029, 63031, 63059, 63067,
63079, 63097, 63103, 63113, 63127, 63131,
63179, 63197, 63199, 63211, 63241, 63247,
63281, 63299, 63311, 63313, 63317, 63331,
63347, 63353, 63361, 63367, 63377, 63389,
63397, 63409, 63419, 63421, 63439, 63443,
63467, 63473, 63487, 63493, 63499, 63521,
63533, 63541, 63559, 63577, 63587, 63589,
63601, 63607, 63611, 63617, 63629, 63647,
63659, 63667, 63671, 63689, 63691, 63697,
63709, 63719, 63727, 63737, 63743, 63761,
63781, 63793, 63799, 63803, 63809, 63823,
63841, 63853, 63857, 63863, 63901, 63907,
63929, 63949, 63977, 63997, 64007, 64013,
64033, 64037, 64063, 64067, 64081, 64091,
64123, 64151, 64153, 64157, 64171, 64187,
64217, 64223, 64231, 64237, 64271, 64279,
64301, 64303, 64319, 64327, 64333, 64373,
64399, 64403, 64433, 64439, 64451, 64453,
64489, 64499, 64513, 64553, 64567, 64577,
64591, 64601, 64609, 64613, 64621, 64627,
64661, 64663, 64667, 64679, 64693, 64709,
64747, 64763, 64781, 64783, 64793, 64811,
64849, 64853, 64871, 64877, 64879, 64891,
64919, 64921, 64927, 64937, 64951, 64969,
65003, 65011, 65027, 65029, 65033, 65053,
65071, 65089, 65099, 65101, 65111, 65119,
65129, 65141, 65147, 65167, 65171, 65173,
65183, 65203, 65213, 65239, 65257, 65267,
65287, 65293, 65309, 65323, 65327, 65353,
65371, 65381, 65393, 65407, 65413, 65419,
65437, 65447, 65449, 65479, 65497, 65519,
65537, 65539, 65543, 65551, 65557, 65563,
65581, 65587, 65599, 65609, 65617, 65629,
65647, 65651, 65657, 65677, 65687, 65699,
65707, 65713, 65717, 65719, 65729, 65731,
65777, 65789, 65809, 65827, 65831, 65837,
65843, 65851, 65867, 65881, 65899, 65921,
65929, 65951, 65957, 65963, 65981, 65983,
66029, 66037, 66041, 66047, 66067, 66071,
66089, 66103, 66107, 66109, 66137, 66161,
66173, 66179, 66191, 66221, 66239, 66271,
66301, 66337, 66343, 66347, 66359, 66361,
66377, 66383, 66403, 66413, 66431, 66449,
66463, 66467, 66491, 66499, 66509, 66523,
66533, 66541, 66553, 66569, 66571, 66587,
66601, 66617, 66629, 66643, 66653, 66683,
66701, 66713, 66721, 66733, 66739, 66749,
66763, 66791, 66797, 66809, 66821, 66841,
66853, 66863, 66877, 66883, 66889, 66919,
66931, 66943, 66947, 66949, 66959, 66973,
67003, 67021, 67033, 67043, 67049, 67057,
67073, 67079, 67103, 67121, 67129, 67139,
67153, 67157, 67169, 67181, 67187, 67189,
67213, 67217, 67219, 67231, 67247, 67261,
67273, 67289, 67307, 67339, 67343, 67349,
67391, 67399, 67409, 67411, 67421, 67427,
67433, 67447, 67453, 67477, 67481, 67489,
67499, 67511, 67523, 67531, 67537, 67547,
67567, 67577, 67579, 67589, 67601, 67607,
67631, 67651, 67679, 67699, 67709, 67723,
67741, 67751, 67757, 67759, 67763, 67777,
67789, 67801, 67807, 67819, 67829, 67843,
67867, 67883, 67891, 67901, 67927, 67931,
67939, 67943, 67957, 67961, 67967, 67979,
67993, 68023, 68041, 68053, 68059, 68071,
68099, 68111, 68113, 68141, 68147, 68161,
68207, 68209, 68213, 68219, 68227, 68239,
68279, 68281, 68311, 68329, 68351, 68371,
68399, 68437, 68443, 68447, 68449, 68473,
68483, 68489, 68491, 68501, 68507, 68521,
68539, 68543, 68567, 68581, 68597, 68611,
68639, 68659, 68669, 68683, 68687, 68699,
68713, 68729, 68737, 68743, 68749, 68767,
68777, 68791, 68813, 68819, 68821, 68863,
68881, 68891, 68897, 68899, 68903, 68909,
68927, 68947, 68963, 68993, 69001, 69011,
69029, 69031, 69061, 69067, 69073, 69109,
69127, 69143, 69149, 69151, 69163, 69191,
69197, 69203, 69221, 69233, 69239, 69247,
69259, 69263, 69313, 69317, 69337, 69341,
69379, 69383, 69389, 69401, 69403, 69427,
69439, 69457, 69463, 69467, 69473, 69481,
69493, 69497, 69499, 69539, 69557, 69593,
69653, 69661, 69677, 69691, 69697, 69709,
69739, 69761, 69763, 69767, 69779, 69809,
69827, 69829, 69833, 69847, 69857, 69859,
69899, 69911, 69929, 69931, 69941, 69959,
69997, 70001, 70003, 70009, 70019, 70039,
70061, 70067, 70079, 70099, 70111, 70117,
70123, 70139, 70141, 70157, 70163, 70177,
70183, 70199, 70201, 70207, 70223, 70229,
70241, 70249, 70271, 70289, 70297, 70309,
70321, 70327, 70351, 70373, 70379, 70381,
70423, 70429, 70439, 70451, 70457, 70459,
70487, 70489, 70501, 70507, 70529, 70537,
70571, 70573, 70583, 70589, 70607, 70619,
70627, 70639, 70657, 70663, 70667, 70687,
70717, 70729, 70753, 70769, 70783, 70793,
70841, 70843, 70849, 70853, 70867, 70877,
70891, 70901, 70913, 70919, 70921, 70937,
70951, 70957, 70969, 70979, 70981, 70991,
70999, 71011, 71023, 71039, 71059, 71069,
71089, 71119, 71129, 71143, 71147, 71153,
71167, 71171, 71191, 71209, 71233, 71237,
71257, 71261, 71263, 71287, 71293, 71317,
71329, 71333, 71339, 71341, 71347, 71353,
71363, 71387, 71389, 71399, 71411, 71413,
71429, 71437, 71443, 71453, 71471, 71473,
71483, 71503, 71527, 71537, 71549, 71551,
71569, 71593, 71597, 71633, 71647, 71663,
71693, 71699, 71707, 71711, 71713, 71719,
71761, 71777, 71789, 71807, 71809, 71821,
71843, 71849, 71861, 71867, 71879, 71881,
71899, 71909, 71917, 71933, 71941, 71947,
71971, 71983, 71987, 71993, 71999, 72019,
72043, 72047, 72053, 72073, 72077, 72089,
72101, 72103, 72109, 72139, 72161, 72167,
72173, 72211, 72221, 72223, 72227, 72229,
72253, 72269, 72271, 72277, 72287, 72307,
72337, 72341, 72353, 72367, 72379, 72383,
72431, 72461, 72467, 72469, 72481, 72493,
72503, 72533, 72547, 72551, 72559, 72577,
72617, 72623, 72643, 72647, 72649, 72661,
72673, 72679, 72689, 72701, 72707, 72719,
72733, 72739, 72763, 72767, 72797, 72817,
72859, 72869, 72871, 72883, 72889, 72893,
72907, 72911, 72923, 72931, 72937, 72949,
72959, 72973, 72977, 72997, 73009, 73013,
73037, 73039, 73043, 73061, 73063, 73079,
73121, 73127, 73133, 73141, 73181, 73189,
73243, 73259, 73277, 73291, 73303, 73309,
73331, 73351, 73361, 73363, 73369, 73379,
73417, 73421, 73433, 73453, 73459, 73471,
73483, 73517, 73523, 73529, 73547, 73553,
73571, 73583, 73589, 73597, 73607, 73609,
73637, 73643, 73651, 73673, 73679, 73681,
73699, 73709, 73721, 73727, 73751, 73757,
73783, 73819, 73823, 73847, 73849, 73859,
73877, 73883, 73897, 73907, 73939, 73943,
73961, 73973, 73999, 74017, 74021, 74027,
74051, 74071, 74077, 74093, 74099, 74101,
74143, 74149, 74159, 74161, 74167, 74177,
74197, 74201, 74203, 74209, 74219, 74231,
74279, 74287, 74293, 74297, 74311, 74317,
74353, 74357, 74363, 74377, 74381, 74383,
74413, 74419, 74441, 74449, 74453, 74471,
74507, 74509, 74521, 74527, 74531, 74551,
74567, 74573, 74587, 74597, 74609, 74611,
74653, 74687, 74699, 74707, 74713, 74717,
74729, 74731, 74747, 74759, 74761, 74771,
74797, 74821, 74827, 74831, 74843, 74857,
74869, 74873, 74887, 74891, 74897, 74903,
74929, 74933, 74941, 74959, 75011, 75013,
75029, 75037, 75041, 75079, 75083, 75109,
75149, 75161, 75167, 75169, 75181, 75193,
75211, 75217, 75223, 75227, 75239, 75253,
75277, 75289, 75307, 75323, 75329, 75337,
75353, 75367, 75377, 75389, 75391, 75401,
75407, 75431, 75437, 75479, 75503, 75511,
75527, 75533, 75539, 75541, 75553, 75557,
75577, 75583, 75611, 75617, 75619, 75629,
75653, 75659, 75679, 75683, 75689, 75703,
75709, 75721, 75731, 75743, 75767, 75773,
75787, 75793, 75797, 75821, 75833, 75853,
75883, 75913, 75931, 75937, 75941, 75967,
75983, 75989, 75991, 75997, 76001, 76003,
76039, 76079, 76081, 76091, 76099, 76103,
76129, 76147, 76157, 76159, 76163, 76207,
76231, 76243, 76249, 76253, 76259, 76261,
76289, 76303, 76333, 76343, 76367, 76369,
76387, 76403, 76421, 76423, 76441, 76463,
76481, 76487, 76493, 76507, 76511, 76519,
76541, 76543, 76561, 76579, 76597, 76603,
76631, 76649, 76651, 76667, 76673, 76679,
76717, 76733, 76753, 76757, 76771, 76777,
76801, 76819, 76829, 76831, 76837, 76847,
76873, 76883, 76907, 76913, 76919, 76943,
76961, 76963, 76991, 77003, 77017, 77023,
77041, 77047, 77069, 77081, 77093, 77101,
77141, 77153, 77167, 77171, 77191, 77201,
77237, 77239, 77243, 77249, 77261, 77263,
77269, 77279, 77291, 77317, 77323, 77339,
77351, 77359, 77369, 77377, 77383, 77417,
77431, 77447, 77471, 77477, 77479, 77489,
77509, 77513, 77521, 77527, 77543, 77549,
77557, 77563, 77569, 77573, 77587, 77591,
77617, 77621, 77641, 77647, 77659, 77681,
77689, 77699, 77711, 77713, 77719, 77723,
77743, 77747, 77761, 77773, 77783, 77797,
77813, 77839, 77849, 77863, 77867, 77893,
77929, 77933, 77951, 77969, 77977, 77983,
78007, 78017, 78031, 78041, 78049, 78059,
78101, 78121, 78137, 78139, 78157, 78163,
78173, 78179, 78191, 78193, 78203, 78229,
78241, 78259, 78277, 78283, 78301, 78307,
78317, 78341, 78347, 78367, 78401, 78427,
78439, 78467, 78479, 78487, 78497, 78509,
78517, 78539, 78541, 78553, 78569, 78571,
78583, 78593, 78607, 78623, 78643, 78649,
78691, 78697, 78707, 78713, 78721, 78737,
78781, 78787, 78791, 78797, 78803, 78809,
78839, 78853, 78857, 78877, 78887, 78889,
78901, 78919, 78929, 78941, 78977, 78979,
79031, 79039, 79043, 79063, 79087, 79103,
79133, 79139, 79147, 79151, 79153, 79159,
79187, 79193, 79201, 79229, 79231, 79241,
79273, 79279, 79283, 79301, 79309, 79319,
79337, 79349, 79357, 79367, 79379, 79393,
79399, 79411, 79423, 79427, 79433, 79451,
79493, 79531, 79537, 79549, 79559, 79561,
79589, 79601, 79609, 79613, 79621, 79627,
79633, 79657, 79669, 79687, 79691, 79693,
79699, 79757, 79769, 79777, 79801, 79811,
79817, 79823, 79829, 79841, 79843, 79847,
79867, 79873, 79889, 79901, 79903, 79907,
79943, 79967, 79973, 79979, 79987, 79997,
80021, 80039, 80051, 80071, 80077, 80107,
80141, 80147, 80149, 80153, 80167, 80173,
80191, 80207, 80209, 80221, 80231, 80233,
80251, 80263, 80273, 80279, 80287, 80309,
80329, 80341, 80347, 80363, 80369, 80387,
80429, 80447, 80449, 80471, 80473, 80489,
80513, 80527, 80537, 80557, 80567, 80599,
80611, 80621, 80627, 80629, 80651, 80657,
80671, 80677, 80681, 80683, 80687, 80701]


# Builds signup screen. takes root window as argument
# Returns username, password and email after built according to protocol
def signup_gui(window):
    global current_password_show
    global return_screen
    return_screen = 'signup'
    current_password_show = replace_password  # default
    # Variables to hold information
    username_svar = tkinter.StringVar()
    password_svar = tkinter.StringVar()
    email_svar = tkinter.StringVar()
    verify_email_svar = tkinter.StringVar()
    dc = {'username': username_svar, 'password': password_svar, 'email': email_svar, 'verify_email': verify_email_svar}

    window.geometry(f'{str(signup_width_size)}x{str(signup_height_size)}')
    frame = tkinter.Frame(window, bg=main_background_color, width=signup_width_size, height=signup_height_size)
    frame.place(relwidth=1, relheight=1)

    # username
    #   label
    username_label = tkinter.Label(frame, text='Username:', background=main_background_color)
    username_label.pack()
    #   entry
    username_entry = tkinter.Entry(frame, textvariable=username_svar,
                                   width=18)
    username_entry.pack()
    username_entry.focus()

    # password
    #   label
    password_label = tkinter.Label(frame, text='Password:', background=main_background_color)
    password_label.pack()
    #   entry
    password_entry = tkinter.Entry(frame, textvariable=password_svar, show=current_password_show,
                                   width=18)
    password_entry.pack()

    # email
    #   label
    email_label = tkinter.Label(frame, text='Email:', background=main_background_color)
    email_label.pack()
    #   entry
    email_entry = tkinter.Entry(frame, textvariable=email_svar,
                                width=18)
    email_entry.pack()
    # verify email
    #   label
    verify_email_label = tkinter.Label(frame, text='Verify email:', background=main_background_color)
    verify_email_label.pack()
    #   entry
    verify_email_entry = tkinter.Entry(frame, textvariable=verify_email_svar,
                                width=18)
    verify_email_entry.pack()

    # signup button
    signup_button_func = lambda: [handle_buttons('signup', window, **dc)]
    signup_button = tkinter.Button(frame, text='Signup', command=signup_button_func,
                                  activebackground='lightblue', activeforeground='white',
                                  width=7)
    signup_button.place(x=120, y=166)

    # exit button
    exit_button_func = lambda: [handle_buttons('exit', window)]
    exit_button = tkinter.Button(frame, text='Exit', command=exit_button_func,
                                 activebackground='red', activeforeground='white',
                                 width=7)
    exit_button.place(x=241, y=0)

    # show password button
    show_password_func = lambda: [change_current_show_password(password_entry)]
    show_password_button = tkinter.Button(frame, text='Show', command=show_password_func,
                                          activebackground='MediumPurple3', activeforeground='white',
                                          width=4)
    show_password_button.place(x=220, y=57)
    # go to login gui
    go_to_login_func = lambda: [show_screen(window, 'login')]
    go_to_login_button = tkinter.Button(frame, text='Login screen', command=go_to_login_func,
                                          activebackground='aquamarine2', activeforeground='white',
                                          width=10)
    go_to_login_button.place(x=0, y=170)


# builds the signup parameters (username, password and email) to send to the server
# Called when signup button is pressed
def process_signup(**kwargs):
    global return_email
    username = kwargs['username'].get()
    password = kwargs['password'].get()
    email = kwargs['email'].get()
    return_email = email
    verify_email = kwargs['verify_email'].get()
    print(f'username: {username}')
    print(f'password: {password}')
    print(f'email: {email}')
    print(f'verify_email: {verify_email}')
    msg_to_send = f'sgnp{username}\n{password}\n{email}\n{verify_email}'
    return msg_to_send


# Builds login screen. takes root window as argument
# Returns username and password after built according to protocol
def login_gui(window):
    global current_password_show
    global return_screen
    return_screen = 'login'
    current_password_show = replace_password  # default
    # Variables to hold information
    username_svar = tkinter.StringVar()
    password_svar = tkinter.StringVar()
    dc = {'username': username_svar, 'password': password_svar}

    window.geometry(f'{str(login_width_size)}x{str(login_height_size)}')
    frame = tkinter.Frame(window, bg=main_background_color, width=login_width_size, height=login_height_size)
    frame.place(relwidth=1, relheight=1)

    # username
    #   label
    username_label = tkinter.Label(frame, text='Username:', background=main_background_color)
    username_label.pack()
    #   entry
    username_entry = tkinter.Entry(frame, textvariable=username_svar,
                                   width=18)
    username_entry.pack()
    username_entry.focus()

    # password
    #   label
    password_label = tkinter.Label(frame, text='Password:', background=main_background_color)
    password_label.pack()
    #   entry
    password_entry = tkinter.Entry(frame, textvariable=password_svar, show=current_password_show,
                                   width=18)
    password_entry.pack()

    # show password button
    show_password_func = lambda: [change_current_show_password(password_entry)]
    show_password_button = tkinter.Button(frame, text='Show', command=show_password_func,
                                          activebackground='MediumPurple3', activeforeground='white',
                                          width=4)
    show_password_button.place(x=220, y=57)
    # show_password_button.pack()
    # show_password_button.pack(side='right')

    # login button
    login_button_func = lambda: [handle_buttons('login', window, **dc)]
    login_button = tkinter.Button(frame, text='Login', command=login_button_func,
                                  activebackground='lightblue', activeforeground='white',
                                  width=7)
    login_button.place(x=120, y=100)

    # exit button
    exit_button_func = lambda: [handle_buttons('exit', window)]
    exit_button = tkinter.Button(frame, text='Exit', command=exit_button_func,
                                 activebackground='red', activeforeground='white',
                                 width=7)
    exit_button.place(x=241, y=0)
    # go to signup gui
    go_to_signup_func = lambda: [show_screen(window, 'signup')]
    go_to_signup_button = tkinter.Button(frame, text='Signup screen', command=go_to_signup_func,
                                          activebackground='aquamarine2', activeforeground='white',
                                          width=10)
    go_to_signup_button.place(x=0, y=120)
    # go to forgot_password gui
    go_to_forgot_password_func = lambda: [show_screen(window, 'forgot_password')]
    o_to_forgot_password_button = tkinter.Button(frame, text='Forgot your\npassword?',
                                                 command=go_to_forgot_password_func,
                                          activebackground='salmon3', activeforeground='white',
                                          width=10)
    o_to_forgot_password_button.place(x=220, y=105)


# Builds the login parameters (username and password) to send to the server
# Called when login button is pressed
def process_login(**kwargs):
    username = kwargs['username'].get()
    password = kwargs['password'].get()
    print('username: ')
    print(username)
    print('password: ')
    print(password)
    msg_to_send = f'lgnp{username}\n{password}'
    return msg_to_send


# Builds verify-email screen. takes root window and email as arguments
# Called after receiving a verify-email message from server
def verify_email_gui(window, email):
    global current_password_show
    global return_screen
    global return_email
    if email == '':  # If an error was raised that deleted the email
        email = return_email
    return_screen = 'verify_email'
    current_password_show = replace_password  # default
    # Variables to hold information
    code_svar = tkinter.StringVar()
    dc = {'code': code_svar, 'email': email}
    print(f'dc in verify_email_gui: {code_svar.get()}, {email}')

    window.geometry(f'{str(verify_email_width_size)}x{str(verify_email_height_size)}')
    frame = tkinter.Frame(window, bg=main_background_color,
                          width=verify_email_width_size, height=verify_email_height_size)
    frame.place(relwidth=1, relheight=1)

    # code was sent msg
    #   label
    code_was_sent_label = tkinter.Label(frame,
                                         text=f'Code was sent to email:\n{email}', background=main_background_color)
    code_was_sent_label.place(x=50, y=2)
    # code
    #   label
    code_label = tkinter.Label(frame, text='Code:', background=main_background_color)
    code_label.place(x=50, y=45)
    #   entry
    code_entry = tkinter.Entry(frame, textvariable=code_svar, show=current_password_show,
                                   width=8)
    code_entry.place(x=90, y=46)

    # show code button
    show_code_func = lambda: [change_current_show_password(code_entry, 90, 46)]
    show_password_button = tkinter.Button(frame, text='Show', command=show_code_func,
                                          activebackground='MediumPurple3', activeforeground='white',
                                          width=4)
    show_password_button.place(x=160, y=42)

    # send code again button
    send_again_button_func = lambda: [handle_buttons('send_code_again', window, **dc)]
    send_button = tkinter.Button(frame, text='Send Code Again', command=send_again_button_func,
                                  activebackground='RoyalBlue4', activeforeground='white',
                                  width=14)
    send_button.place(x=152, y=80)
    # send code button
    send_button_func = lambda: [handle_buttons('verify_code', window, **dc)]
    send_button = tkinter.Button(frame, text='Send', command=send_button_func,
                                  activebackground='lightblue', activeforeground='white',
                                  width=7)
    send_button.place(x=84, y=80)

    # exit button
    exit_button_func = lambda: [handle_buttons('exit', window)]
    exit_button = tkinter.Button(frame, text='Exit', command=exit_button_func,
                                 activebackground='red', activeforeground='white',
                                 width=7)
    exit_button.place(x=201, y=0)


# Builds the verify email parameters (code and email) to send to the server
# Called when send code button is pressed
def process_verify_email(**kwargs):
    email = kwargs['email']
    code = kwargs['code'].get()
    print('email: ')
    print(email)
    print('code: ')
    print(code)
    msg_to_send = f'cdve{code}\n{email}'
    return msg_to_send


# Builds forgot password screen. takes root window as argument
# Returns email after built according to protocol
def forgot_password_gui(window):
    global return_screen
    return_screen = 'forgot_password'
    # Variables to hold information
    email_svar = tkinter.StringVar()
    dc = {'email': email_svar}

    window.geometry(f'{str(verify_email_width_size)}x{str(verify_email_height_size)}')
    frame = tkinter.Frame(window, bg=main_background_color,
                          width=verify_email_width_size, height=verify_email_height_size)
    frame.place(relwidth=1, relheight=1)

    # enter email msg
    #   label
    enter_email_label = tkinter.Label(frame,
                                         text=f'Enter email to reset password', background=main_background_color)
    enter_email_label.place(x=30, y=5)
    # email
    #   label
    email_label = tkinter.Label(frame, text='Email:', background=main_background_color)
    email_label.place(x=50, y=45)
    #   entry
    email_entry = tkinter.Entry(frame, textvariable=email_svar, width=20)
    email_entry.place(x=90, y=46)

    # send code button
    send_button_func = lambda: [handle_buttons('forgot_password', window, **dc)]
    send_button = tkinter.Button(frame, text='Send', command=send_button_func,
                                  activebackground='lightblue', activeforeground='white',
                                  width=7)
    send_button.place(x=84, y=80)

    # go to signup gui
    go_to_signup_func = lambda: [show_screen(window, 'signup')]
    go_to_signup_button = tkinter.Button(frame, text='Signup screen', command=go_to_signup_func,
                                         activebackground='aquamarine2', activeforeground='white',
                                         width=11)
    go_to_signup_button.place(x=173, y=80)

    # exit button
    exit_button_func = lambda: [handle_buttons('exit', window)]
    exit_button = tkinter.Button(frame, text='Exit', command=exit_button_func,
                                 activebackground='red', activeforeground='white',
                                 width=7)
    exit_button.place(x=201, y=0)


# Builds the forgot password parameters (email) to send to the server
# Called when forgot password button is pressed
def process_forgot_password(**kwargs):
    global return_email
    return_email = kwargs['email'].get()
    email = kwargs['email'].get()
    print('email: ', end='')
    print(email)
    msg_to_send = f'frps{email}'
    return msg_to_send


# Builds reset password screen. Takes root window and email as arguments
# Called after receiving a password-reset approve.
def reset_password_gui(window):
    global current_password_show
    global return_email
    global return_screen
    return_screen = 'reset_password'
    current_password_show = replace_password  # default
    # Variables to hold information
    password_svar = tkinter.StringVar()
    dc = {'password': password_svar, 'email': return_email}

    window.geometry(f'{str(verify_email_width_size)}x{str(verify_email_height_size)}')
    frame = tkinter.Frame(window, bg=main_background_color,
                          width=verify_email_width_size, height=verify_email_height_size)
    frame.place(relwidth=1, relheight=1)

    # enter password msg
    #   label
    enter_password_label = tkinter.Label(frame, text=f'Enter new password', background=main_background_color)
    enter_password_label.place(x=30, y=5)
    # password
    #   label
    password_label = tkinter.Label(frame, text='Password', background=main_background_color)
    password_label.place(x=30, y=45)
    #   entry
    password_entry = tkinter.Entry(frame, textvariable=password_svar, width=12)
    password_entry.place(x=90, y=46)

    # show password button
    show_password_func = lambda: [change_current_show_password(password_entry, 90, 46)]
    show_password_button = tkinter.Button(frame, text='Show', command=show_password_func,
                                          activebackground='MediumPurple3', activeforeground='white',
                                          width=4)
    show_password_button.place(x=180, y=43)
    # show_password_button.pack()
    # show_password_button.pack(side='right')

    # send code button
    send_button_func = lambda: [handle_buttons('reset_password', window, **dc)]
    send_button = tkinter.Button(frame, text='Send', command=send_button_func,
                                  activebackground='lightblue', activeforeground='white',
                                  width=7)
    send_button.place(x=84, y=80)

    # exit button
    exit_button_func = lambda: [handle_buttons('exit', window)]
    exit_button = tkinter.Button(frame, text='Exit', command=exit_button_func,
                                 activebackground='red', activeforeground='white',
                                 width=7)
    exit_button.place(x=201, y=0)


# Builds the reset password parameters (email and password) to send to server
# Called when reset password button is pressed
def process_reset_password(**kwargs):
    global return_email
    email = return_email
    password = kwargs['password'].get()
    print('email: ', end='')
    print(email)
    print('password: ', end='')
    print(password)
    msg_to_send = f'rsps{email}\n{password}'
    return msg_to_send


# Builds the send code again request with email
# Called when the send code again button is pressed
def process_send_code_again(email):
    return b'cdap'+email.encode()


# Builds exchange-key screen. Takes root window as argument
# Called after receiving a exchange-key request.
def exchange_key_gui(window):
    window.geometry(f'{str(verify_email_width_size)}x{str(verify_email_height_size)}')
    frame = tkinter.Frame(window, bg=main_background_color,
                          width=verify_email_width_size, height=verify_email_height_size)
    frame.place(relwidth=1, relheight=1)

    # enter password msg
    #   label
    key_exchange_button = tkinter.Label(frame, text=f'Press on you preferred key-exchange method',
                                         background=main_background_color)
    key_exchange_button.place(x=5, y=40)

    # DPH method button
    DPH_button_func = lambda: [handle_buttons('exchange_key_method', window, **{'method': 'DPH'})]
    send_button = tkinter.Button(frame, text='DP-Helman', command=DPH_button_func,
                                  activebackground='lightblue', activeforeground='white',
                                  width=9)
    send_button.place(x=20, y=80)

    # RSA method button
    DPH_button_func = lambda: [handle_buttons('exchange_key_method', window, **{'method': 'RSA'})]
    send_button = tkinter.Button(frame, text='RSA', command=DPH_button_func,
                                  activebackground='lightblue', activeforeground='white',
                                  width=9)
    send_button.place(x=160, y=80)

    # exit button
    exit_button_func = lambda: [handle_buttons('exit', window)]
    exit_button = tkinter.Button(frame, text='Exit', command=exit_button_func,
                                 activebackground='red', activeforeground='white',
                                 width=7)
    exit_button.place(x=201, y=0)


# Builds the exchange-key message (method to use)
def process_exchange_key_gui(method):
    return b'kems'+method.encode()


# Returns a number out of the DPH_private_list
def get_private_dph():
    global DPH_private_list
    index = random.randint(0, len(DPH_private_list)-1)
    return DPH_private_list[index]


# Returns a 128 bits random string
def generate_random_key_128bits():
    s = ''
    for i in range(16):
        s += chr(random.randint(32, 126))
    return s.encode()


# Handles the exchange-key procedure
# Declares the key after receiving it
def exchange_key(method, sock):
    global aes_encryption_key
    global key_id
    if method == 'DPH':
        private = get_private_dph()
        key = send_recv_msg.get_dph_key(sock, private, 'client')
        aes_encryption_key = hashlib.sha256(key).digest()[:128]  # Turn key into 128 hash bits
    else:  # method == 'RSA'
        aes_encryption_key = generate_random_key_128bits()
        aes_encryption_key = hashlib.sha256(aes_encryption_key).digest()[:128]  # Turn key into 128 hash bits
        send_recv_msg.send_key_rsa_client(sock, aes_encryption_key)
    print('key: ' + aes_encryption_key.hex())


# Returns ID to send to server
# Builds key: 'ip:port CURRENT-TIME'
def calculate_key_id(ip, port):
    return ip + ':' + str(port) + '|' + str(datetime.datetime.now())


# Helps the 'show' button to show password's characters
def change_current_show_password(password_entry, x_pos=-1, y_pos=-1):
    global current_password_show
    if current_password_show == '':
        current_password_show = replace_password
    else:
        current_password_show = ''
    password_entry.configure(show=current_password_show)
    if x_pos >= 0 and y_pos >= 0:
        password_entry.place(x=x_pos, y=y_pos)
    else:
        password_entry.pack()
    return


# Shows screen according to response (customized text-based screen)
def custom_screen(response, window):
    window.geometry(f'{str(response_width_size)}x{str(response_height_size)}')
    frame = tkinter.Frame(window, bg=main_background_color, width=response_width_size, height=response_height_size)
    frame.place(relwidth=1, relheight=1)

    # response label
    response_label = tkinter.Label(frame, text=response, background=main_background_color,
                                   wraplength=response_width_size-20)
    response_label.place(relx=0.5, rely=0.5, anchor='center')

    # exit button
    exit_button_func = lambda: [handle_buttons('return_from_response', window)]
    exit_button = tkinter.Button(frame, text='Exit', command=exit_button_func,
                                 activebackground='red', activeforeground='white',
                                 width=7)
    exit_button.place(x=111, y=0)


# Handles data received from server
def handle_data(data, sock):
    global return_screen
    data = data.decode()
    cmd = data[:4]
    data = data[4:]
    fields = data.split('\n')
    special_screen = 'custom'
    label_explanation_response = ''
    if cmd == 'lgna':
        label_explanation_response = 'Login succeeded!'
    elif cmd == 'sgna':
        label_explanation_response = 'Signup succeeded!'
        return_screen = 'login'
    elif cmd == 'vfce':
        label_explanation_response = fields[0]
        special_screen = 'verify_email'
    elif cmd == 'vfap':
        label_explanation_response = 'Password reset request succeeded'
        special_screen = 'reset_password'
    elif cmd == 'rspa':
        label_explanation_response = 'Password reset successfully!'
        return_screen = 'login'
    elif cmd == 'skep':
        special_screen = 'exchange_key'
    elif cmd == 'keas':
        exchange_key(data, sock)
        special_screen = 'signup'
    elif cmd == 'eror':
        label_explanation_response = 'Error!\r\n'+fields[1]
    else:
        label_explanation_response = 'Unknown response from server'
    return label_explanation_response, special_screen


# Handles pressed buttons
# button_str = 'exit', 'login', 'signup', 'send_code_again', 'forgot_password'
def handle_buttons(button_str, window, **kwargs):
    global connection_required_buttons
    global return_screen
    global aes_encryption_key
    global key_id
    global my_address
    msg = ''
    if button_str == 'exit':      # exit button
        window.destroy()
        return
    elif button_str == 'return_from_response':
        show_screen(window, return_screen)
        return
    if button_str in connection_required_buttons:  # If button that requires connection with server
        if button_str == 'login':     # login button
            print('processing login')
            msg = process_login(**kwargs)
        elif button_str == 'signup':    # signup button
            print('processing signup')
            msg = process_signup(**kwargs)
        elif button_str == 'send_code_again':    # send_code_again button
            print('sending code again')
            msg = process_send_code_again(kwargs['email'])
        elif button_str == 'forgot_password':
            print('sending email')
            msg = process_forgot_password(**kwargs)
        elif button_str == 'verify_code':
            print('verifying code')
            msg = process_verify_email(**kwargs)
        elif button_str == 'reset_password':
            print('reseting password')
            msg = process_reset_password(**kwargs)
        elif button_str == 'exchange_key_method':
            print('Sending key-exchange method')
            msg = process_exchange_key_gui(kwargs['method'])
        # Send data to server
        sck = socket.socket()
        sck.connect((server_ip, server_port))
        ip, port = sck.getsockname()
        if key_id == '':  # If key-id is not set yet
            key_id = calculate_key_id(ip, port)
        print('key-id: ' + str(key_id))
        send_recv_msg.send_msg(b'pake'+key_id.encode(), sck)
        msg_about_key_exchange = send_recv_msg.recv_msg(sck)
        if msg_about_key_exchange == b'skep':  # If key exchange is necessary
            pass  # Next message is about the key-exchange
        else:  # If msg == b'ukoa' --> USE THE SAVED KEY!
            pass
        send_recv_msg.send_msg(msg, sck, aes_encryption_key)
        if button_str == 'exit':
            sck.close()
            return
        data = send_recv_msg.recv_msg(sck, aes_encryption_key)
        lbl, specific_screen = handle_data(data, sck)
        sck.close()
        show_screen(window, specific_screen, lbl)


# Show screen according to argument 'screen'.
# Screen options: signup, login, forgot_password, custom (response from server)
def show_screen(window, screen, lbl=''):
    title = screen.split('_')
    title = [part[0].upper()+part[1:] for part in title]
    title = ' '.join(title)
    window.title(title)
    if screen == 'signup':
        signup_gui(window)
    elif screen == 'login':
        login_gui(window)
    elif screen == 'verify_email':
        verify_email_gui(window, lbl)
    elif screen == 'forgot_password':
        forgot_password_gui(window)
    elif screen == 'reset_password':
        reset_password_gui(window)
    elif screen == 'exchange_key':
        exchange_key_gui(window)
    elif screen == 'custom':
        custom_screen(lbl, window)


def main():
    global key_id
    window = tkinter.Tk()
    # Window settings
    window.geometry(f'100x100')  # To make sure that window doesn't crash if geometry not set later
    window.resizable(False, False)
    window.title('Main window')
    window.configure(background='black')
    # run first screen
    show_screen(window, 'exchange_key', 'my_email.com')
    # Setup key-address
    window.mainloop()
    # Send exit message if THERE WAS A CONNECTION WITH THE SERVER (BY NOW)
    if key_id != '':  # If HAS sent a message to server so far
        msg = b'exit'
        sck = socket.socket()
        sck.connect((server_ip, server_port))
        send_recv_msg.send_msg(b'pake' + key_id.encode(), sck)
        msg_about_key_exchange = send_recv_msg.recv_msg(sck)
        send_recv_msg.send_msg(msg, sck, aes_encryption_key)
    print('Terminating program. Goodbye!')


if __name__ == '__main__':
    main()

