__author__ = 'Ittay Levit'
import socket
import sys


def main(ip, port):
    clnt = socket.socket()
    print('Trying to connect')
    clnt.connect((ip, port))

    while True:
        data = input("Enter data to send: ")
        if data.lower() == 'q':
            print('Disconnected')
            break
        clnt.send(data.encode())
        data = clnt.recv(1024)
        if data == '':
            print('Server disconnected')
            break
        print("Received <<< " + data.decode())
    clnt.close()


if __name__ == '__main__':
    if len(sys.argv) < 3:
        main('127.0.0.1', 12345)
    else:
        main(sys.argv[1], int(sys.argv[2]))
