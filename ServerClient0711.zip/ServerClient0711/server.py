__author__ = 'Ittay Levit'
import socket
import threading


def handle_client(srv, address):
    print(f'Connected by: {address}')
    while True:
        try:
            data = srv.recv(1024)
            if data == b'':
                print("Client disconnected")
                break
            print("Received <<< " + data.decode())
            srv.send(b'GOT: ' + data)
        except ConnectionResetError as e:
            print('Client disconnected')
            break
    srv.close()


def main():
    ip = '0.0.0.0'
    port = 12346
    thread_list = []

    acpt = socket.socket()
    acpt.bind((ip, port))
    print('Server up and running')
    acpt.listen(5)

    while True:
        srv, address = acpt.accept()
        t = threading.Thread(target=handle_client, args=(srv, address))
        t.start()
        thread_list.append(t)


if __name__ == '__main__':
    main()
