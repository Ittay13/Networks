__author__ = 'Ittay_Levit'
import socket
import struct
import traceback
import sys

# Global variables
DNS_SERVER_IP = '127.0.0.1'
DNS_SERVER_PORT = 53  # Default
Default_Recv_Buffer_Size = 1024
website_ip_dict = {
    'www.google.com': '1.2.3.4',
    'www.ynet.co.il': '13.07.20.08',
    'web.mashov.info': '0.255.0.255',
    'www.yossi.com': '33.22.0.46'}
addition_if_sys = ''
if sys.byteorder == 'little':
    addition_if_sys = '!'


# Main loop of DNS server
def udp_server():
    global DNS_SERVER_IP
    global DNS_SERVER_PORT
    global Default_Recv_Buffer_Size
    addr = ''
    # Create socket to recv clients
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # UDP main socket
    server_socket.bind((DNS_SERVER_IP, DNS_SERVER_PORT))
    print('Server up, waiting for clients to connect')
    # After server is up, recv clients
    while True:
        try:
            query, addr = server_socket.recvfrom(Default_Recv_Buffer_Size)
            print('request as bytes:')
            print(query)
            request_dict = parse_request(query)
            print_log(addr, request_to_msg(request_dict), 'DNS REQUEST', 'FROM')
            response_log, response = dns_handler(request_dict)
            print_log(addr, response_log, 'DNS RESPONSE', 'TO')
            print('response as bytes:')
            print(response)
            udp_send(response, addr)
        except Exception:
            print_log(addr, f'Error!\r\n{traceback.print_exc()}', 'ERROR', 'RELATED TO')


# Handle dns request by data
# Returns string representing the answer to send to client and log
# (log, response_to_send)
def dns_handler(request_dict):
    global website_ip_dict
    request_dict['Domain Name'] = request_dict['Domain Name'].encode()
    response_dict = {'ID': request_dict['ID'],     # Dictionary with data for msg to return
                     'QRRC': request_dict['QRRC'],
                     'AnRRC': 1,
                     'AuRRC': 0,
                     'AdRRC': 0,
                     'Type': 1,
                     'Class': 1,          # 0h12C seconds (300sec - 5 minutes)
                     'TTL': 300,
                     'FLAGS': 0,
                     'Domain Name': 0,
                     'IP Length': '',
                     'IP': ''}
    if request_dict['Domain Name'].decode() in website_ip_dict.keys():   # If Domain Name is known
        ip = website_ip_dict[request_dict['Domain Name'].decode()]
        response_dict['IP'] = ip
        response_dict['FLAGS'] = 33152                                 # \x81\x80
        response_dict['Domain Name'] = parse_number_to_network(49164)  # \xc0\x0c
        response_dict['IP Length'] = len(ip.split('.'))
    else:
        ip = ''          # Empty IP
        response_dict['FLAGS'] = 33155  # \x81\x83
        response_dict['AnRRC'] = 0
        response_dict['Domain Name'] = request_dict['Domain Name']

    # Make log of response
    response_log = 'ID: ' + str(response_dict['ID']) + '\r\n'
    response_log += 'Flags: ' + str(response_dict['FLAGS']) + '\r\n'
    response_log += 'QRRC: ' + str(response_dict['QRRC']) + '\r\n'
    response_log += 'AnRRC: ' + str(response_dict['AnRRC']) + '\r\n'
    response_log += 'AuRRC: ' + str(response_dict['AuRRC']) + '\r\n'
    response_log += 'AdRRC: ' + str(response_dict['AdRRC']) + '\r\n'
    response_log += 'Domain Name (request): ' + str(request_dict['Domain Name'].decode()) + '\r\n'
    response_log += 'Type: ' + str(request_dict['Type']) + '\r\n'
    response_log += 'Class: ' + str(request_dict['Class']) + '\r\n'
    response_log += 'Domain Name (response): ' + str(response_dict['Domain Name']) + '\r\n'
    response_log += 'Type: ' + str(response_dict['Type']) + '\r\n'
    response_log += 'Class: ' + str(response_dict['Class']) + '\r\n'
    response_log += 'TTL: ' + str(response_dict['TTL']) + '\r\n'
    response_log += 'IP Length: ' + str(response_dict['IP Length']) + '\r\n'
    response_log += 'IP: ' + str(response_dict['IP']) + '\r\n'

    # HEADER block
    header_block = b''
    header_block += parse_number_to_network(response_dict['ID'], 2)
    header_block += parse_number_to_network(response_dict['FLAGS'], 2)
    header_block += parse_number_to_network(response_dict['QRRC'], 2)
    header_block += parse_number_to_network(response_dict['AnRRC'], 2)
    header_block += parse_number_to_network(response_dict['AuRRC'], 2)
    header_block += parse_number_to_network(response_dict['AdRRC'], 2)
    # QUESTION block
    question_block = b''
    domain_fields = request_dict['Domain Name'].split(b'.')
    for field in domain_fields:
        question_block += parse_number_to_network(len(field))
        question_block += field
    question_block += b'\x00'
    question_block += parse_number_to_network(request_dict['Type'], 2)
    question_block += parse_number_to_network(request_dict['Class'], 2)
    # ANSWER block
    answer_block = b''
    answer_block += response_dict['Domain Name']
    answer_block += parse_number_to_network(response_dict['Type'], 2)
    answer_block += parse_number_to_network(response_dict['Class'], 2)
    answer_block += parse_number_to_network(response_dict['TTL'], 4)
    if response_dict['IP Length'] != '':
        answer_block += parse_number_to_network(response_dict['IP Length'], 1)
        ip_fields = response_dict['IP'].split('.')
        for part in ip_fields:
            answer_block += parse_number_to_network(int(part), 1)
    # FINAL RESPONSE
    response = header_block + question_block + answer_block
    return response_log, response


# Parse the data into dictionary
# Returns dictionary with data
def parse_request(data):
    dc = {}
    header = data[:12]
    query = data[12:]
    dc['ID'] = parse_number_from_network(header[:2])
    dc['Flags'] = parse_number_from_network(header[2:4])
    dc['QRRC'] = parse_number_from_network(header[4:6])
    dc['AnRRC'] = parse_number_from_network(header[6:8])
    dc['AuRRC'] = parse_number_from_network(header[8:10])
    dc['AdRRC'] = parse_number_from_network(header[10:12])
    domain_name_bytes = query.split(b'\x00', 1)[0]
    dc['Domain Name'] = ''
    while len(domain_name_bytes) > 0:
        size_of_part = parse_number_from_network(domain_name_bytes[0:1])  # Works like this (and not like this: dnb[0])
        dc['Domain Name'] += (domain_name_bytes[1:size_of_part+1]).decode() + '.'
        domain_name_bytes = domain_name_bytes[size_of_part+1:]
    dc['Domain Name'] = dc['Domain Name'][:len(dc['Domain Name'])-1]
    dc['Type'] = parse_number_from_network(query[len(query)-4:len(query)-2])
    dc['Class'] = parse_number_from_network(query[len(query)-2:len(query)])
    return dc


# Parses request to msg to print
def request_to_msg(request_dict):
    line = '\r\n'
    msg = 'ID: ' + str(request_dict['ID']) + line
    msg += 'Flags: ' + str(request_dict['Flags']) + line
    msg += 'QRRC: ' + str(request_dict['QRRC']) + line
    msg += 'AnRRC: ' + str(request_dict['AnRRC']) + line
    msg += 'AuRRC: ' + str(request_dict['AuRRC']) + line
    msg += 'AdRRC: ' + str(request_dict['AdRRC']) + line
    msg += 'Domain: ' + str(request_dict['Domain Name']) + line
    msg += 'q_type: ' + str(request_dict['Type']) + line
    msg += 'q_class: ' + str(request_dict['Class']) + line
    return msg


# Parses request to msg to print
def response_to_msg(request_dict):
    line = '\r\n'
    msg = 'ID: ' + str(request_dict['ID']) + line
    msg += 'Flags: ' + str(request_dict['Flags']) + line
    msg += 'QRRC: ' + str(request_dict['QRRC']) + line
    msg += 'AnRRC: ' + str(request_dict['AnRRC']) + line
    msg += 'AuRRC: ' + str(request_dict['AuRRC']) + line
    msg += 'AdRRC: ' + str(request_dict['AdRRC']) + line
    msg += 'Domain: ' + str(request_dict['Domain Name']) + line
    msg += 'q_type: ' + str(request_dict['Type']) + line
    msg += 'q_class: ' + str(request_dict['Class']) + line
    return msg


# Gets binary number (as num) and returns the number after parsing
# The parsing is to the correct endian and uses STRUCT module
def parse_number_from_network(number):
    global addition_if_sys
    size = 'H'      # size for 2 bytes
    if len(number) == 4:
        size = 'I'  # size for 4 bytes
    if len(number) == 1:
        size = 'B'  # size for 1 byte
    return struct.unpack(addition_if_sys+size, number)[0]


# Gets number (as int) and returns the number as bytes
# The parsing is to the internet default's endian and with STRUCT module
def parse_number_to_network(number, size=-1):
    global addition_if_sys
    if size != -1:

        if size == 2:
            size = 'H'
        elif size == 4:
            size = 'I'
        elif size == 1:
            size = 'B'
        return struct.pack(addition_if_sys+size, number)
    size = 'H'      # size for 2 bytes
    if number > 65536:
        size = 'I'  # size for 4 bytes
    elif number < 256:  # size for 1 byte
        size = 'B'
    return struct.pack(addition_if_sys+size, number)


# Sends data to addr
# data is a string, addr is a tuple (ip, port)
def udp_send(data, addr):
    if type(data) is not bytes:
        data = bytes(data)
    sck = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sck.sendto(data, addr)


# Prints message (with address)
# method = 'DNS REQUEST' / 'DNS RESPONSE' / 'ERROR'
# direction = 'FROM / TO' / 'RELATED TO'
def print_log(address, msg, method, direction):
    print(f'MESSAGE {direction}: {str(address[0])}:{str(address[1])}\r\n{method}:\r\n{str(msg)}')


def main():
    udp_server()


if __name__ == '__main__':
    main()
