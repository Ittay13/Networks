__author__ = 'Ittay_Levit'

from scapy.all import *

ip = '0.0.0.0'
port = 50

def is_open(ip, port):
	syn_segment = TCP(dport=port, sport=5555, seq=777, flags='S')
	syn_packet = IP(dst=ip)/syn_segment
	# syn_packet.show()
	syn_ack_packet = sr1(syn_packet, verbose=False, timeout=2)
	# syn_ack_packet.show()
	# print(syn_ack_packet[TCP].flags)
	if syn_ack_packet is not None and TCP in syn_ack_packet and syn_ack_packet[TCP].flags == 'SA':
		return True
	return False


def main():
	ip = input('Enter IP: ')
	parts = ip.split('.')
	if len(parts) != 4:
		print('Incorrect IP!')
		return
	for i in parts:
		try:
			if 0 > int(i) or int(i) > 255:
				print('Incorrect IP!')
				return
		except Exception as err:
			print('Incorrect IP!')
			return
	for port in range(24, 1024):
		if is_open(ip, port):
			print('Open port: ' + str(port))
		# else:
			# print('Bad port: ' + str(port))


main()