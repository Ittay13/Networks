__author__ = 'Ittay_Levit'

import AsyncMessages as AsyncNessagesFile
import tcp_by_size
import threading
import socket


# Global variables
server_ip = '0.0.0.0'
server_port = 1307
max_listen_users = 10  # Maximum number of users who can connect at once
keep_server_alive = True
thread_list = []
amount_to_recv = 64 * 1024
async_msg_platform = AsyncNessagesFile.AsyncMessages()
fields_sprt = b'\x18'


# Handles client request
# Builds msg and puts in async_msg_platform
def handle_request(data, username):
    global async_msg_platform
    data = data[8:]   # Get rid of size header
    cmd = data[4:]    # Command
    data = data[4:]
    if data == b'':
        return False
    if cmd == b'snda':    # Send messaage to everyone
        async_msg_platform.put_msg_to_all(b'rcva'+fields_sprt+username+fields_sprt+data)
    elif cmd == b'sndp':
        fields = data.split(fields_sprt, 1)
        async_msg_platform.put_msg_by_user(b'rcvp'+fields_sprt+fields[0]+fields_sprt+fields[1], fields[0])
    return True


def handle_client(sck):
    sck = sck[0]
    global async_msg_platform
    async_msg_platform.add_new_socket(sck)
    client_to_die = False
    # Loop until user signed up
    while True:
        data = tcp_by_size.recv_by_size(sck)
        data = data[8:]   # Get rid of size header
        if data[4:] == b'sgnp':
            break
    username = data[4:]
    async_msg_platform.sock_by_user[username] = sck
    s = username + b' has entered the chat!'
    async_msg_platform.put_msg_to_all(s)
    while not client_to_die:
        data = tcp_by_size.recv_by_size(sck)
        client_to_die = handle_request(data, username)
    s = username + b' has disconnected.'
    async_msg_platform.put_msg_to_all(s)


def main():
    global keep_server_alive
    global thread_list
    main_sck = socket.socket()
    main_sck.bind((server_ip, server_port))
    print(f'Server up ({server_ip}:{str(server_port)}), waiting for clients to connect')
    main_sck.listen(max_listen_users)
    while keep_server_alive:
        sck = main_sck.accept()
        t = threading.Thread(target=handle_client, args=(sck,))
        thread_list.append(t)
        t.start()
    for t in thread_list:
        t.join()


if __name__ == '__main__':
    main()
