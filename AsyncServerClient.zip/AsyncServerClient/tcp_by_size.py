SIZE_HEADER_FORMAT = b"00000000" b'\x18'     # n digits for data size + one seperator
size_header_size = len(SIZE_HEADER_FORMAT)  # Size of header


# Returns sent message [as bytes]
def recv_by_size(sock):
    size_header = b''
    data_len = 0
    while len(size_header) < size_header_size:
        _s = sock.recv(size_header_size - len(size_header))
        if _s is None:
            size_header = b''
            break
        size_header += _s
    # Now, the size header field has entirely received in size_header (which is binary).
    data = b''
    if size_header != b"":
        data_len = int(size_header[:size_header_size - 1])
        while len(data) < data_len:
            _d = sock.recv(data_len - len(data))
            if _d is None:
                data = b""
                break
            data += _d
    if data_len != len(data):
        data = b""  # Partial data is like no data !
    return str(len(data)).zfill(size_header_size - 1).encode() + b"\x18" + data


# Sends message
def send_with_size(sock, bdata):
    len_data = len(bdata)
    header_data = str(len(bdata)).zfill(size_header_size - 1).encode() + b"\x18"
    if type(bdata) is not bytes:
        bdata = bdata.encode()
    bytea = header_data + bdata
    sock.send(bytea)
