__author__ = 'Ittay_Levit'
import socket
# import threading
import tcp_by_size

# Global variables
server_ip = '127.0.0.1'
server_port = 1307
fields_sprt = b'\x18'


def main():
    sck = socket.socket()
    sck.connect((server_ip, server_port))
    while True:
        s = input('Enter username: ')
        if s != '':
            break
    tcp_by_size.send_with_size(sck, b'sgnp'+fields_sprt+s.encode())
    print('To send data privately write <private-username> msg here.\r\n'
          'Otherwise write freely the message to send.')
    while True:
        s = input('Write message to send:')
        if s[:8] == '<private' and '>' in s:  # If to send privately
            fields = s[9:].split('>')
            user_to = fields[0]
            msg = fields[1][1:]
            tcp_by_size.send_with_size(sck, b'sndp'+fields_sprt+user_to.encode()+fields_sprt+msg.encode())
        else:                                 # If to send publicly
            tcp_by_size.send_with_size(sck, b'snda'+fields_sprt+s.encode())
        data = tcp_by_size.recv_by_size(sck)
        print(data)


if __name__ == '__main__':
    main()
