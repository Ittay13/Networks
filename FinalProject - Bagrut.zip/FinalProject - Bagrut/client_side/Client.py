import pygame
import socket
import select

import gsc_client
import send_recv_msg
import pickle
import os

'''GLOBAL VARIABLES'''
server_ip = '10.100.102.3'
server_port = 1301
current_screen = ''
sck = None
finish_program = False
game_manager = None
screen_obj = None
resources_path = os.getcwd() + "\\resources\\"
screen_width = 1000   # Pixels
screen_length = 1000  # Pixels
aes_encryption_key = b''  # gsc
key_id = ''               # gsc


# The purpose of the class is to manage the game from the client side
class ManageGame:

	# TEMP VARIABLES
	color_palette = {0: (255, 255, 255),  # FREE SPACE color
					# Conquered, Trail, Player
					1: (0, 76, 153), 2: (51, 153, 255), 3: (30, 30, 255),              # Blue
					4: (204, 0, 0), 5: (255, 102, 102), 6: (255, 30, 30),              # Red
					7: (50, 139, 50), 8: (110, 209, 110), 9: (18, 90, 18),             # Green
						10: (238, 255, 74), 11: (248, 255, 173), 12: (255, 255, 0)}    # Yellow

	# Variables - 2 underscore before the variable's name (__):
	# The variable will be called so: object.Game__variable | [variable is the variable's name]
	#    Instance variables
	# __player_name         # string representing the player's name                      [STRING]
	# __board_length        # Length of board (in tiles)                                 [INT]
	# __board_width         # Width of board  (in tiles)                                 [INT]
	# __is_player_alive     # Bool representing if player is still alive                 [BOOL]
	# __tile_size           # int representing width/length (same) of a single tile      [INT]
	# __game_alive          # bool representing if the game is alive                     [BOOL]

	# Receives args_dc - a dictionary containing the arguments for the function
	def __init__(self, args_dc):
		self.__player_name = args_dc['player_name']
		self.__board_length = args_dc['board_length']
		self.__board_width = args_dc['board_width']
		self.__is_player_alive = True
		self.__tile_size = 20
		self.__game_alive = False

	# game_alive
	@property
	def game_alive(self):
		return self.__game_alive

	@game_alive.setter
	def game_alive(self, new_game_alive):
		self.__game_alive = new_game_alive

	# board
	# Draws board - UPDATES SCREEN (FLIP) IN ORDER TO SEE VISUALS
	def draw_board(self, board_matrix, screen_obj_a):
		for y in range(self.__board_length):
			for x in range(self.__board_width):
				index = self.get_index_to_board((x, y))
				pygame.draw.rect(screen_obj_a, ManageGame.color_palette[board_matrix[index]],
					pygame.Rect(x*self.__tile_size, y*self.__tile_size, self.__tile_size, self.__tile_size))
		pygame.display.flip()  # Updates graphics

	# Receives a dictionary with the following format: (x, y) as KEY and number (int) as VALUE and draws tile
	def draw_tiles_in_location(self, board_dict, screen_obj_a):
		for pos in board_dict:
			pygame.draw.rect(screen_obj_a, ManageGame.color_palette[board_dict[pos]],
							pygame.Rect(pos[0] * self.__tile_size, pos[1] * self.__tile_size, self.__tile_size,
							self.__tile_size))
		pygame.display.flip()  # Updates graphics

	# The function that controls the home screen
	def home_screen(self, screen_obj_a):
		global current_screen
		global finish_program
		current_screen = 'Home'
		pygame.display.set_caption('HOME SCREEN')
		ManageGame.draw_home_screen(screen_obj_a)
		while not finish_program:
			for event in pygame.event.get():
				mouse_pos = self.handle_event(event)
				if mouse_pos is not None:
					print(mouse_pos)
					x = mouse_pos[0]
					y = mouse_pos[1]
					if 196 <= x <= 780 and 373 <= y <= 527:  # Enter Game button
						self.in_game(screen_obj_a)
						return True  # (continues program)
					elif 297 <= x <= 719 and 551 <= y <= 706:  # Tutorial button
						self.tutorial_screen(screen_obj_a)
						return True  # (continues program)
					elif 363 <= x <= 613 and 728 <= y <= 882:  # Exit button
						self.end_screen(screen_obj_a)
						return False  # (terminates program)

	@staticmethod
	# Home screen - first screen to show to player
	def draw_home_screen(screen_obj_a):
		img = pygame.image.load(resources_path + 'home_screen.png')
		screen_obj_a.blit(img, (0, 0))
		pygame.display.flip()
		return

	# The function that controls the tutorial screen
	def tutorial_screen(self, screen_obj_a):
		global finish_program
		global current_screen
		current_screen = 'Tutorial'
		pygame.display.set_caption('TUTORIAL SCREEN')
		ManageGame.draw_tutorial_screen(screen_obj_a)
		leave_tutorial = False
		while not (finish_program or leave_tutorial):
			for event in pygame.event.get():
				leave_tutorial = self.handle_event(event)
				if leave_tutorial or finish_program:
					break
		return

	@staticmethod
	# Home screen - first screen to show to player
	def draw_tutorial_screen(screen_obj_a):
		img = pygame.image.load(resources_path + 'tutorial_screen.png')
		screen_obj_a.blit(img, (0, 0))
		pygame.display.flip()
		return

	# The function that controls the dead screen
	def dead_screen(self, screen_obj_a, won):
		global current_screen
		current_screen = 'Dead'
		pygame.display.set_caption('DEAD SCREEN')
		ManageGame.draw_dead_screen(screen_obj_a, won)
		leave_dead_screen = False
		while not (finish_program or leave_dead_screen):
			for event in pygame.event.get():
				leave_dead_screen = self.handle_event(event)
				if leave_dead_screen or finish_program:
					break
		return

	@staticmethod
	# Dead screen - show when player dies
	def draw_dead_screen(screen_obj_a, won):
		screenshot = screen_obj_a.copy()  # Snapshot of current screen
		screenshot = screenshot.convert_alpha()
		screenshot.set_alpha(128)  # Set opacity (transparency)
		screenshot = ManageGame.blur_surface(screenshot)
		# Show blurred screenshot
		screen_obj_a.blit(screenshot, (0, 0))
		# Show writing-image
		if won:
			img = pygame.image.load(resources_path + 'game_over_won_transparent.png')
		else:
			img = pygame.image.load(resources_path + 'game_over_lost_transparent.png')
		screen_obj_a.blit(img, (0, 0))
		pygame.display.flip()
		return

	# The function that controls the end screen
	def end_screen(self, screen_obj_a):
		global current_screen
		global finish_program
		current_screen = 'End'
		pygame.display.set_caption('END SCREEN')
		ManageGame.draw_end_screen(screen_obj_a)
		leave_end_screen = False
		while not (finish_program or leave_end_screen):
			for event in pygame.event.get():
				leave_end_screen = self.handle_event(event)
				if leave_end_screen or finish_program:
					break
		return

	@staticmethod
	# End screen - last screen to show to player
	def draw_end_screen(screen_obj_a):
		img = pygame.image.load(resources_path + 'goodbye_screen.png')
		screen_obj_a.blit(img, (0, 0))
		pygame.display.flip()
		return

	# The function that controls the waiting room screen
	def waiting_room(self, screen_obj_a):
		global current_screen
		global finish_program
		global sck
		current_screen = 'WaitingRoom'
		pygame.display.set_caption('Waiting Room')
		ManageGame.draw_waiting_room_screen(screen_obj_a)
		leave_waiting_room = False
		while not (finish_program or leave_waiting_room):
			for event in pygame.event.get():
				self.handle_event(event)
				if leave_waiting_room or finish_program:
					break
				ready_to_read, _, _ = select.select([sck], [], [], 0)
				if sck in ready_to_read:
					print('ready to recv in waiting room')
					msg = send_recv_msg.recv_msg(sck, aes_encryption_key)
					if msg == b'lrom':
						leave_waiting_room = True
		return

	@staticmethod
	# Waiting room screen - the screen to show to player before game starts
	def draw_waiting_room_screen(screen_obj_a):
		img = pygame.image.load(resources_path + 'waiting_room_screen.png')
		screen_obj_a.blit(img, (0, 0))
		pygame.display.flip()
		return

	@staticmethod
	# Draws a white screen
	def draw_white_screen(screen_obj_a):
		global screen_width
		global screen_length
		pygame.draw.rect(screen_obj_a, (255, 255, 255), pygame.Rect(0, 0, screen_width, screen_length))
		pygame.display.flip()  # Updates screen background color

	# The function that controls the game itself with the server
	def in_game(self, screen_obj_a):
		try:
			global sck
			global game_manager
			global finish_program
			global current_screen
			global aes_encryption_key
			global key_id
			run_gsc_client_give_server_keyid(key_id)  # So server knows how to encrypt and decrypt messages
			msg_from_server = b''
			ready_to_read, _, _ = select.select([sck], [], [])
			if sck in ready_to_read:
				print('ready to recv waiting room msg')
				msg_from_server = send_recv_msg.recv_msg(sck, aes_encryption_key)
			if msg_from_server == b'wrom':  # If need to go to waiting room
				self.waiting_room(screen_obj_a)   # Go to waiting room
			# After waiting room
			self.draw_white_screen(screen_obj_a)  # DRAW BLANK SCREEN
			self.game_alive = True
			current_screen = 'InGame'
			pygame.display.set_caption('GAME')
			print('Connected to server')
			while self.game_alive and (not finish_program):
				for event in pygame.event.get():
					self.handle_event(event)
				# If not ready to read - doesn't need to refresh the screen
				# There is a timeout so program will be non-blocking
				ready_to_read, _, _ = select.select([sck], [], [], 0)
				if sck in ready_to_read:
					print('ready to recv')
					msg_from_server = send_recv_msg.recv_msg(sck, aes_encryption_key)
					self.handle_msg_from_server(msg_from_server)
			return
		except Exception as err:
			print('Error! ' + str(err))
			return

	@staticmethod
	# Returns a blurred surface
	# Scale factor --> 0 ==> the more blurred
	def blur_surface(screen_obj_a, scale_factor=2):
		# Downscale
		small_size = (max(1, int(screen_obj_a.get_width() * scale_factor)),
					  max(1, int(screen_obj_a.get_height() * scale_factor)))
		small_surface = pygame.transform.smoothscale(screen_obj_a, small_size)

		# Upscale back to original
		return pygame.transform.smoothscale(small_surface, screen_obj_a.get_size())

	# Draws tile - DOESN'T UPDATE SCREEN
	def draw_tile(self, board_matrix, x, y, screen_obj_a):
		index = self.get_index_to_board((x, y))
		pygame.draw.rect(screen_obj_a, ManageGame.color_palette[board_matrix[index]],
			pygame.Rect(x * self.__tile_size, y * self.__tile_size, self.__tile_size, self.__tile_size))

	# Receives location (x, y) and returns index in board
	def get_index_to_board(self, location):
		return location[0]+location[1]*self.__board_length

	# board_length
	@property
	def board_length(self):
		return self.__board_length

	# board_width
	@property
	def board_width(self):
		return self.__board_width

	# Receives as argument the event and handles it
	def handle_in_game_event(self, event):
		global sck
		msg = b''
		send_msg = False

		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_LEFT:  # Left arrow
				msg = b'movd\nleft'
				send_msg = True
			elif event.key == pygame.K_RIGHT:  # Right arrow
				msg = b'movd\nright'
				send_msg = True
			elif event.key == pygame.K_UP:  # Up arrow
				msg = b'movd\nup'
				send_msg = True
			elif event.key == pygame.K_DOWN:  # Down arrow
				msg = b'movd\ndown'
				send_msg = True
		if send_msg:        # If event requires something to send to server
			send_recv_msg.send_msg(msg, sck, aes_encryption_key)

	# Returns mouse pos if mouse button is pressed (otherwise returns None)
	def handle_home_screen_event(self, event):
		if event.type == pygame.MOUSEBUTTONDOWN:
			return pygame.mouse.get_pos()
		return None

	# Returns if escape key is pressed
	def handle_tutorial_screen_event(self, event):
		if event.type == pygame.KEYDOWN:  # If a key is pressed
			if event.key == pygame.K_ESCAPE:  # escape key
				return True
		return False

	# Returns if any key is pressed
	def handle_dead_screen_event(self, event):
		if event.type == pygame.KEYDOWN:  # If a key is pressed
			return True
		return False

	# Returns if any key is pressed
	def handle_end_screen_event(self, event):
		if event.type == pygame.KEYDOWN:  # If a key is pressed
			return True
		return False

	# Returns if need to stay in waiting room
	def handle_waiting_room_screen_event(self, event):
		global sck
		if event.type == pygame.KEYDOWN:  # If a key is pressed
			if event.key == pygame.K_SPACE:  # spacebar key
				# Send to server
				msg = b'sgam'
				send_recv_msg.send_msg(msg, sck, aes_encryption_key)

	# Receives as argument the event and handles it
	# Sends event to sub-function depends on the current screen
	def handle_event(self, event):
		global finish_program
		global current_screen
		if event.type == pygame.QUIT:
			finish_program = True
			print('exited with pygame.QUIT')
			return None
		if current_screen == 'InGame':
			return self.handle_in_game_event(event)
		elif current_screen == 'Home':
			return self.handle_home_screen_event(event)
		elif current_screen == 'Tutorial':
			return self.handle_tutorial_screen_event(event)
		elif current_screen == 'Dead':
			return self.handle_dead_screen_event(event)
		elif current_screen == 'End':
			return self.handle_end_screen_event(event)
		elif current_screen == 'WaitingRoom':
			self.handle_waiting_room_screen_event(event)

		return None

	# Handles a single message from server
	def handle_msg_from_server(self, msg):
		global screen_obj
		if msg == b'':  # If message from server is empty
			game_manager.game_alive = False
			return
		# Do something about it
		else:
			fields = msg.split(b'\n')
			msg_code = fields[0]
			if msg_code == b'brdg':
				print('Received graphics')
				board_pickle = b'\n'.join(fields[1:])
				board = pickle.loads(board_pickle)
				self.draw_tiles_in_location(board, screen_obj)
			elif msg_code == b'lser':
				print('I lost!')
				self.dead_screen(screen_obj, False)
				self.game_alive = False
			elif msg_code == b'wner':
				print('I won!')
				self.dead_screen(screen_obj, True)
				self.game_alive = False
			elif msg_code == b'eror':
				print('Error from server! ' + fields[1].decode())


# Returns key-id and aes encryption-key
def run_gsc_client_get_keyid():
	global server_ip
	global server_port
	global sck
	# Run gsc (graphic server client) program
	response = gsc_client.final_project_run()  # Returns tuple (id [bytes], key [encryption_key])
	return response


# Receives key-id to send to server
# Run when starting each game (in the 'InGame' section)
def run_gsc_client_give_server_keyid(key_id):
	global sck
	sck = socket.socket()
	sck.connect((server_ip, server_port))
	send_recv_msg.send_msg(key_id.encode(), sck)
	return


def main_program():
	global screen_obj
	global game_manager
	global finish_program
	global screen_width
	global screen_length
	global aes_encryption_key
	global key_id

	tup = run_gsc_client_get_keyid()
	if tup is not False:
		key_id, aes_encryption_key = tup
		pygame.init()
		size = (screen_width, screen_length)
		background_colour = (96, 96, 96)
		screen = pygame.display.set_mode(size)  # Initialize the screen
		screen.fill(background_colour)
		pygame.display.flip()  # Updates screen background color
		clock = pygame.time.Clock()
		clock.tick(60)  # limit to 60 fps
		screen_obj = screen
		print('Game screen is up')
		dc = {'player_name': 'MyplayerName', 'board_length': 50, 'board_width': 50}
		game_manager = ManageGame(dc)
		cont = True
		while cont and (not finish_program):
			cont = game_manager.home_screen(screen_obj)  # Start with home screen - the rest will happen from there
		pygame.quit()
	else:  # If has no key - don't run the rest of the program
		print('Has no key.')
	print('Exit game. Goodbye!')


if __name__ == '__main__':
	main_program()
