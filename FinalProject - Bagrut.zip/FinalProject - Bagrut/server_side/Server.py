import threading
import socket

import send_recv_msg
import pickle
import time
import random
import select
import pygame
from collections import deque
import subprocess  # To run gsc_server

'''GLOBAL VARIABLES'''
server_ip = '10.100.102.3'
server_port = 1301
gsc_server_port = 13074
error_dict = {b'001': b'One or more empty fields',
			  b'002': b'Illegal command',
			  b'601': b'Direction is illegal!'}
thread_list = []
thread_list_lock = threading.Lock()
games_list = []
games_list_lock = threading.Lock()
server_alive = True
max_people_to_listen_at_once = 5


# The purpose of the class is to manage a single GAME LOBBY
class Game:
	# Variables - 2 underscore before the variable's name (__):
	#    Class variables
	__board_length =          50   # Length of board (in tiles)
	__board_width =           50   # Width of board  (in tiles)
	max_number_of_players = 4      # Maximum number of players allowed in a single lobby

	# The variable will be called so: object.Game__variable | [variable is the variable's name]
	#    Instance variables
	# __players_dict    = dictionary with player's object [KEY] and their colors' tuple (Conquered, Trail, Player)
	# as [VALUE] [DICT]
	# __color_counter   = Counter for next player's color
	# __board           = dictionary containing all the board's points (key)
	# __is_game_alive   = bool representing if game is still alive (not over) [BOOLEAN]
	# __color_palette   = dictionary with KEY (0-12 representing color) and VALUE (RGB tuple color) [DICT]
	# __in_waiting_room = bool representing if currently in waiting room [BOOLEAN]

	def __init__(self):
		self.__players_dict = {}
		self.__players_dict_lock = threading.Lock()
		self.__board = Game.get_new_board()
		self.__is_game_alive = True
		self.__color_palette = {}
		self.__color_counter = 1
		self.__in_waiting_room = True

	# players_dict
	# Adds new player to game(if free plac), sets random location on board and draws 3*3 conquered block besides
	# Returns bool if succeeded joining player to game
	def add_new_player(self, player):  # Appends new player to players_list
		self.__players_dict_lock.acquire()
		self.__players_dict[player] = (self.__color_counter, self.__color_counter+1, self.__color_counter+2)
		self.__color_counter += 3
		r = self.generate_draw_place_for_player(player, 1)  # Draw conquered area of player
		if r is not None:  # If free place
			player.location = r
			if r[0] > self.__board_width // 2:  # If in the right part of the screen
				if r[1] < self.__board_length // 2:      # If in the upper part of the screen
					player.change_direction('down')
				else:                    	        	 # If in the lower part of the screen
					player.change_direction('up')
			if not self.__in_waiting_room:
				player.send_to_player(b'lrom')
				# Send board to player (full board)
				b = self.get_full_board_to_send()
				player.send_to_player(b)
			else:
				player.send_to_player(b'wrom')
		else:
			self.__players_dict.pop(player)  # If no free place - remove player from game
			return False
		self.__players_dict_lock.release()
		return True

	# Removes player from dict and from board (all of his points will be free)
	def remove_player(self, pl):  # Checks if player is in players_dict -> if so removes player from it
		self.__players_dict_lock.acquire()
		if Game.is_in_players_dict(self, pl):
			# Remove from board
			for point in self.__board.values():
				if point.player == pl:  # If point belongs to removed player
					if point.is_trail() or point.is_player_on_point():
						if point.is_player_on_point():  # For debuG
							pass  # For debug
						# If point is trail or player itself - may be on player's conquered area (can't free it)
						point.type = point.was_before_type
						point.player = point.was_before_player
					else:
						point.free_point()  # Free it
					point.turn_on_modified_lately()
			# Send to player that he lost
			self.send_loser_msg(pl)
			# Remove from user dict
			self.__players_dict.pop(pl)
		self.__players_dict_lock.release()

	# DOESN'T USE DICT.LOCK() !
	def is_in_players_dict(self, player):  # Returns if player is in players_dict
		return player in self.__players_dict.keys()

	# Returns current number of players
	def number_of_players(self):
		self.__players_dict_lock.acquire()
		length = len(self.__players_dict)
		self.__players_dict_lock.release()
		return length

	@property
	def players_dict(self):
		return self.__players_dict

	@property
	def players_dict_lock(self):
		return self.__players_dict_lock

	@property
	def in_waiting_room(self):
		return self.__in_waiting_room

	@in_waiting_room.setter
	def in_waiting_room(self, new_in_waiting_room):
		self.__in_waiting_room = new_in_waiting_room

	# board
	@classmethod  # Needs Game class in order to work, doesn't need an instance
	def get_new_board(cls):  # Returns a new board
		dc = {}
		for y in range(Game.__board_length):
			for x in range(Game.__board_width):
				index = Game.location_to_board_index([x, y])
				dc[index] = Point()
				dc[index].turn_on_modified_lately()
		return dc

	@property
	def board(self):
		return self.__board

	# Checks if can draw 3 * 3 block [CONQUERED] besides player's pos - if so it does it
	# Returns location [x, y] for new player to spawn at
	# If no place returns None
	def generate_draw_place_for_player(self, player, type):
			x_s = random.randint(0, Game.__board_width-4)   # Starting x
			y_s = random.randint(0, Game.__board_length-4)  # Starting y
			for x in range(x_s, Game.__board_width+x_s-3):
				for y in range(y_s, Game.__board_length+y_s-3):
					x = x % Game.__board_width
					y = y % Game.__board_length
					# Check if rectangle 3*3 is free (x, y - top left point)
					if (self.is_block_free(3, 3, x, y) and
							self.__board[self.location_to_board_index([x+3, y+1])].is_free()):
						# Draw block
						self.draw_block(3, 3, x, y, player, type)
						index = self.location_to_board_index([x+3, y+1])
						pnt = self.__board[index]
						pnt.set_pre_type(pnt.type)  # Save pre type (this is trail)
						pnt.set_pre_player(pnt.player)  # Save pre player (this is player)
						# Return pos for spawn
						return [x+3, y+1]
			return None

	# Draws block in board (of width, length) given the top left pos (pos as list)
	# DOESN'T CHECK IF LINE IS FREE
	# DOESN'T USE board.LOCK()!
	def draw_block(self, width, length, x_left_top, y_left_top, point_player, point_type):
		for i in range(0, length):
			self.draw_line(width, x_left_top, y_left_top+i, point_player, point_type)

	# Draws line of width in [x_pos, y_pos] in self.__board
	# DOESN'T CHECK IF LINE IS FREE
	# DOESN'T USE board.LOCK()!
	def draw_line(self, width, x_pos, y_pos, point_player, point_type):
		for i in range(0, width):
			index = self.location_to_board_index([x_pos+i, y_pos])
			self.__board[index].type = point_type
			self.__board[index].player = point_player
			self.__board[index].turn_on_modified_lately()

	# Returns if block is free in board (of width, length) given the top left pos (pos as list)
	def is_block_free(self, width, length, x_left_top, y_left_top):
		for i in range(0, length):
			if y_left_top + i >= self.__board_length:  # If out of border
				return False
			if not self.is_line_free(width, x_left_top, y_left_top+i):  # If line is not free
				return False
		return True

	# Returns if a line of width in [x_pos, y_pos] is free in self.__board
	def is_line_free(self, width, x_pos, y_pos):
		for i in range(0, width):
			if x_pos + i >= self.__board_width:  # If out of border
				return False
			if not self.__board[self.location_to_board_index([x_pos+i, y_pos])].is_free():  # If not free
				return False
		return True

	@staticmethod
	# Receives location (list) and returns board's index version
	def location_to_board_index(location):
		return str(location)

	# DOESN'T USE board.LOCK() !
	# Returns pos of point (x, y) from board
	# If there is no pos (point doesn't exist) returns None
	def get_location_of_point(self, point):
		for key in self.__board.keys():
			if self.__board[key] == point:
				return key
		return None

	# Kills (removes from players dict) every player that there is a player currently on their trail
	# Receives list of player to pity and to not kill
	def kill_players_trail_on(self, met_border_players_list):
		remove_me_player_list = []
		self.__players_dict_lock.acquire()
		for player in self.__players_dict:
			index = self.location_to_board_index(player.location)
			if self.__board[index].is_trail():  # If player on trail point
				if player in met_border_players_list and self.__board[index].player == player:
					# If on own trail and it's because met border (stayed on same point)
					continue
				remove_me_player_list.append(self.__board[index].player)  # Add trail's player to remove_me list
		self.__players_dict_lock.release()
		for player in remove_me_player_list:  # Kill every player that there is someone on their trail
			player.kill_player()
			self.remove_player(player)

	# Moves each player in players_dict
	# KILLS PLAYERS THAT THERE IS SOMEONE ON THEIR TRAIL (calls kill_players_on_trail())
	# Conquers area for player (if can)
	def move_players_kill_trail_on_conquer_area(self):
		players_pre_pos = {}  # Dict. Player = Key, (PreviousPos, PreviousType) = Value
		met_border_players_list = []  # List of players that met the border while moving (stuck in the place)
		self.__players_dict_lock.acquire()
		for p in self.__players_dict:
			# DEBUG
			print(p)
			# DEBUG

			# Make current location trail point
			pre_location = p.location[:]
			index = Game.location_to_board_index(p.location)
			pnt = self.__board[index]        # Previous location point
			pnt.trail_point(p)               # Make current location trail
			pnt.turn_on_modified_lately()

			# Save previous location
			players_pre_pos[p] = pre_location

			# Move player
			p.move_player(self.__board_length, self.__board_width)  # Update location in player obj

			# Set pre stats (type and player)
			index = Game.location_to_board_index(p.location)
			cur_point = self.__board[index]
			if cur_point.is_free() or cur_point.is_conquered():  # Otherwise leave pre stats as it is
				cur_point.set_pre_type(cur_point.type)       # Save recent type (this is trail)
				cur_point.set_pre_player(cur_point.player)   # Save recent player (this is player)

			if players_pre_pos[p] == p.location:  # If met border (stuck in the same location)
				met_border_players_list.append(p)

		self.__players_dict_lock.release()

		# Kill players whom someone is on their trail
		self.kill_players_trail_on(met_border_players_list)

		self.__players_dict_lock.acquire()
		for p in self.__players_dict:
			index = Game.location_to_board_index(p.location)
			cur_point = self.__board[index]
			cur_point.put_player_on_point(p)     # Update location on board
			cur_point.turn_on_modified_lately()

		self.__players_dict_lock.release()

		# Conquer points
		self.players_conquer_area(players_pre_pos)

		# Update again current player's location on board and conquer previous point (if it was on conquered area)
		self.__players_dict_lock.acquire()

		for p in self.__players_dict:
			index = Game.location_to_board_index(p.location)
			cur_point = self.__board[index]
			cur_point.put_player_on_point(p)     # Update location on board
			cur_point.turn_on_modified_lately()

			pre_pos_point = self.__board[Game.location_to_board_index(players_pre_pos[p])]
			if pre_pos_point.is_conquer_point_after_player_leave():  # If needs to conquer trail
				if not pre_pos_point.is_player_on_point():
					pre_pos_point.conquer_point(p)  # Conquer trail
				pre_pos_point.not_conquer_point_after_player_leave()  # Don't need to conquer trail anymore

		self.__players_dict_lock.release()

	# If a player can conquer an area, it conquers its area
	def players_conquer_area(self, players_pre_pos_dict):
		remove_me_player_list = []  # List of players to kill
		for player in players_pre_pos_dict:
			index = self.location_to_board_index(player.location)
			border_point = players_pre_pos_dict[player]
			if self.__board[index].was_before_type == Point.type_to_number_dict['conquered'] and\
					self.__board[index].was_before_player == player:
			# if self.__board[index].is_conquered() and self.__board[index].player == player:
				# If player inside his own conquered area
				if not self.__board[self.location_to_board_index(border_point)].is_conquer_point_after_player_leave():
					visited = self.return_everything_but_player_inside_polygon(player)  # Set of visited locations
					# For each point in board - check if should conquer
					for x in range(self.__board_width):
						for y in range(self.__board_length):
							loc = self.location_to_board_index([x, y])
							if loc not in visited:  # If need to conquer point
								cur_point = self.__board[loc]
								if (cur_point.player is not None and cur_point.player != player and
									(cur_point.is_trail() or cur_point.is_player_on_point())):
									# If conquers trail/player - kill the player
									remove_me_player_list.append(cur_point.player)
								# Conquer point
								cur_point.conquer_point(player)
								cur_point.turn_on_modified_lately()

				# Need to turn player's current point next time to conquered (and not to trail)
				player_point = self.__board[self.location_to_board_index(player.location)]
				player_point.conquer_point_after_player_leave()

		for player in remove_me_player_list:  # Kill every player that there is someone on their trail
			player.kill_player()
			self.remove_player(player)

	# Doesn't use board.lock()
	# Returns a queue (deque) with every point that is not inside the player's polygon
	def return_everything_but_player_inside_polygon(self, player):
		visited = set()  # Set of locations of points that were visited! - THOSE POINTS ARE NOT INSIDE POLYGON/POLYGON ITSELF
		queue = deque()  # Queue of points to visit
		addition_list = [(-1, 0), (1, 0), (0, -1), (0, 1)]  # Left, Right, Up, Down
		# Initialize queue - add all the border's points' locations to the queue
		for x in range(self.__board_width):
			queue.append(self.location_to_board_index([x, 0]))                      # Top row
			queue.append(self.location_to_board_index([x, self.__board_length-1]))  # Bottom row
		for y in range(self.__board_length):
			queue.append(self.location_to_board_index([0, y]))                      # Left row
			queue.append(self.location_to_board_index([self.__board_width-1, y]))   # Right row
		# For every point's location in the queue
		while len(queue) != 0:
			loc = queue.popleft()  # Current location
			# If point was not visited OR is free or not inside player's polygon (or the polygon itself)
			cur_point = self.__board[loc]
			if (loc not in visited and (cur_point.is_free()
					or not cur_point.player == player)):
				visited.add(loc)  # Add location to visited points
				# Add it's neighbours
				pos = loc.split(', ')
				x = int(pos[0][1:])                # X of point
				y = int(pos[1][:len(pos[1]) - 1])  # Y of point
				for addition_index in range(len(addition_list)):
					new_x = x + addition_list[addition_index][0]
					new_y = y + addition_list[addition_index][1]
					# If point is in range
					if (0 <= new_x < self.__board_width) and (0 <= new_y < self.__board_length):
						# Add point to queue
						pos = self.location_to_board_index([new_x, new_y])
						queue.append(pos)
		return visited  # Return location of points that are not inside polygon or part of the polygon itself

	# Graphics

	# Generates board to send to player
	def old_get_board_to_send(self):
		pickle_board = []
		for y in range(self.__board_length):
			for x in range(self.__board_width):
				color = 0
				index = Game.location_to_board_index([x, y])
				cur_point = self.__board[index]
				player = cur_point.player
				type = cur_point.type
				if player is not None:   # If point is empty leave the color as 0
					type -= 1
					color = self.__players_dict[player][type]
				pickle_board.append(color)
		pickle_board = pickle.dumps(pickle_board)
		msg = b'brdg\n'+pickle_board
		return msg

	# Generates full board (everything in the board) to send to player
	def get_full_board_to_send(self):
		try:
			pickle_board = {}
			for y in range(self.__board_length):
				for x in range(self.__board_width):
					color = 0
					index = Game.location_to_board_index([x, y])
					cur_point = self.__board[index]
					player = cur_point.player
					type = cur_point.type
					if player is not None:  # If point is empty leave the color as 0
						type -= 1
						color = self.__players_dict[player][type]
					pickle_board[(x, y)] = color  # Key = (x, y), Value = color
			pickle_board = pickle.dumps(pickle_board)
			msg = b'brdg\n' + pickle_board
			return msg
		except Exception as err:
			print(err)

	# Get board to send to player
	def get_board(self):
		pickle_board = {}
		for y in range(self.__board_length):
			for x in range(self.__board_width):
				color = 0
				index = Game.location_to_board_index([x, y])
				cur_point = self.__board[index]
				if cur_point.is_modified_lately():
					player = cur_point.player
					type = cur_point.type
					if player is not None:  # If point is empty leave the color as 0
						if player in self.__players_dict.keys():
							type -= 1
							color = self.__players_dict[player][type]
						else:
							cur_point.free_point()
					pickle_board[(x, y)] = color  # Key = (x, y), Value = color
					cur_point.turn_off_modified_lately()
		pickle_board = pickle.dumps(pickle_board)
		msg = b'brdg\n' + pickle_board
		return msg
	# Send board to all players

	def send_board_to_all_players(self):
		if len(self.__players_dict) != 0:  # If lobby is not empty
			b = self.get_board()
			self.__players_dict_lock.acquire()
			for player in self.__players_dict:
				player.send_to_player(b)
			self.__players_dict_lock.release()

	# color_counter
	@property
	def color_counter(self):
		return self.__color_counter

	# is_game_alive
	@property
	def is_game_alive(self):
		return self.__is_game_alive

	# Returns if the whole board is conquered by the same player
	def is_all_board_conquered_same_player(self):
		p = self.__board[self.location_to_board_index([0, 0])].player
		if p is None:
			return False
		for pnt in self.__board.values():
			if pnt.player != p or pnt.is_trail():  # If point belongs to other player or is trail of current player
				return False
		return True

	# Sends message to the winner of the game
	def send_winner_msg(self, player):
		msg = b'wner'
		player.send_to_player(msg)

	# Sends message to the loser of the game
	def send_loser_msg(self, player):
		msg = b'lser'
		player.send_to_player(msg)

	# Declares self.__is_game_alive as  FALSE
	# Removes game from games_list (global)
	def end_game(self):
		global games_list
		global games_list_lock
		self.__is_game_alive = False
		games_list_lock.acquire()
		if self in games_list:
			games_list.remove(self)
		games_list_lock.release()


	def __str__(self):
		return (f'Players: {self.__players_dict}, IsGameAlive: {self.__is_game_alive},'
				f'ColorCounter: {self.__color_counter}')

# The purpose of the class is to manage a single player in a game
class Player:
	# Variables - 2 underscore before the variable's name (__):
	# The variable will be called so: object.Player__variable | [variable is the variable's name]
	# __name           = name of player             [STRING]
	# __is_alive       = bool if player is alive    [BOOLEAN]
	# __location       = [x, y] of player           [LIST]
	# __velocity_x     = velocity in axis X         [INT]
	# __velocity_y     = velocity in axis Y         [INT]
	# __sck            = TCP socket connected to the user   socket
	# __encryption_key = bytes that are the encryption key [BYTES]


	def __init__(self, args_list):  # Receives args_list - a list containing the arguments for the function
		self.__name = args_list['name']
		self.__is_alive = True
		self.__location = args_list['location']
		self.__velocity_x = 1
		self.__velocity_y = 0
		self.__sck = args_list['sck']
		self.__encryption_key = args_list['enc_key']

	# encryption_key
	@property
	def encryption_key(self):
		return self.__encryption_key

	@encryption_key.setter
	def encryption_key(self, newencr):
		self.__encryption_key = newencr

	# name
	# getter
	@property
	def name(self):
		return self.__name

	@property
	def is_alive(self):
		return self.__is_alive

	# is_alive
	@is_alive.setter
	def is_alive(self, new_is_alive):
		self.__is_alive = new_is_alive

	def kill_player(self):
		self.__is_alive = False

	# location
	@property
	def location(self):
		return self.__location

	@location.setter
	def location(self, new_location):
		self.__location = new_location

	# VELOCITY
	# velocity_x
	@property
	def velocity_x(self):
		return self.__velocity_x

	@velocity_x.setter
	def velocity_x(self, new_velocity_x):
		self.__velocity_x = new_velocity_x

	# velocity_y
	@property
	def velocity_y(self):
		return self.__velocity_y

	@velocity_y.setter
	def velocity_y(self, new_velocity_y):
		self.__velocity_y = new_velocity_y

	# Receives direction [STRING] (up, down, left, right) and updates velocity (x, y)
	def change_direction(self, direction):
		if direction == 'up':
			self.__velocity_x = 0
			self.__velocity_y = -1
		elif direction == 'down':
			self.__velocity_x = 0
			self.__velocity_y = 1
		elif direction == 'right':
			self.__velocity_x = 1
			self.__velocity_y = 0
		elif direction == 'left':
			self.__velocity_x = -1
			self.__velocity_y = 0

	# sck
	def send_to_player(self, msg):  # Sends msg (bytes) to player
		send_recv_msg.send_msg(msg, self.__sck, self.__encryption_key)

	def recv_from_player(self):  # Receives msg (bytes) from player
		# If not ready to read - doesn't need to refresh the screen
		# There is a timeout since there are many sockets on server side and has to be non-blocking
		ready_to_read, _, _ = select.select([self.__sck], [], [], 0)
		if self.__sck in ready_to_read:
			return send_recv_msg.recv_msg(self.__sck, self.__encryption_key)
		return None

	@property
	def sck(self):
		return self.__sck

	# GENERAL FUNCTIONS

	# Moves player - adds speed to location (in direction)
	def move_player(self, board_length, board_width):
		self.__location[0] += self.__velocity_x
		self.__location[1] += self.__velocity_y
		if self.__location[0] < 0:
			self.__location[0] = 0
		elif self.__location[0] >= board_width:
			self.__location[0] = board_width-1
		if self.__location[1] < 0:
			self.__location[1] = 0
		elif self.__location[1] >= board_length:
			self.__location[1] = board_length-1

	def __str__(self):
		return (f'name: {self.__name}, is_alive: {self.__is_alive}, ' +
				f'location: {self.__location}, velocity_x: {self.__velocity_x}, velocity_y: {self.__velocity_y}' +
				f'encryption key: {str(self.__encryption_key)}')


# The purpose of the class is to manage a single point in a game
class Point:
	type_to_number_dict = {'free': 0, 'conquered': 1, 'trail': 2, 'player_itself': 3}
	# Variables - 2 underscore before the variable's name (__):
	# The variable will be called so: object.Point__variable | [variable is the variable's name]
	# __type            = type of point (0 = free, 1 = conquered, 2 = trail, 3 = player itself)     [INT]
	# __player          = object of player that the point is his area/trail                         [Player OBJECT]
	# __modified_lately = bool that represents if need to send the point's color (as it has changed) [BOOL]
	# __conquer_after_player_leave = bool that means if to conquer point after player leaves it     [BOOL]
	# __conquer_after_player_leave only relevant when player is on the point
	# __was_before_type = type of the point that was before the point was turned into trail - RELEVANT ONLY AS TRAIL
	# __was_before_player = player of the point that was before the point was turned into trail - RELEVANT ONLY AS TRAIL

	def __init__(self):
		self.__type = 0
		self.__player = None
		self.__conquer_after_player_leave = False
		self.__modified_lately = False
		self.__was_before_type = 0       # Default
		self.__was_before_player = None  # Default

	# type
	# getter
	@property
	def type(self):
		return self.__type

	@type.setter
	def type(self, new_type):
		self.__type = new_type

	# player
	# getter
	@property
	def player(self):
		return self.__player

	@player.setter
	def player(self, new_player):
		self.__player = new_player

	# modified_lately
	# getter
	def is_modified_lately(self):
		return self.__modified_lately

	def turn_on_modified_lately(self):
		self.__modified_lately = True

	def turn_off_modified_lately(self):
		self.__modified_lately = False

	def free_point(self):
		self.type = Point.type_to_number_dict['free']
		self.player = None
		self.__conquer_after_player_leave = False

	def conquer_point(self, player):
		self.type = Point.type_to_number_dict['conquered']
		self.player = player

	def trail_point(self, player):
		self.type = Point.type_to_number_dict['trail']
		self.player = player

	def conquer_point_after_player_leave(self):
		self.__conquer_after_player_leave = True

	def not_conquer_point_after_player_leave(self):
		self.__conquer_after_player_leave = False

	def put_player_on_point(self, player):
		self.type = Point.type_to_number_dict['player_itself']
		self.player = player

	def is_free(self):
		return self.type == Point.type_to_number_dict['free']

	def is_conquered(self):
		return self.type == Point.type_to_number_dict['conquered']

	def is_trail(self):
		return self.type == Point.type_to_number_dict['trail']

	def is_player_on_point(self):
		return self.type == Point.type_to_number_dict['player_itself']

	def is_conquer_point_after_player_leave(self):
		return self.__conquer_after_player_leave

	@property
	def was_before_type(self):
		return self.__was_before_type

	def set_pre_type(self, new_type):
		self.__was_before_type = new_type

	@property
	def was_before_player(self):
		return self.__was_before_player

	def set_pre_player(self, p):
		self.__was_before_player = p


'''FUNCTIONS'''


# Returns general-errors (not specific for any command but the 00X errors)
# If there is no error returns None
def get_error_from_client_message(code, fields):
	if b'' in fields or code == b'':  # If one or more empty fields
		return error_dict[b'001']
	if code not in [b'movd']:         # If illegal command
		return error_dict[b'002']
	return None


def handle_move_player(player, direction):
	directions = (b'up', b'down', b'left', b'right')
	if direction not in directions:
		player.send_to_player(error_dict[b'601'])
	else:
		player.change_direction(direction.decode())
		player.send_to_player('Changed successfully!')
	print(player)


# Handles a single request from client, receives Game (obj), Player (obj) and msg (bytes) as arguments
def handle_player_request(game, player, msg):
	fields = msg.split(b'\n')
	msg_code = fields[0]
	error = get_error_from_client_message(msg_code, fields)  # If there is error in message from client
	if error is not None:  # IF there is an error
		player.send_to_player(error)
	else:  # IF there is no error
		if msg_code == b'movd':
			direction = fields[1]
			handle_move_player(player, direction)


# Handles a single game, receives Game object as argument
def handle_game_lobby(game):
	global error_dict
	clock = pygame.time.Clock()
	remove_player_list = []  # If player has to be removed append him to this list
	# WAITING ROOM
	while game.in_waiting_room:
		game.players_dict_lock.acquire()
		players_list = game.players_dict.keys()
		for player in players_list:
			msg = player.recv_from_player()
			if msg is not None:  # If message is nothing
				if len(msg) == 0:  # If message from client is empty (client disconnected)
					print(f'Player [{player.sck}] seems to disconnect')
					remove_player_list.append(player)
				else:
					if msg == b'sgam':  # If client want to start game
						game.in_waiting_room = False
					else:               # If illegal command
						player.send_to_player(error_dict[b'002'])
		game.players_dict_lock.release()
		for player in remove_player_list:
			game.remove_player(player)
			player.kill_player()
		remove_player_list.clear()

	# Tell players that game starts
	game.players_dict_lock.acquire()
	players_list = game.players_dict.keys()
	for player in players_list:
		player.send_to_player(b'lrom')
	game.players_dict_lock.release()

	# Actual game
	while game.is_game_alive:  # Main loop
		clock.tick(10)  # limit to 10 fps
		'''Print game - for debug'''
		print(game)
		'''Send graphics to every client'''
		game.send_board_to_all_players()
		print('sends graphics')
		'''Handle each client's request'''
		game.players_dict_lock.acquire()
		players_list = game.players_dict.keys()
		for player in players_list:
			msg = player.recv_from_player()
			if msg is not None:  # If message is nothing
				if len(msg) == 0:  # If message from client is empty (client disconnected)
					print(f'Player [{player.sck}] seems to disconnect')
					remove_player_list.append(player)
				else:
					handle_player_request(game, player, msg)
		game.players_dict_lock.release()
		for player in remove_player_list:
			game.remove_player(player)
			player.kill_player()
		remove_player_list.clear()
		'''Game checkup round - check for collisions, new conquered area...'''
		# Move players to next point                +
		# Kill those whom someone is on their trail +
		# Conquer land
		game.move_players_kill_trail_on_conquer_area()
		'''check if whole board is covered by the same player'''
		if game.is_all_board_conquered_same_player():
			winner = game.board['[0, 0]'].player     # Get winner (player obj)
			game.send_board_to_all_players()  	     # Send board to winner so he sees that he conquered everything
			game.send_winner_msg(winner)             # Send to winner that he won
			winner.kill_player()                     # Kill winner
			game.end_game()                          # Terminate game
		elif game.number_of_players() == 0:          # If there are no players in the game
			game.end_game()


# Joins a single player (obj) to a free game (obj)
# If there is no free game - opens one and starts it
def player_join_to_game(player):
	global games_list
	global games_list_lock
	global thread_list
	global thread_list_lock
	'''Check for a free game to join'''
	games_list_lock.acquire()
	for game in games_list:
		if game.number_of_players() < Game.max_number_of_players and game.color_counter != 13:
			# If free place in game
			success = game.add_new_player(player)
			if success:
				games_list_lock.release()
				return
	'''If there is no free game - open a new one'''
	game = Game()
	games_list.append(game)
	game.add_new_player(player)
	thread_list_lock.acquire()
	t = threading.Thread(target=handle_game_lobby, args=(game,))
	thread_list.append(t)
	thread_list_lock.release()
	t.start()
	games_list_lock.release()


# Handles a single client, receives socket object (sck) and address (addr) sa arguments
# Runs gsc interaction first, then joins to game
def handle_client(sck, addr):
	print(f'New player connected {str(addr)}')
	# sck.settimeout(0.1)  # 0.1 seconds
	cur_id = send_recv_msg.recv_msg(sck)
	gsc_sck = socket.socket()
	print('connecting to: ' + str((server_ip, gsc_server_port)))
	gsc_sck.connect((server_ip, gsc_server_port))  # Connect to gsc server to ask for key from id
	send_recv_msg.send_msg(cur_id, gsc_sck)
	enc_key = send_recv_msg.recv_msg(gsc_sck)
	gsc_sck.close()
	if enc_key == b'':
		sck.close()
	else:
		arg_dict = {'name': f'{time.time()}', 'location': [0, 0], 'sck': sck, 'enc_key': enc_key}
		player = Player(arg_dict)
		print(player)
		player_join_to_game(player)
	print(f'Goodbye Client [{addr}]')


'''GSC SERVER'''
def run_gsc_server():
	subprocess.run(['python', 'gsc_server.py'])



'''MAIN PROGRAM'''
def main_program():
	global server_ip
	global server_port
	global thread_list
	global server_alive
	global max_people_to_listen_at_once
	t = threading.Thread(target=run_gsc_server)  # Run gsc_server
	thread_list.append(t)
	t.start()
	listening_socket = socket.socket()
	listening_socket.bind((server_ip, server_port))
	listening_socket.listen(max_people_to_listen_at_once)
	print('Server up. Waiting for clients to connect')
	while server_alive:
		sck, addr = listening_socket.accept()
		t = threading.Thread(target=handle_client, args=(sck, addr))
		thread_list.append(t)
		t.start()
	listening_socket.close()
	for t in thread_list:
		t.join()
	print('Server shutting down. Goodbye!')


if __name__ == '__main__':
	gsc_thread = threading.Thread()
	main_program()
