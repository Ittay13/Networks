# SERVER
__author__ = 'Ittay_Levit'

import socket
import threading
import pickle
import os
import send_recv_msg
import hashlib
import random
import datetime
import smtplib
import ssl
import uuid
from email.message import EmailMessage
import base64
import pickle


'''User class'''
pepper = 'Levit1307'
class User:
	def __init__(self, username, password, email):
		self._username = username
		self.salt = username+username[::-1]  # salt = username + reverse username
		self._email = email
		self._password = self.get_hashed_password(self.salt, password)

	@property
	def username(self):
		return self._username

	@username.setter
	def username(self, new_username):
		self._username = new_username

	@property
	def password(self):
		return self._password

	@password.setter
	def password(self, new_password):
		self._password = self.get_hashed_password(self.salt, new_password)

	@ property
	def email(self):
		return self._email

	@email.setter
	def email(self, new_email):
		self._email = new_email

	@staticmethod
	def get_hashed_password(salt, password):  # Returns hash(salt+password+pepper)
		global pepper
		return hashlib.sha256((salt + password + pepper).encode()).hexdigest()

	def __str__(self):
		global pepper
		return (f'Username: {str(self._username)} Password: {str(self._password)} Email: {str(self._email)} '
				f'Salt: {str(self.salt)} Pepper: {str(pepper)}')

'''Verify-Email class'''
small_letters_list = [chr(x) for x in range(97, 123)]
big_letters_list = [chr(x) for x in range(65, 91)]
code_choice = small_letters_list + big_letters_list
delta_time = datetime.timedelta(minutes=5)
class VerifyEmail:
	def __init__(self, user_obj):
		self._user = user_obj
		self._code = VerifyEmail.generate_random_code()
		self.time = datetime.datetime.now()

	@property
	def user(self):
		return self._user

	@property
	def code(self):
		return self._code

	@code.setter
	def code(self, new_code):
		self._code = new_code

	@staticmethod
	# Returns 6 letters code
	def generate_random_code():
		global code_choice
		code = ''
		for i in range(6):  # Number of letters in password
			code += (random.choice(code_choice))
		return code

	# Sends email
	# USING: build_email_string, send_email (FROM MAIN PROGRAM)
	def send_email(self):
		body = build_email_string(self.user.username, self.code)
		subject = 'Verification Code'
		send_email(email_receiver=self.user.email, subject=subject, body=body)

	# Resets time
	def reset_time(self):
		self.time = datetime.datetime.now()

	# Change code
	def change_code(self):
		self.code = VerifyEmail.generate_random_code()

	# Return if current time is valid time
	def is_valid_time(self):
		global delta_time
		return datetime.datetime.now() <= self.time + delta_time

	# Return if code == object's code
	def is_same_code(self, code):
		return code == self._code

	# Returns if valid code (code same as self code and valid time)
	def is_valid_code(self, code):
		return self.is_valid_time() and self.is_same_code(code)

	def __str__(self):
		return f'Email: {str(self._user.email)} Code: {str(self._code)} Time: {str(self.time)}'

'''Server program'''
# Global Variables
#	Email variables
email_sender = 'ittay.levit@gmail.com'
email_password = 'tyby qtpa xxwy zlvc'  # Code from: https://myaccount.google.com/u/3/apppasswords
security_code = str(uuid.uuid4())


#	Program variables
all_clients_to_disconnect = False     # All clients need to disconnect
max_users_of_program = 100            # Maximum number of users at once
current_number_of_users = 0
max_connections_at_once = 10          # Maximum number of users trying to connect at once
server_ip = '10.100.102.3'            # Server's ip
server_port = 13072                   # Server's port
server_key_id_port = 13074            # Server's port (for final project YA)
error_list = [b''] * 7
error_list[1] = b'eror01\nIncorrect username or password'
error_list[2] = b'eror02\nUsername or email are already in use'
error_list[3] = b'eror03\nUnknown email'
error_list[4] = b'eror04\nOne or more empty fields'
error_list[5] = b'eror05\nEmail not same as verify email'
error_list[6] = b'eror06\nUnknown request!'

users_dictionary = {}  # Username: User_OBJ
users_dict_lock = threading.Lock()
not_verified_email_dictionary = {}  # Email: VerifyEmail_OBJ
not_verified_email_dict_lock = threading.Lock()
forgot_password_not_verified_email_dictionary = {}  # Email: VerifyEmail_OBJ
forgot_password_not_verified_email_dict_lock = threading.Lock()
dictionary_path = os.getcwd()+'\\users_dictionary.txt'

ID_key_dictionary = {}  # ID	: key
key_exchange_method = {'DPH': send_recv_msg.get_dph_key,
					   'RSA': send_recv_msg.get_key_rsa_server}

# DP-Helman variables
DPH_g = 33211
DPH_p = 29009
DPH_private_list = [10007, 10009, 10037, 10039, 10061, 10067,
10079, 10091, 10093, 10099, 10103, 10111,
10139, 10141, 10151, 10159, 10163, 10169,
14929, 14939, 14947, 14951, 14957, 14969,
15013, 15017, 15031, 15053, 15061, 15073,
15083, 15091, 15101, 15107, 15121, 15131,
15139, 15149, 15161, 15173, 15187, 15193,
15217, 15227, 15233, 15241, 15259, 15263,
15271, 15277, 15287, 15289, 15299, 15307,
15319, 15329, 15331, 15349, 15359, 15361,
16691, 16693, 16699, 16703, 16729, 16741,
16759, 16763, 16787, 16811, 16823, 16829,
16843, 16871, 16879, 16883, 16889, 16901,
16921, 16927, 16931, 16937, 16943, 16963,
16981, 16987, 16993, 17011, 17021, 17027,
17033, 17041, 17047, 17053, 17077, 17093,
17881, 17891, 17903, 17909, 17911, 17921,
17929, 17939, 17957, 17959, 17971, 17977,
17987, 17989, 18013, 18041, 18043, 18047,
18059, 18061, 18077, 18089, 18097, 18119,
18127, 18131, 18133, 18143, 18149, 18169,
18191, 18199, 18211, 18217, 18223, 18229,
18503, 18517, 18521, 18523, 18539, 18541,
18583, 18587, 18593, 18617, 18637, 18661,
18679, 18691, 18701, 18713, 18719, 18731,
18749, 18757, 18773, 18787, 18793, 18797,
18839, 18859, 18869, 18899, 18911, 18913,
18919, 18947, 18959, 18973, 18979, 19001,
19013, 19031, 19037, 19051, 19069, 19073,
19081, 19087, 19121, 19139, 19141, 19157,
19181, 19183, 19207, 19211, 19213, 19219,
19237, 19249, 19259, 19267, 19273, 19289,
19309, 19319, 19333, 19373, 19379, 19381,
19391, 19403, 19417, 19421, 19423, 19427,
19433, 19441, 19447, 19457, 19463, 19469,
19477, 19483, 19489, 19501, 19507, 19531,
19543, 19553, 19559, 19571, 19577, 19583,
19603, 19609, 19661, 19681, 19687, 19697,
19709, 19717, 19727, 19739, 19751, 19753,
19763, 19777, 19793, 19801, 19813, 19819,
19843, 19853, 19861, 19867, 19889, 19891,
19919, 19927, 19937, 19949, 19961, 19963,
19979, 19991, 19993, 19997, 20011, 20021,
20029, 20047, 20051, 20063, 20071, 20089,
20107, 20113, 20117, 20123, 20129, 20143,
20149, 20161, 20173, 20177, 20183, 20201,
20231, 20233, 20249, 20261, 20269, 20287,
20323, 20327, 20333, 20341, 20347, 20353,
20359, 20369, 20389, 20393, 20399, 20407,
20431, 20441, 20443, 20477, 20479, 20483,
20509, 20521, 20533, 20543, 20549, 20551,
20593, 20599, 20611, 20627, 20639, 20641,
20681, 20693, 20707, 20717, 20719, 20731,
20747, 20749, 20753, 20759, 20771, 20773,
71329, 71333, 71339, 71341, 71347, 71353,
71363, 71387, 71389, 71399, 71411, 71413,
71429, 71437, 71443, 71453, 71471, 71473,
71483, 71503, 71527, 71537, 71549, 71551,
72253, 72269, 72271, 72277, 72287, 72307,
72337, 72341, 72353, 72367, 72379, 72383,
72431, 72461, 72467, 72469, 72481, 72493,
72503, 72533, 72547, 72551, 72559, 72577,
72617, 72623, 72643, 72647, 72649, 72661,
72673, 72679, 72689, 72701, 72707, 72719,
72733, 72739, 72763, 72767, 72797, 72817,
72859, 72869, 72871, 72883, 72889, 72893,
72907, 72911, 72923, 72931, 72937, 72949,
72959, 72973, 72977, 72997, 73009, 73013,
73037, 73039, 73043, 73061, 73063, 73079,
73121, 73127, 73133, 73141, 73181, 73189,
73243, 73259, 73277, 73291, 73303, 73309,
73331, 73351, 73361, 73363, 73369, 73379,
73417, 73421, 73433, 73453, 73459, 73471,
73483, 73517, 73523, 73529, 73547, 73553,
73571, 73583, 73589, 73597, 73607, 73609,
73637, 73643, 73651, 73673, 73679, 73681,
73699, 73709, 73721, 73727, 73751, 73757,
73783, 73819, 73823, 73847, 73849, 73859,
73877, 73883, 73897, 73907, 73939, 73943,
73961, 73973, 73999, 74017, 74021, 74027,
74051, 74071, 74077, 74093, 74099, 74101,
74143, 74149, 74159, 74161, 74167, 74177,
74197, 74201, 74203, 74209, 74219, 74231,
74279, 74287, 74293, 74297, 74311, 74317,
74353, 74357, 74363, 74377, 74381, 74383,
74413, 74419, 74441, 74449, 74453, 74471,
74507, 74509, 74521, 74527, 74531, 74551,
74567, 74573, 74587, 74597, 74609, 74611,
74653, 74687, 74699, 74707, 74713, 74717,
74729, 74731, 74747, 74759, 74761, 74771,
74797, 74821, 74827, 74831, 74843, 74857,
74869, 74873, 74887, 74891, 74897, 74903,
74929, 74933, 74941, 74959, 75011, 75013,
75029, 75037, 75041, 75079, 75083, 75109,
75149, 75161, 75167, 75169, 75181, 75193,
75211, 75217, 75223, 75227, 75239, 75253,
75277, 75289, 75307, 75323, 75329, 75337,
75353, 75367, 75377, 75389, 75391, 75401,
75407, 75431, 75437, 75479, 75503, 75511,
75527, 75533, 75539, 75541, 75553, 75557,
75577, 75583, 75611, 75617, 75619, 75629,
75653, 75659, 75679, 75683, 75689, 75703,
75709, 75721, 75731, 75743, 75767, 75773,
75787, 75793, 75797, 75821, 75833, 75853,
75883, 75913, 75931, 75937, 75941, 75967,
75983, 75989, 75991, 75997, 76001, 76003,
76039, 76079, 76081, 76091, 76099, 76103,
76129, 76147, 76157, 76159, 76163, 76207,
76231, 76243, 76249, 76253, 76259, 76261,
76289, 76303, 76333, 76343, 76367, 76369,
76387, 76403, 76421, 76423, 76441, 76463,
76481, 76487, 76493, 76507, 76511, 76519,
76541, 76543, 76561, 76579, 76597, 76603,
76631, 76649, 76651, 76667, 76673, 76679,
76717, 76733, 76753, 76757, 76771, 76777,
76801, 76819, 76829, 76831, 76837, 76847,
76873, 76883, 76907, 76913, 76919, 76943,
76961, 76963, 76991, 77003, 77017, 77023,
77041, 77047, 77069, 77081, 77093, 77101,
77141, 77153, 77167, 77171, 77191, 77201,
77237, 77239, 77243, 77249, 77261, 77263,
77269, 77279, 77291, 77317, 77323, 77339,
77351, 77359, 77369, 77377, 77383, 77417,
77431, 77447, 77471, 77477, 77479, 77489,
77509, 77513, 77521, 77527, 77543, 77549,
77557, 77563, 77569, 77573, 77587, 77591,
77617, 77621, 77641, 77647, 77659, 77681,
77689, 77699, 77711, 77713, 77719, 77723,
77743, 77747, 77761, 77773, 77783, 77797,
77813, 77839, 77849, 77863, 77867, 77893,
77929, 77933, 77951, 77969, 77977, 77983,
78007, 78017, 78031, 78041, 78049, 78059,
78101, 78121, 78137, 78139, 78157, 78163,
78173, 78179, 78191, 78193, 78203, 78229,
78241, 78259, 78277, 78283, 78301, 78307,
78317, 78341, 78347, 78367, 78401, 78427,
78439, 78467, 78479, 78487, 78497, 78509,
78517, 78539, 78541, 78553, 78569, 78571,
78583, 78593, 78607, 78623, 78643, 78649,
78691, 78697, 78707, 78713, 78721, 78737,
78781, 78787, 78791, 78797, 78803, 78809,
78839, 78853, 78857, 78877, 78887, 78889,
78901, 78919, 78929, 78941, 78977, 78979,
79031, 79039, 79043, 79063, 79087, 79103,
79133, 79139, 79147, 79151, 79153, 79159,
79187, 79193, 79201, 79229, 79231, 79241,
79273, 79279, 79283, 79301, 79309, 79319,
79337, 79349, 79357, 79367, 79379, 79393,
79399, 79411, 79423, 79427, 79433, 79451,
79493, 79531, 79537, 79549, 79559, 79561,
79589, 79601, 79609, 79613, 79621, 79627,
79633, 79657, 79669, 79687, 79691, 79693,
79699, 79757, 79769, 79777, 79801, 79811,
79817, 79823, 79829, 79841, 79843, 79847,
79867, 79873, 79889, 79901, 79903, 79907,
79943, 79967, 79973, 79979, 79987, 79997,
80021, 80039, 80051, 80071, 80077, 80107,
80141, 80147, 80149, 80153, 80167, 80173,
80191, 80207, 80209, 80221, 80231, 80233,
80251, 80263, 80273, 80279, 80287, 80309,
80329, 80341, 80347, 80363, 80369, 80387,
80429, 80447, 80449, 80471, 80473, 80489,
80513, 80527, 80537, 80557, 80567, 80599,
80611, 80621, 80627, 80629, 80651, 80657,
80671, 80677, 80681, 80683, 80687, 80701,
80737, 80747, 80749, 80761, 80777, 80779,
80789, 80803, 80809, 80819, 80831, 80833,
80863, 80897, 80909, 80911, 80917, 80923,
80933, 80953, 80963, 80989, 81001, 81013,
81019, 81023, 81031, 81041, 81043, 81047,
81071, 81077, 81083, 81097, 81101, 81119,
81157, 81163, 81173, 81181, 81197, 81199,
81223, 81233, 81239, 81281, 81283, 81293,
81307, 81331, 81343, 81349, 81353, 81359,
81373, 81401, 81409, 81421, 81439, 81457,
81509, 81517, 81527, 81533, 81547, 81551,
81559, 81563, 81569, 81611, 81619, 81629,
81647, 81649, 81667, 81671, 81677, 81689,
81703, 81707, 81727, 81737, 81749, 81761,
81773, 81799, 81817, 81839, 81847, 81853,
81883, 81899, 81901, 81919, 81929, 81931,
81943, 81953, 81967, 81971, 81973, 82003,
82009, 82013, 82021, 82031, 82037, 82039,
82067, 82073, 82129, 82139, 82141, 82153,
82171, 82183, 82189, 82193, 82207, 82217,
82223, 82231, 82237, 82241, 82261, 82267,
82301, 82307, 82339, 82349, 82351, 82361,
82387, 82393, 82421, 82457, 82463, 82469,
82483, 82487, 82493, 82499, 82507, 82529,
82549, 82559, 82561, 82567, 82571, 82591,
82609, 82613, 82619, 82633, 82651, 82657,
82721, 82723, 82727, 82729, 82757, 82759,
82781, 82787, 82793, 82799, 82811, 82813,
82847, 82883, 82889, 82891, 82903, 82913,
82963, 82981, 82997, 83003, 83009, 83023,
83059, 83063, 83071, 83077, 83089, 83093,
83117, 83137, 83177, 83203, 83207, 83219,
83227, 83231, 83233, 83243, 83257, 83267,
83273, 83299, 83311, 83339, 83341, 83357,
83389, 83399, 83401, 83407, 83417, 83423,
83437, 83443, 83449, 83459, 83471, 83477,
99859, 99871, 99877, 99881, 99901, 99907,
99929, 99961, 99971, 99989, 99991]

# RSA variables
RSA_exponent = 65537


# Returns key of id (if has)
# Otherwise returns b''
def get_key_from_id(id_cur):
	global ID_key_dictionary
	pass
	if id_cur in list(ID_key_dictionary.keys()):
		key = ID_key_dictionary[id_cur]
		return key  # Returns key of id (if has)
	return b''


# Sends email by arguments
# receiver_email = who to send the email
def send_email(email_receiver, subject, body):
	global email_sender
	em = EmailMessage()
	em['From'] = email_sender
	em['To'] = email_receiver
	em['Subject'] = subject
	em.set_content(body)
	context = ssl.create_default_context()

	with smtplib.SMTP_SSL('smtp.gmail.com', 465, context=context) as smtp:
		smtp.login(email_sender, email_password)
		smtp.sendmail(email_sender, email_receiver, em.as_string())


# Builds verification-code email
# Receives username code as argument (string)
def build_email_string(username, code):
	s = (f'Hello {username},\n\n'
		
		f'The verification code is: {code}')
	return s


# Handle client's request.
# Returns msg to send
def handle_request(request):
	request = request.decode()
	cmd = request[:4]
	request = request[4:]
	fields = request.split('\n')
	if cmd == 'lgnp':
		dc = {'username': fields[0], 'password': fields[1]}
		return handle_login(**dc)
	elif cmd == 'sgnp':
		dc = {'username': fields[0], 'password': fields[1], 'email': fields[2], 'verify_email': fields[3]}
		return handle_signup(**dc)
	elif cmd == 'cdap':
		return resend_code(fields[0])
	elif cmd == 'cdve':
		dc = {'code': fields[0], 'email': fields[1]}
		return handle_email_verify(cmd, **dc)
	elif cmd == 'frps':
		dc = {'email': fields[0]}
		return handle_forgot_password(**dc)
	elif cmd == 'rsps':
		dc = {'email': fields[0], 'password': fields[1]}
		return handle_reset_password(**dc)
	else:   # If unknown request
		return error_list[6]


# Handles signup request
# Returns msg to send according to if username and email are free
def handle_signup(**kwargs):
	global users_dict_lock
	global users_dictionary
	global not_verified_email_dict_lock
	global not_verified_email_dictionary
	global error_list
	r = b''
	username = kwargs['username']
	password = kwargs['password']
	email = kwargs['email']
	verify_email = kwargs['verify_email']
	if is_empty(username) or is_empty(password) or is_empty(email) or is_empty(verify_email):
		return error_list[4]
	if email != verify_email:
		return error_list[5]
	users_dict_lock.acquire()
	users_dictionary = get_dictionary()
	users_dict_lock.release()
	not_verified_email_dict_lock.acquire()
	not_verified_dictionary = not_verified_email_dictionary
	for name in users_dictionary:
		if username == name or email == users_dictionary[name].email:
			# If username/email already in use
			r = error_list[2]
			break
	if r == b'':
		for not_verified_email in not_verified_email_dictionary:
			# If email or username is not verified (GOING TO BE USED)
			if (username == not_verified_email_dictionary[not_verified_email].user.username
				or email == not_verified_email)\
					and not_verified_email_dictionary[not_verified_email].is_valid_time():
				r = error_list[2]
				break
	if r == b'':  # IF USERNAME AND EMAIL NOT TAKEN
		# If username and email free
		user = User(username, password, email)
		# Put user in not_verified_email dictionary
		not_verified_email_dictionary[email] = VerifyEmail(user)
		# Send email to user
		not_verified_email_dictionary[email].send_email()
		print(not_verified_email_dictionary[email])
		# Build reply
		r = b'vfce'+email.encode()
	not_verified_email_dict_lock.release()

	return r


# Handles login request
# Returns msg to send according to if username and password are correct
def handle_login(**kwargs):
	global users_dict_lock
	global users_dictionary
	global error_list
	r = b''
	username = kwargs['username']
	password = kwargs['password']
	if is_empty(username) or is_empty(password):
		return error_list[4]
	users_dict_lock.acquire()
	users_dictionary = get_dictionary()
	for user in users_dictionary:
		if username == users_dictionary[user].username\
				and users_dictionary[user].password == User.get_hashed_password(users_dictionary[user].salt, password):
			# If login successful
			r = b'lgna'
			break
	if r == b'':
		# If login not successful
		r = error_list[1]
	users_dict_lock.release()
	return r


# Handle sent code (email_verify - both SIGNUP and RESET PASSWORD)
# Returns msg to send according to if code is valid
def handle_email_verify(cmd, **kwargs):
	global users_dictionary
	global users_dict_lock
	global not_verified_email_dictionary
	global not_verified_email_dict_lock
	global forgot_password_not_verified_email_dictionary
	global forgot_password_not_verified_email_dict_lock
	global error_list
	r = error_list[3]
	code = kwargs['code']
	email = kwargs['email']
	if is_empty(email) or is_empty(code):
		return error_list[4]
	valid = False
	my_lock = 0
	my_dc = 0
	not_verified_email_dict_lock.acquire()
	if email not in not_verified_email_dictionary:
		my_dc = forgot_password_not_verified_email_dictionary
		my_lock = forgot_password_not_verified_email_dict_lock
	else:
		my_dc = not_verified_email_dictionary
		my_lock = not_verified_email_dict_lock
	not_verified_email_dict_lock.release()

	my_lock.acquire()
	if email in my_dc:
		r = b'vfce'+email.encode()
		if my_dc[email].is_valid_code(code):
			valid = True

	if valid:
		if my_dc == not_verified_email_dictionary:  # Signup
			verify_email = my_dc[email]
			user = verify_email.user
			users_dict_lock.acquire()
			users_dictionary[user.username] = user  # Put user in users_dictionary
			update_dictionary(users_dictionary)
			users_dict_lock.release()
			r = b'sgna'
			my_dc.pop(email)  # Remove email
		else:                # Reset password
			r = b'vfap'

	my_lock.release()
	return r


# Handle request to forgot password
# Returns msg to send according to if email exists
def handle_forgot_password(**kwargs):
	global forgot_password_not_verified_email_dictionary
	global forgot_password_not_verified_email_dict_lock
	global users_dictionary
	global users_dict_lock
	global error_list
	new_email = ''
	email = kwargs['email']
	if is_empty(email):
		return error_list[4]
	success = False
	users_dict_lock.acquire()
	for user in users_dictionary.values():
		if user.email == email:
			new_email = VerifyEmail(user)
			# Send email
			new_email.send_email()
			print(new_email)
			success = True
			break
	users_dict_lock.release()
	if success:
		forgot_password_not_verified_email_dict_lock.acquire()
		forgot_password_not_verified_email_dictionary[email] = new_email
		forgot_password_not_verified_email_dict_lock.release()
		return b'vfce'+email.encode()
	return error_list[3]


# Handle password resetting:
# 	Resets password after it's email was verified
# 	Receives new passwords and resets it
# 	Returns msg to send according to if code is valid
def handle_reset_password(**kwargs):
	global users_dictionary
	global users_dict_lock
	global forgot_password_not_verified_email_dictionary
	global forgot_password_not_verified_email_dict_lock
	global error_list
	r = b''
	email = kwargs['email']
	password = kwargs['password']
	if is_empty(email) or is_empty(password):
		return error_list[4]

	users_dict_lock.acquire()
	forgot_password_not_verified_email_dict_lock.acquire()
	if email not in forgot_password_not_verified_email_dictionary:
		r = error_list[3]
	else:
		user = forgot_password_not_verified_email_dictionary[email].user
		users_dictionary[user.username].password = password
		update_dictionary(users_dictionary)
		forgot_password_not_verified_email_dictionary.pop(email)
	forgot_password_not_verified_email_dict_lock.release()
	users_dict_lock.release()
	r = b'rspa'
	return r


# Resends code if email exists in:
# 				1. not verified dict
# 				2. forgot password dict
def resend_code(email):
	global forgot_password_not_verified_email_dict_lock
	global forgot_password_not_verified_email_dictionary
	global not_verified_email_dict_lock
	global not_verified_email_dictionary
	global error_list
	success = False
	if is_empty(email):
		return error_list[4]
	not_verified_email_dict_lock.acquire()
	forgot_password_not_verified_email_dict_lock.acquire()

	if email in not_verified_email_dictionary:
		not_verified_email_dictionary[email].change_code()
		not_verified_email_dictionary[email].reset_time()
		# Send email
		not_verified_email_dictionary[email].send_email()
		print(not_verified_email_dictionary[email])
		success = True

	elif email in forgot_password_not_verified_email_dictionary:
		forgot_password_not_verified_email_dictionary[email].change_code()
		forgot_password_not_verified_email_dictionary[email].reset_time()
		# Send email
		forgot_password_not_verified_email_dictionary[email].send_email()
		print(forgot_password_not_verified_email_dictionary[email])
		success = True

	forgot_password_not_verified_email_dict_lock.release()
	not_verified_email_dict_lock.release()

	if not success:
		return error_list[3]
	return b'vfce'+email.encode()


# Returns if empty field (empty string)
def is_empty(field):
	if field == '':
		return True
	return False


# Returns instance of dictionary
def get_dictionary():
	with open(dictionary_path, 'rb') as myfile:
		data = myfile.read()
	users_dict = pickle.loads(data)
	return users_dict


# Updates instance of dictionary (that is kept as a file)
def update_dictionary(dc):
	with open(dictionary_path, 'wb') as myfile:
		myfile.write(pickle.dumps(dc))


# Returns a number out of the DPH_private_list
def get_private_dph():
	global DPH_private_list
	index = random.randint(0, len(DPH_private_list)-1)
	return DPH_private_list[index]


# Handles key exchange
# Updates address-key dictionary
# If client crashes doesn't do anything
def handle_key_exchange(sock, addr, id):
	global ID_key_dictionary
	global key_exchange_method
	global DPH_g
	global DPH_p
	global RSA_exponent
	key = b''
	end_procedure = False
	msg = send_recv_msg.recv_msg(sock)
	if msg == b'exit':  # If client wants to disconnect
		return
	if msg == b'':  # If client disconnected
		print(f'Client seems to disconnect [{addr}]')
		return
	method = msg.decode()[4:]  # first 4 digits are code of function ('kems'), after that is the method
	if method in key_exchange_method:
		msg_to_send = b'keas'+method.encode()
		send_recv_msg.send_msg(msg_to_send, sock)
		func = key_exchange_method[method]
		if method == 'DPH':
			private = get_private_dph()
			key = func(sock, private, 'server', DPH_g, DPH_p)
			key = hashlib.sha256(key).digest()[:128]  # Turn key into 128 hash bits
			if key != b'error':
				end_procedure = True
		elif method == 'RSA':
			key = func(sock, RSA_exponent)
			if key != b'':
				end_procedure = True
		print(f'key with [{addr}], ID: {id}: ' + key.hex())
		ID_key_dictionary[id] = key  # Turn key into 128 hash bits
	if not end_procedure:
		msg = b'skep'  # Send key-exchange message
		send_recv_msg.send_msg(msg, sock)  # Tell client to start process again


# Handle client - main client's thread loop
def handle_client(sock, addr):
	global current_number_of_users
	global ID_key_dictionary
	try:
		print('ID-key dictionary: ' + str(ID_key_dictionary))
		msg = send_recv_msg.recv_msg(sock)  # Get 'pake' msg
		id = msg[4:].decode()
		print('ID: ' + id)
		# First check if there is a key to encrypt with
		if id not in ID_key_dictionary:  # If doesn't has a key for the specific address
			send_recv_msg.send_msg(b'skep', sock)  # Tell client to start key-exchange
			handle_key_exchange(sock, addr, id)
			sock.close()  # The client exchanged-key, enough interaction
			return
		else:  # If address already has a key
			send_recv_msg.send_msg(b'ukoa', sock)  # Tell client that already has his key
		key = ID_key_dictionary[id]
		# try to recv data
		byte_data = send_recv_msg.recv_msg(sock, key)
		if byte_data == b'':                             # If received data
			print(f'[{addr[0]}:{addr[1]}] client seems to disconnect')
			sock.close()
		# Handle exit statement from client
		# if byte_data == b'exit':
			# ID_key_dictionary.pop(id)  # Remove key from dictionary
		# send the msg to send
		else:
			msg = handle_request(byte_data)
			send_recv_msg.send_msg(msg, sock, key)
		sock.close()
	except Exception as err:
		print(f'[{addr[0]}:{addr[1]}] error: {str(err)}')
		sock.close()
	print(f'[{addr[0]}:{addr[1]}] goodbye client.')
	current_number_of_users -= 1

def main_ret_key_of_id_final_project_YA():
	sck = socket.socket()
	sck.bind((server_ip, server_key_id_port))
	print('my final project address: ' + str((server_ip, server_key_id_port)))
	sck.listen(max_connections_at_once)
	while True:
		temp_sck, addr = sck.accept()
		cur_id = send_recv_msg.recv_msg(temp_sck).decode()
		key = get_key_from_id(cur_id)
		send_recv_msg.send_msg(key, temp_sck)


# Main server's loop
def gsc_server_main():
	global all_clients_to_disconnect
	global max_users_of_program
	global current_number_of_users
	global server_ip
	global server_port
	global users_dictionary
	threads_list = []
	srv_sock = socket.socket()
	srv_sock.bind((server_ip, server_port))
	srv_sock.listen(max_connections_at_once)
	t = threading.Thread(target=main_ret_key_of_id_final_project_YA)
	t.start()
	threads_list.append(t)
	print('Server up, waiting for connections')
	users_dictionary = get_dictionary()
	for i in users_dictionary:
		print(users_dictionary[i])
	while True:
		if current_number_of_users-1 < max_users_of_program:  # If number of connected users less than maximum allowed
			client_sock, addr = srv_sock.accept()
			t = threading.Thread(target=handle_client, args=(client_sock, addr))
			t.start()
			current_number_of_users += 1
			threads_list.append(t)
		else:  # If number of connected users more than maximum users allowed
			print('Closing server, more than maximum users connected')
			break

	all_clients_to_disconnect = True
	print('Waiting to all clients to die')
	for t in threads_list:
		t.join()
	srv_sock.close()
	print('Server going down')


if __name__ == '__main__':
	gsc_server_main()
