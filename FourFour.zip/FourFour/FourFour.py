__author__ = 'Ittay_Levit'

import socket
import os
import threading
import hashlib
import time
import traceback


# Global variables
webroot_address = 'E:\\Networks\\FourFour\\webroot'    # Address of webroot directory
server_ip = '127.0.0.1'                                # My ip
close_all_clients = False                              # IF need to close all clients (terminate program)
socket_recv_size = 64 * 1024                           # Number of bytes to read each time (size of chunk)
# Response code (key) and response message (value)
status_dictionary = {200: 'OK', 404: 'Not Found', 403: 'Forbidden',
                     302: 'Moved Temporarily', 500: 'Iternal Server Error',
                     304: 'Not Modified'}
# List of paths of forbidden files
forbidden_files_path = ['\\forbiddentextfile.txt']
# Dictionary of paths of moved temporarily files
# Key = moved file path, Value = path of file to direct to (instead of moved file)
temporarily_moved_files_paths = {'\\iwasmoved.txt': '\\takemeinsteadofmoved.txt'}


# The function receives http requests
# Returns dictionary with key-value pairs according to http format
def http_recv(sck):
    global socket_recv_size
    dc = {'status': 'failure', 'body': ''}
    bt = b''
    two_lines = b'\r\n\r\n'
    one_line = '\r\n'
    # receive until end of header
    while two_lines not in bt:
        chunk = sck.recv(socket_recv_size)
        if len(chunk) == 0:  # If other side disconnected
            return dc
        bt += chunk
    bt = bt.split(two_lines, 1)  # bt[0] = header, bt[1] = body
    header = bt[0].decode()
    header = header.split(one_line)
    body = bt[1]
    print(header)
    # Turn first line to key and value
    # EXAMPLE FOR FIRST LINE: GET /food/banana?mode=show&loc=5,7 HTTP/1.1
    first_line = header[0]
    first_line = first_line.split(' ')
    dc['method'] = first_line[0]                              # Get
    dc['url'] = first_line[1].replace('/', '\\')  # \food\banana?mode=show&loc=5,7
    dc['version'] = first_line[2].split('/')[1]               # 1.1
    header = header[1:]

    # Get parameters
    resource = dc['url'].split('?')[0]     # \food\banana
    if len(dc['url'].split('?')) > 1:      # If there are parameters and not just resource
        parameters = dc['url'].split('?')[1:]  # mode=show&loc=5,7
        parameters = ''.join(parameters)
        parameters = parameters.split('&')     # [mode=show, loc=5,7]
        dc['url'] = resource                   # \food\banana
        dc['parameters'] = {}
        for pair in parameters:
            key = pair.split('=')[0]           # mode
            value = pair.split('=')[1]         # show
            dc['parameters'][key] = value      # parameters: {mode: show}

    # Turn rest of lines to key and value
    # EXAMPLE FOR NORMAL LINE: Connection: keep-alive
    for line in header:
        key = line.split(':')[0].lower()
        value = line.split(':', 1)[1][1:]
        dc[key] = value

    # Read end of body (if has so)
    body_size = 0
    if 'content-length' in dc.keys():
        body_size = int(dc['content-length'])
    while len(body) < body_size:
        chunk = sck.recv(body_size - len(body))
        body += chunk
        if len(chunk) == 0:   # If other side disconnected
            return dc
    dc['body'] = body
    dc['status'] = 'success'
    print(dc)
    return dc


# Sends binary data 'http_response' with socket 'sck'
def http_send(sck, http_response):
    sck.send(http_response)            # Send response


# Builds http response with 'bdata' as its body
# Returns bytestream representing the response (=the encoded response)
def build_http(bdata, response_code, path):
    global status_dictionary
    size = len(bdata)
    http_response = f'HTTP/1.1 {response_code} {status_dictionary[response_code]}\r\n'  # First line
    http_response += f'Content-Length: {size}\r\n'                                      # Content-Length
    http_response += f'Content-Type: '                                                  # Content-Type
    c = 'txt'
    if response_code != 302:                                                            # If file not moved temporarily
        http_response += f'{return_content_type(path)}\r\n'                               # Type of path
    else:
        http_response += 'text/html; charset=utf-8\r\n'                                   # Type of 'path'
    if type(bdata) is not bytes:  # Make sure bdata is bytes
        bdata = bdata.encode()
    http_response += f'ETag: {hashlib.md5(bdata).hexdigest()}\r\n'                      # ETag
    date = 'None'
    if os.path.isfile(path):
        date = time.ctime(os.path.getmtime(path))                                         # Epoch to textual date
    http_response += f'Last-Modified: {date}\r\n'                                       # Last-Modified
    http_response += 'Cache-Control: public\r\n'                                        # Cache-Control

    http_response += '\r\n'                                                             # *Separate header and body
    http_response = http_response.encode() + bdata                                      # Body
    return http_response


# Returns a string representing the value of the key 'Content-Type' for the http response
def return_content_type(path):
    tp = path.split('.')[len(path.split('.'))-1]
    if tp == 'txt' or tp == 'html':
        return 'text/html; charset=utf-8'
    if tp == 'jpg':
        return 'image/jpeg'
    if tp == 'js':
        return 'text/javascript; charset=UTF-8'
    if tp == 'css':
        return 'text/css'
    else:
        return 'unknown type'


# Returns path to resource from the url received in the http request
# Returns status code if resource does not exists (404) and if exists (200)
# Returns: path, status code
# If path not exists returns path to ndex.html
# url: '\' is the equivalent to index.html
def url_to_path(url):
    global webroot_address
    global forbidden_files_path
    global temporarily_moved_files_paths
    status_code = 200
    path = webroot_address + url
    if url == '\\':                 # If url is '\'
        path = webroot_address + '\\index.html'
    elif not os.path.isfile(path):  # If requested file does not exists
        status_code = 404
        path = webroot_address + '\\index.html'
    elif url in forbidden_files_path:
        print('file is forbidden!')
        status_code = 403
    elif url in temporarily_moved_files_paths.keys():
        status_code = 302
        path = webroot_address + temporarily_moved_files_paths[url]
    return path, status_code


# Receives bytes of picture and path to picture, writes the bytes to the file (or create one if not exists)
# If path exists function doesn't do anything
# False = didn't work successfully
# True  = worked well
def save_picture(picture_bytes, path_to_file):
    path_to_file = webroot_address + path_to_file
    print(f'saving pic to path:{path_to_file}')
    try:
        with open(path_to_file, 'wb') as my_file:
            my_file.write(picture_bytes)
        return True
    except Exception as err:
        return False


# Returns status code, path and bytes of image by path
def get_image(image_name):
    image_name = webroot_address + '\\' + image_name
    if not os.path.isfile(image_name):
        return 404, '', b'Image not found!\r\nTry again'
    try:
        with open(image_name, 'rb') as file_handle:
            image_bytes = file_handle.read()
            return 200, image_name, image_bytes
    except Exception as err:
        return 500, '', b'Server unexpected error occurred!\r\nTry again'


# Returns if need to send new resource
# True = send new resource
# False = use resource in cache
def check_cache(if_modified_since, if_none_match, path):
    print(f'checking cache. path:{path}, modified last:{if_modified_since}, ETag:{if_none_match}')
    if os.path.isfile(path):
        #           time.ctime(os.path.getmtime(path))
        file_date = time.ctime(os.path.getmtime(path))
        print('file date: ' + file_date)
        if file_date == if_modified_since and file_date != 'None':
            with open(path, 'rb') as file_handle:
                file_bytes = file_handle.read()
                print(f'bytes as hex:{hashlib.md5(file_bytes).hexdigest()}')
            if hashlib.md5(file_bytes).hexdigest() == if_none_match:
                print('match!')
                return False
    print('no match!')
    return True


# Handle single client
def handle_client(sck, addr):
    status_number = -1
    path = ''
    http_response = b''
    print(f'New client: {addr}')
    try:
        # Receive dictionary by request
        dc = http_recv(sck)
        print(f'DC={dc}')

        if dc['status'] == 'success':
            page = ''
            if dc['method'] == 'GET':
                # Send resource
                if dc['status'] == 'success':
                    func = dc['url']
                    if func == r'\calculate-next':                  # 4.5-4.6
                        page = str(float(dc['parameters']['num'])+1)  # Return next number
                        status_number = 200
                    elif func == r'\calculate-area':                # 4.9
                        height = float(dc['parameters']['height'])
                        width = float(dc['parameters']['width'])
                        page = str(height * width / 2)
                        status_number = 200
                    elif func == r'\image':                          # 4.11
                        image_name = dc['parameters']['image-name']
                        status_number, path, page = get_image(image_name)
                    else:
                        path, status_number = url_to_path(dc['url'])  # Search resource in pc, return status number and path
                        with open(path, 'rb') as my_file:
                            page = my_file.read()
                        if status_number == 302:                      # If moved temporarily
                            page = path.encode()
            elif dc['method'] == 'POST':                           # 4.10
                path_to_file = dc['url'] + '\\' + dc['parameters']['file-name']
                picture_bytes = dc['body']
                status = save_picture(picture_bytes, path_to_file)
                if status:
                    status_number = 200
                else:
                    status_number = 500
            # If unknown method
            else:
                status_number = 500
                page = 'Unknown request!'
            # Build response
            if 'if-modified-since' in dc.keys() and 'if-none-match' in dc.keys():
                if check_cache(dc['if-modified-since'], dc['if-none-match'], path):  # Not modified (304 error)
                    http_response = build_http(page, status_number, path)
                else:
                    http_response = build_http(b'', 304, '')
            else:
                http_response = build_http(page, status_number, path)
            # Send response
            http_send(sck, http_response)
    except Exception:
        print(f'Error!\r\n{traceback.format_exc()}')
    # Close connection
    sck.close()
    print(f'Goodbye address: {addr}')


# Main loop - manage all clients
def main_loop():
    global server_ip
    global close_all_clients
    t_list = []
    main_sck = socket.socket()
    main_sck.bind((server_ip, 80))
    main_sck.listen(50)  # Max number of users capable of connecting at once
    while not close_all_clients:
        sck, addr = main_sck.accept()
        t = threading.Thread(handle_client(sck, addr))
        t_list.insert(0, t)
    for t in t_list:
        t.join()


def main():
    main_loop()


if __name__ == '__main__':
    main()
