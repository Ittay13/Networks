__author__ = 'Ittay_Levit'

import socket
import os


# Global variables
webroot_address = 'E:\\Networks\\FourFour\\webroot'    # Address of webroot directory (my pc)
server_ip = '127.0.0.1'                                # Server ip
client_ip = '127.0.0.1'                                # My ip
close_all_clients = False                              # IF need to close all clients (terminate program)
socket_recv_size = 64 * 1024                           # Number of bytes to read each time (size of chunk)
# Response code (key) and response message (value)
status_dictionary = {200: 'OK', 404: 'Not Found', 403: 'Forbidden',
                     302: 'Moved Temporarily', 500: 'Iternal Server Error'}
# List of paths of forbidden files
forbidden_files_path = ['\\forbiddentextfile.txt']
# Dictionary of paths of moved temporarily files
# Key = moved file path, Value = path of file to direct to (instead of moved file)
temporarily_moved_files_paths = {'\\iwasmoved.txt': '\\takemeinsteadofmoved.txt'}


# The function receives http requests
# Returns dictionary with key-value pairs according to http format
def http_recv(sck):
    global socket_recv_size
    global status_dictionary
    dc = {'version': '', 'status_code': 0, 'status_msg': ''}
    bt = b''
    two_lines = b'\r\n\r\n'
    one_line = '\r\n'
    # receive until end of header
    while two_lines not in bt:
        chunk = sck.recv(socket_recv_size)
        if len(chunk) == 0:  # If other side disconnected
            return dc
        bt += chunk
    # Now when the whole header was received
    bt = bt.split(b'\r\n\r\n', 1)
    header = bt[0]
    header = header.decode()
    header = header.split('\r\n')
    first_line = header[0].split(' ')
    dc['version'] = first_line[0].split('/')[1]
    dc['status_code'] = first_line[1]
    dc['status_msg'] = first_line[2]
    header = header[1:]
    for line in header:
        dc[line.split(' ', 1)[0].lower()] = line.split(' ', 1)[1]

    # Read end of body (if has so)
    body_size = 0
    body = bt[1]
    if 'content-length' in dc.keys():
        body_size = int(dc['content-length'])
    while len(body) < body_size:
        chunk = sck.recv(body_size - len(body))
        body += chunk
        if len(chunk) == 0:   # If other side disconnected
            return dc
    dc['body'] = body
    return dc


# Sends binary data 'http_response' with socket 'sck'
def http_send(sck, http_response):
    print(http_response)
    sck.send(http_response)            # Send response


# Builds http response with 'bdata' as its body
# Returns bytestream representing the response (=the encoded response)
def build_http(bdata, url, method, parameters=''):
    global status_dictionary
    size = len(bdata)
    http_response = f'{method} /{url}?{parameters} HTTP/1.1\r\n'                        # HTTP version 1.1
    http_response += f'Content-Length: {size}\r\n'                                      # Content-Length
    http_response += '\r\n'                                                             # *Separate header and body
    if type(bdata) is not bytes:  # Make sure bdata is bytes
        bdata = bdata.encode()
    http_response = http_response.encode() + bdata                                      # Body
    return http_response


# Handle single client
def talk_to_server(sck):
    path_to_pic = r'E:\Screenshot_2024-12-01_21-40-18.png'
    pic_bytes = b''
    with open(path_to_pic, 'rb') as my_file:
        pic_bytes = my_file.read()
    # Name to save file as
    print('enter name to save file as: ', end='')
    name_of_file = input()
    # Build response
    http_response = build_http(pic_bytes, 'uploads', 'POST', f'file-name={name_of_file}')
    # Send response
    http_send(sck, http_response)

    # Receive dictionary by request
    dc = http_recv(sck)

    print(dc)

    # Close connection
    sck.close()  # Temporary
    print(f'Disconnecting...\nGoodbye')


# Connect to server
def connect_loop():
    global server_ip
    sck = socket.socket()
    sck.connect((server_ip, 80))
    talk_to_server(sck)


def main():
    connect_loop()


if __name__ == '__main__':
    main()
