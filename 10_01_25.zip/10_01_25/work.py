__author__ = 'Ittay Levit'

import socket
import time
import threading
import struct


# global var
found_addr = False


# Returns socket connected to server and tuple of ip and port
# Returns like this:
# Socket, (ip, port)
def connect_to_server(extra_ip):
    global found_addr
    ip = '10.68.121.' + str(extra_ip)
    for port in range(62520, 62660):
        sck = socket.socket()
        # print(f'Address: {ip}:{port}')
        try:
            if True:
                # time.sleep(0.00000000000001)
                sck.settimeout(0.01)
                sck.connect((ip, port))
                print(f'Connected to address {ip}:{str(port)}')
                # found_addr = True
                return sck, (ip, port)
            else:
                return
        except Exception as err:
            pass
    print('ended with ip: ' + ip)
            # print(f'NO from address {ip}:{str(port)}')


def main():
    sck = socket.socket()
    sck.connect(('10.68.121.78', 62534))
    sck.send(b'NAME=Ittay')
    data = sck.recv(1024)
    print(data.decode())
    sck.send(b'help')
    data = sck.recv(1024)
    print(data.decode())
    sck.send(b'what do you want')
    data = sck.recv(1024)
    print(data.decode())
    sck.send(b'FF-FF-FF-FF-FF-FF')
    data = sck.recv(1024)
    tup = struct.unpack('L', data[:4])
    num = socket.ntohl(tup[0])
    print(num)
    '''
    print('Starting search...')
    for i in range(256):
        lst = [i]
        t = threading.Thread(target=connect_to_server, args=lst)
        t.start()
    '''


if __name__ == '__main__':
    main()
