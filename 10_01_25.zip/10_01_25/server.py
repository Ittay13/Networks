import socket


def main():
    server_sck = socket.socket()
    server_sck.bind(('10.68.121.86', 62531))
    print('connected server to address 10.68.121.86:62531')
    server_sck.listen(5)
    sck, addr = server_sck.accept()
    print(f'Address: {addr}')


if __name__ == '__main__':
    main()
