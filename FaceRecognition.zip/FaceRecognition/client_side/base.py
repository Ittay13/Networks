import cv2
import os
import face_recognition
import pickle
import threading
import sys


path = os.getcwd()
encoding_dictionary_path = path + '\\encoding_dict.txt'
name_encoding_face = {}  # Name (key), Encoding list (Value) dictionary


class Video:
	def __init__(self, width, height):
		# Open the default camera
		self.cam = cv2.VideoCapture(0)  # Default camera
		self.cam.set(cv2.CAP_PROP_FRAME_WIDTH, width)
		self.cam.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
		self.ret = True
		self.img_rgb = None
		self.frame_count = 1

	# Update ret, img_rgb
	def update_frame(self):
		if self.frame_count != 5:
			self.frame_count += 1
			return
		self.frame_count = 1
		self.ret, self.img_rgb = self.cam.read()  # Get frame


# Generates encoding for a specific name
# Appends it to the name-encoding dictionary
def generate_encodings(name):
	global name_encoding_face
	count = 1
	name_encoding_face[f'{name}'] = []
	for file in os.listdir(path+f'\\faces_db\\{name}'):
		image = face_recognition.load_image_file(file)
		encodings = face_recognition.face_encodings(image)
		if encodings:
			name_encoding_face[f'{name}'].append(encodings[0])  # add encoding
		count += 1


# Loads the encoding-dictionary from path
def pickle_load_encodings(pth):
	global name_encoding_face
	# Load pickle-dictionary
	with open(pth, 'rb') as file_handle:
		name_encoding_face = pickle.load(file_handle)


# Returns if the image consists the face of 'name'
# Receives image obj, face_locations (x, y, w, h), and name of person to recognize
def recognize_face(image, face_locations, name):
	global name_encoding_face
	matches = ''
	distances = ''
	face_encodings = face_recognition.face_encodings(image, face_locations)
	for (top, right, bottom, left), encoding in zip(face_locations, face_encodings):
		matches = face_recognition.compare_faces(name_encoding_face[name], encoding)
		distances = face_recognition.face_distance(name_encoding_face[name], encoding)
	if any(matches):
		best_match = distances.argmin()
		if matches[best_match]:
			print(f'recognized {name}')
			# Draw results
			color = (0, 255, 0)  # Green
			thickness = 2
			(top, right, bottom, left) = face_locations[0]
			cv2.rectangle(image, (left, top), (right, bottom), color, thickness)       # Green rectangle (2 thickness)
			cv2.putText(image, name, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX,  # Green text      (2 thickness)
						0.8, color, thickness)
			return True  # If recognized the face
	return False


# Loops infinitely to update camera
def loop_update_camera(video_obj):
	while video_obj.ret:
		video_obj.update_frame()


def main(dct):
	global path
	global name_encoding_face
	name_encoding_face = dct
	# Get the default frame width and height
	frame_width = 800
	frame_height = 800
	video_obj = Video(frame_width, frame_height)
	t = threading.Thread(target=loop_update_camera, args=(video_obj,))
	t.start()

	cont_bool = True
	while video_obj.img_rgb is None:  # Wait until the first frame is taken
		pass
	while cont_bool:
		if not video_obj.ret:
			break
		img = video_obj.img_rgb
		img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)  # Grayscale of picture
		faces_rectangles = face_recognition.face_locations(img_gray)
		color = (0, 0, 255)  # BGR
		thickness = 2
		for (top, right, bottom, left) in faces_rectangles:  # Each face_rectangle is a tuple of (x, y, width, height)
			recognized = False
			for name in name_encoding_face:
				recognized = recognize_face(img, [(top, right, bottom, left)], name)
				if recognized:
					break
			if not recognized:  # If recognized already drew a green rectangle around the face
				# Draw a red rectangle around the face
				cv2.rectangle(img, (left, top), (right, bottom), color, thickness)    # Red rectangle (2 thickness)
				cv2.putText(img, 'Unknown', (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX,
							0.8, color, thickness)                               # Red text (2 thickness)
		resized_image = cv2.resize(img, (frame_width, frame_height))
		cv2.imshow('Camera', resized_image)

		# Press 'esc' to exit the loop
		if cv2.waitKey(1) == 0x1B:
			break

	# Release the capture and writer objects
	video_obj.cam.release()
	t.join()
	cv2.destroyAllWindows()


if __name__ == '__main__':
	main()
