import socket
import pickle
import send_recv_msg
import base

ip = '46.117.123.164'
port = 3742
name_encoding_face = {}  # Name (key), Encoding list (Value) dictionary - BYTES DICTIONARY


def load_dict(pickle_dict_bytes):
	global name_encoding_face
	name_encoding_face = pickle.loads(pickle_dict_bytes)


def main():
	sck = socket.socket()
	sck.connect((ip, port))
	pickle_dict_bytes = send_recv_msg.recv_msg(sck)
	sck.close()
	if pickle_dict_bytes is None or len(pickle_dict_bytes) == 0:
		print('Error contacting server, closing down')
		exit()
	load_dict(pickle_dict_bytes)
	base.main(name_encoding_face)


if __name__ == '__main__':
	main()
