import socket
import threading
import os
import pickle
import face_recognition

import send_recv_msg

thread_list = []
ip = '10.100.102.3'
port = 3742
max_listen = 5
stop_server = False
path = os.getcwd()
encoding_dictionary_path = path + '\\encoding_dict.txt'
name_encoding_face = {}  # Name (key), Encoding list (Value) dictionary - BYTES DICTIONARY
name_encoding_face_bytes = b''  # Bytes of [name_encoding_face]

# Loads the encoding-dictionary from path
def pickle_load_encodings(pth):
	global name_encoding_face
	global name_encoding_face_bytes
	# Load pickle-dictionary
	with open(pth, 'rb') as file_handle:
		name_encoding_face = pickle.load(file_handle)
	name_encoding_face_bytes = pickle.dumps(name_encoding_face)



# Creates and saves the encoding-dictionary to a pickle txt file in path
def pickle_save_encodings(pth):
	global path
	global name_encoding_face
	# Generate encodings
	for name in os.listdir(path+'\\faces_db'):
		generate_encodings(name)
	# Save pickle-dictionary
	with open(pth, 'wb') as file_handle:
		pickle.dump(name_encoding_face, file_handle)


# Generates encoding for a specific name
# Appends it to the name-encoding dictionary
def generate_encodings(name):
	global name_encoding_face
	count = 1
	name_encoding_face[f'{name}'] = []
	for file in os.listdir(path+f'\\faces_db\\{name}'):
		image = face_recognition.load_image_file(path+f'\\faces_db\\{name}\\'+file)
		encodings = face_recognition.face_encodings(image)
		if encodings:
			name_encoding_face[f'{name}'].append(encodings[0])  # add encoding
		count += 1


def handle_client(sck):
	send_recv_msg.send_msg(name_encoding_face_bytes, sck)
	sck.close()


def main():
	pickle_load_encodings(encoding_dictionary_path)
	server_sck = socket.socket()
	server_sck.bind((ip, port))
	server_sck.listen(max_listen)
	print('server on')
	while not stop_server:
		sck, addr = server_sck.accept()
		t = threading.Thread(target=handle_client, args=(sck,))
		thread_list.append(t)
		t.start()
	for t in thread_list:
		t.join()
	server_sck.close()


if __name__ == '__main__':
	pickle_load_encodings(encoding_dictionary_path)
	main()
