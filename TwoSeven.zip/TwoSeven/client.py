__author__ = 'Ittay_Levit'
# 2.7 November 2024
if __name__ == '__main__':
    from tcp_by_size import recv_by_size, send_with_size
import socket
import sys
import traceback
import os
# import datetime  # For log_client


# Global Variables
log_file_name = 'ClientLog.txt'


# Writes to log file the log [time, direction, and message]
'''def log_client(direction, data):
    #  Direction - Sent or Received, Byte_Data - data as string
    global log_file_name
    info = ''
    if direction == 'sent':
        info = f'\nTime: {datetime.datetime.now()} Sent     >>> {data}'
    elif direction == 'received':
        info = f'\nTime: {datetime.datetime.now()} Received <<< {data}'
    elif direction == 'error':
        info = f'\nTime: {datetime.datetime.now()} Error!   {data}'
    else:
        info = f'\nTime: {datetime.datetime.now()} {data}'
    with open(log_file_name, 'a') as file_handle:
        file_handle.write(info)'''


# Menu of available functions, shown to user. returns list with fields.
def user_interface():
    cont = True
    num = 0
    fields = [''] * 3
    while cont:
        print('\n  1. Take a screenshot and save on server\'s computer')
        print('\n  2. Get file from server')
        print('\n  3. Show directory of server')
        print('\n  4. Delete a server\'s file')
        print('\n  5. Copy file on server\'s computer')
        print('\n  6. Run program on server\'s computer')
        print('\n  7. DISCONNECT')
        num = input('Input 1 - 7 > ')
        try:
            if ord(num) < 49 or ord(num) > 55:
                print('Selection error, please try again.')
            else:
                num = int(num)
                cont = False
        except Exception as err:
            print('Selection error, please try again.')
    if num == 1:
        fields[0] = 'SCRP'
        print('Enter path of directory to save screenshot at.')
        fields[1] = input('The path may contain the name of the screenshot\'s file: ')
    elif num == 2:
        fields[0] = 'SNDF'
        fields[1] = input('Enter path of file to send: ')
        while True:
            fields[2] = input('Enter name to save file as: ')
            name, nothing = separate_name_and_path(fields[2])
            if not is_name_maybe_with_extension_legal(fields[2]):
                print('Illegal file name!')
            elif is_name_in_directory(name, os.getcwd()):
                print('File with the requested name already exists in directory.')
            else:
                break
    elif num == 3:
        fields[0] = 'SHWD'
        fields[1] = input('Enter path of directory to show: ')
    elif num == 4:
        fields[0] = 'DELF'
        fields[1] = input('Enter path of file to remove: ')
    elif num == 5:
        fields[0] = 'CPYF'
        fields[1] = input('Enter path of file to copy: ')
        print('Enter path of directory to copy file to.')
        fields[2] = input('The path may contain the name of the new file: ')
    elif num == 6:
        fields[0] = 'RPRG'
        fields[1] = input('Enter name or full path of program to run: ')
    elif num == 7:
        fields[0] = 'DSCN'
    return fields


# Build reply to send according to protocol. Takes fields as argument.
def protocol_build_request(fields):
    count = 0
    for field in fields:
        if field != '':
            count += 1
    fields = fields[0:count]
    return '?'.join(fields)


# Returns TRUE if file with path exists, FALSE if otherwise
def does_file_exists(path):
    return os.path.isfile(path)


# Returns TRUE if name can be used as a file/directory name, otherwise returns FALSE
def is_name_legal(name):
    # Illegal characters:
    # \ / : * ? " < > |
    if '\\' in name or '/' in name or ':' in name or '*' in name or '?' in name \
            or '"' in name or '<' in name or '>' in name or '|' in name:
        return False
    return True


# Takes a name as an argument - it may have the extension of the file.
# Returns TRUE if name can be used as a file/directory name, otherwise returns FALSE
def is_name_maybe_with_extension_legal(name):
    name = name.split('.')
    if len(name) > 2:                    # If name has more than single dot (not only for extension)
        return False
    for part_name in name:                # If name is single name or with extension
        if not is_name_legal(part_name):
            return False
    return True


# Returns a tuple with the name and the path seperated (name, path)
def separate_name_and_path(path):
    fields = path.split('\\')
    path = ''
    name = ''
    try:
        path = '\\'.join(fields[:len(fields)-1])
        name = fields[len(fields)-1]
    except Exception as err:
        pass
    return name, path


# Returns TRUE if file name (not necessarily with extension) exists in directory
def is_name_in_directory(name, path):
    for f in os.listdir(path):
        f = f.split('.')[len(f.split('.'))-2]
        if f == name:
            return True
    return False


# Save file sent by server to client's computer
def save_file_to_computer(sock, fields):
    global log_file_name
    if len(fields[2].split('.')) == 1:                     # If new filename doesn't have extension
        name, nothing = separate_name_and_path(fields[1])  # Add extension to name
        extension = ''
        for i in name[::-1]:                               # Extract extension from server's file
            if i != '.':
                extension += i
            else:
                break
        extension = extension[::-1]
        fields[2] += '.' + extension
    with open(fields[2], 'wb') as my_file:
        while True:
            chunk = recv_by_size(sock, 'client', log_file_name)
            size_of_chunk = int((chunk[:8]).decode())
            chunk = chunk[9:]
            my_file.write(chunk)
            if size_of_chunk < 64 * 1024:             # If current chunk smaller than 64k
                break                                 # Stop reading bytes
    return recv_by_size(sock, 'client', log_file_name)


# Parse the directory sent by server
def receive_and_return_directory(sock):
    directory = b''
    while True:
        chunk = recv_by_size(sock, 'client', log_file_name)
        size_of_chunk = chunk[:8]
        size_of_chunk = int(size_of_chunk.decode())
        chunk = chunk[9:]
        directory += chunk
        if size_of_chunk < 64 * 1024:  # If current chunk smaller than 64k
            break  # Stop reading bytes
    directory = directory.decode(errors='ignore')
    directory = directory.split('|')
    directory = '\n' + '\n'.join(directory)
    msg = recv_by_size(sock, 'client', log_file_name)
    if msg[9:] != b'DONE':
        return msg
    return directory  # Return parsed list


# Parse answer from server. Returns the answer from server as string
def protocol_parse_reply(reply, fields, sock):
    to_show = 'Invalid reply from server'
    try:
        code = reply[0]
        if code == 'FILR':
            to_show = save_file_to_computer(sock, fields)
            if to_show[9:] == b'DONE':
                to_show = 'File was sent successfully!'
        elif code == 'DIRR':
            to_show = receive_and_return_directory(sock)
        elif code == 'DONE':
            to_show = 'Request was done successfully!'
        elif code == 'EROR':
            to_show = 'Server returned an error!\nError code:  ' + reply[1] + "\nExplanation: " + reply[2]
    except Exception as err:
        to_show = 'Server reply bad format'
    return to_show


# Handle reply from server. Returns if to stay connected
def handle_reply(reply, sock, fields):
    reply = reply.decode()
    reply = reply[9:]
    reply = reply.split('?')
    if fields[0] == 'DSCN':
        if reply[0] == 'DONE':  # If server accepted disconnection - return to stop connection.
            print('Will exit...')
            return False

    to_show = protocol_parse_reply(reply, fields, sock)
    if to_show != '':
        print('\n==========================================================')
        print(f' SERVER Reply: {to_show}', end='')
        print('\n==========================================================')
    return True  # Stay connected


# Main loop
def main(ip):
    connected = False
    sock = socket.socket()
    port = 1307
    global log_file_name
    with open(log_file_name, 'w') as file_handle:
        file_handle.write('')
    try:
        sock.connect((ip, port))
        print(f'Connect succeeded {ip}:{port}')
        connected = True
    except Exception as err:
        print(f'Error while trying to connect. Check ip or port -- {ip}:{port}')

    while connected:
        fields = user_interface()
        to_send = protocol_build_request(fields)
        if to_send == '':
            print("Selection error try again")
            continue
        try:
            send_with_size(sock, -1, to_send.encode(), 'client', log_file_name)
            byte_data = recv_by_size(sock, 'client', log_file_name)
            if byte_data == b'':
                print('Seems server disconnected. Disconnecting...')
                break

            # Handle answer from server
            connected = handle_reply(byte_data, sock, fields)

        except socket.error as err:
            print(f'Got socket error: {err}')
            break
        except Exception as err:
            print(f'General error: {err}')
            print(traceback.format_exc())
            break
    print('Shutting client down, bye')
    sock.close()


if __name__ == '__main__':
    if len(sys.argv) > 1:
        main(sys.argv[1])
    else:
        main('127.0.0.1')
