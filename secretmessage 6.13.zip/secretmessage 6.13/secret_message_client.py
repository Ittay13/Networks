__author__ = 'Ittay_Levit'
from scapy.all import *

server_ip = '10.100.102.22'


def main():
	print('Enter message to send: ',end='')
	msg = input()
	for i in msg:
		packet = IP(dst=server_ip)/UDP(dport=ord(i))
		send(packet)


main()
