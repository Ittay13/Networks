__author__ = 'Ittay_Levit'
from scapy.all import *


#  Returns TRUE if packet's dport is between ord(A) to ord (z) *INCLUDING]
def A_to_z_ASCII_filter(packet):
	return UDP in packet and (ord('A') <= packet[UDP].dport <= ord('z')) and Raw not in packet


def main():
	while True:
		packet = sniff(count=1, lfilter=A_to_z_ASCII_filter)
		packet = packet[0]
		print(chr(int(packet[UDP].dport)),end='')


main()
