__author__ = 'Ittay_Levit'
# 2.7 December 2024
if __name__ == '__main__':
	from tcp_by_size import recv_by_size, send_with_size
import socket
import datetime
import time
import traceback
import os
import pyautogui   # Screenshots [SCRP]
import shutil      # Copy file   [CPYF]
import subprocess  # Run program [RPRG]
import select      # SELECT


# Global Variables
all_clients_to_disconnect = False     # All clients need to disconnect
max_users_of_program = 100            # Maximum number of users at once
max_connections_at_once = 10          # Maximum number of users trying to connect at once
server_ip = '0.0.0.0'                 # Server's ip
server_port = 1307                    # Server's port
error_list = [b''] * 11
error_list[1] = b'EROR?01?File exists in directory'
error_list[2] = b'EROR?02?File does not exists'
error_list[3] = b'EROR?03?Directory does not exists'
error_list[4] = b'EROR?04?File cannot be deleted'
error_list[5] = b'EROR?05?Program doesn\'t exist or can\'t run'
error_list[6] = b'EROR?06?Incorrect message format'
error_list[7] = b'EROR?07?Illegal file/directory path'
error_list[8] = b'EROR?08?Code not supported'
error_list[9] = b'EROR?09?No permission to delete the requested file'
error_list[10] = b'EROR?10?General error'
log_file_name = 'ServerLog.txt'
'''SELECT vars'''
read_socket_list = []
write_socket_dict = {}  # Key = sock, Value = bytes to send with sock
error_socket_list = []


# Writes to log file the log [time, direction, thread and message]
def log_server(direction, tid, data):
	#  Direction - Sent \ Received, TID, Byte_Data - data as string
	global log_file_name
	info = ''
	if direction == 'error':
		info = f'\nTime: {datetime.datetime.now()} TID: {tid}: Error!   {data}'
	elif direction == 'program':
		info = f'\nTime: {datetime.datetime.now()} [PROGRAM]: {data}'
	else:
		info = f'\nTime: {datetime.datetime.now()} TID: {tid}: {data}'
	with open(log_file_name, 'a') as file_handle:
		file_handle.write(info)


# Returns if length of message is correct
def check_length(message):
	global error_list
	# return: string - error message. nothing - no error
	message = message.decode()
	size = len(message)
	if size < 13:  # 13 is min message size [00000004?DSCN]
		return error_list[6]
	if int(message[:8]) != size - 9:
		return error_list[6]
	return b''


# Returns a tuple with the name and the path seperated (name, path)
def separate_name_and_path(path):
	fields = path.split('\\')
	path = ''
	name = ''
	try:
		path = '\\'.join(fields[:len(fields)-1])
		name = fields[len(fields)-1]
	except Exception as err:
		pass
	return name, path


# Returns TRUE if directory with path exists, FALSE if otherwise
def does_directory_exists(path):
	return os.path.isdir(path)


# Returns TRUE if file with path exists, FALSE if otherwise
def does_file_exists(path):
	return os.path.isfile(path)


# Returns existence state about directory and file, Checks full and relative. Returns (directory, file, full)
def check_path_name_existence(path):
	directory_exists = 0                     # Only seperated path exists
	file_exists = 0                          # Only seperated name
	full_directory_exists = 0                # not seperated path
	name, path = separate_name_and_path(path)
	if does_directory_exists(path):
		directory_exists = 1
	if does_file_exists(path+'\\'+name):
		file_exists = 1
	if does_directory_exists(path+'\\'+name):
		full_directory_exists = 1
	return directory_exists, file_exists, full_directory_exists


# Given the client's request, returning the errors that are to be with files and directories
def return_error_by_requests(path, request_name):
	global error_list
	if request_name == 'SCRP':
		directory_exists, file_exists, full_directory_exists = check_path_name_existence(path)
		if not directory_exists and not full_directory_exists:
			return error_list[3]
		if file_exists or does_file_exists(path+'.png'):
			return error_list[1]
		return b''
	if request_name == 'SNDF' or request_name == 'DELF' or request_name == 'CPYF' or request_name == 'RPRG':
		directory_exists, file_exists, full_directory_exists = check_path_name_existence(path)
		if not directory_exists and not full_directory_exists:
			return error_list[3]
		if not file_exists:
			return error_list[2]
		return b''
	if request_name == 'SHWD':
		directory_exists, file_exists, full_directory_exists = check_path_name_existence(path)
		if not full_directory_exists:
			return error_list[3]
		return b''


#  Save screenshot in server's pc
def save_screenshot(path):
	global error_list
	error = return_error_by_requests(path, 'SCRP')
	if error != b'':
		return error
	try:
		if does_directory_exists(path):                                       # If path not contains name
			dt = (str(datetime.datetime.now()).replace(':', '-'))
			dt = dt.replace(' ', '_')
			dt = dt[:len(dt)-7]                                                 # Date
			path = path + f'\\Screenshot_{dt}.png'                              # Add name to path
		else:                                                                 # If path contains name
			pass                                                                # Don't change path
		img = pyautogui.screenshot(path)
		return b''
	except Exception as err:
		if not does_file_exists(path):                                        # If file still not exists
			try:
				pyautogui.screenshot(path+'.png')                               # Add extension to path
				if not does_file_exists(path + '.png'):  # If file STILL not exists
					return error_list[10]
				return b''
			except OSError as err:
				if err.errno == 22:                      # If illegal file path
					return error_list[7]
				return error_list[10]                                        # Return error
		return error_list[10]


#  Send file to client - function calls send_with_size - sends independently
def get_file(path, sock, tid):
	global error_list
	global log_file_name
	error = return_error_by_requests(path, 'SNDF')
	if error != b'':
		return error
	try:
		with open(path, 'rb') as file_handle:
			# Send message that indicates that file is going to be sent
			send_with_size(sock, tid, B'FILR', 'server', log_file_name)
			while True:
				chunk = file_handle.read(64 * 1024)  # Send 64k bytes
				send_with_size(sock, tid, chunk, 'server', log_file_name)
				if len(chunk) < 64 * 1024:
					break
		return b''
	except OSError as err:
		if err.errno == 22:        # If illegal file path
			return error_list[7]
	except Exception as err:
		return error_list[10]


# Send bytes that represents directory's files
def get_directory(path, sock, tid):
	global error_list
	error = return_error_by_requests(path, 'SHWD')
	if error != b'':
		return error
	try:
		flist = os.listdir(path)
		string_files = '|'.join(flist)
		# Send message that indicates that file is going to be sent
		send_with_size(sock, tid, b'DIRR', 'server', log_file_name)

		while True:
			send_with_size(sock, tid, string_files[:64 * 1024].encode(errors='ignore'),  'server', log_file_name)
			if len(string_files[:64 * 1024]) < 64 * 1024:       # If current send was last send
				break
			string_files = string_files[64 * 1024:]
		return b''
	except Exception as err:
		return error_list[10]


#  Delete file in server's pc
def delete_file(path):
	global error_list
	error = return_error_by_requests(path, 'DELF')
	if error != b'':
		path = os.getcwd() + '\\' + path
		error2 = return_error_by_requests(path, 'DELF')
		if error2 != b'':
			if error == error_list[2]:
				return error
			else:
				return error2
	try:
		os.remove(path)
		return b''
	except PermissionError as error:
		return error_list[9]
	except Exception as error:
		return error_list[10]


def copy_file(fields):
	global error_list
	copy_from = fields[0]
	copy_to = fields[1]
	name = ''
	error = return_error_by_requests(copy_from, 'CPYF')
	if error != b'':
		return error
	error = return_error_by_requests(copy_to, 'CPYF')
	if error == error_list[3]:
		return error
	if does_directory_exists(copy_to):  # If copy_to path doesn't have name
		pre_name, nothing = separate_name_and_path(copy_from)
		copy_to += '\\CopyOf-' + pre_name
	if does_file_exists(copy_to):       # If file with requested name already exists
		return error_list[1]
	new_name, nothing = separate_name_and_path(copy_to)
	if len(new_name.split('.')) == 1:   # If name doesn't consist file extension
		extension = ''
		old_name, nothing = separate_name_and_path(copy_from)
		for i in old_name[::-1]:        # Extract extension from copied file
			if i != '.':
				extension += i
			else:
				break
		extension = extension[::-1]
		new_name += '.' + extension    # Add extension to copy to file
	if separate_name_and_path(copy_to)[0] != new_name:
		nothing, path = separate_name_and_path(copy_to)
		copy_to = path + '\\' + new_name
	try:
		shutil.copy(copy_from, copy_to)
		return b''
	except Exception as error:
		return error_list[10]


def run_program(path):
	global error_list
	try:
		subprocess.call(path)
		return b''
	except Exception as err:
		if does_file_exists(path):
			return error_list[5]    # If program exists as path
		error = return_error_by_requests(path, 'RPRG')
		if error == error_list[2]:  # If program was called by path and directory exists
			return error
		return error_list[5]        # If program was not called by path or wrong directory


# Build reply to return according to protocol - RUNS THE SUB FUNCTIONS AS REQUESTED (run program, delete file...)
def build_reply(request, sock, tid):
	global error_list
	# Returns a string
	request = request.decode()[9:]
	request_code = request[:4]
	fields = request.split('?')  # list of fields
	if request_code == 'SCRP':
		reply = save_screenshot(fields[1])
		if reply == b'':
			reply = b'DONE'
	elif request_code == 'SNDF':
		reply = get_file(fields[1], sock, tid)
		if reply == b'':
			reply = b'DONE'
	elif request_code == 'SHWD':
		reply = get_directory(fields[1], sock, tid)
		if reply == b'':
			reply = b'DONE'
	elif request_code == 'DELF':
		reply = delete_file(fields[1])
		if reply == b'':
			reply = b'DONE'
	elif request_code == 'CPYF':
		reply = copy_file(fields[1:])
		if reply == b'':
			reply = b'DONE'
	elif request_code == 'RPRG':
		reply = run_program(fields[1])
		if reply == b'':
			reply = b'DONE'
	elif request_code == 'DSCN':
		reply = b'DONE'
	else:
		reply = error_list[8]
	return reply


# Handle client's request. RETURN: tuple (message to send, bool: close client socket)
def handle_request(request, sock, tid):
	global error_list
	try:
		request_code = request[:4]
		to_send = build_reply(request, sock, tid)
		if request_code == b'DSCN':
			return to_send, True
	except Exception as err:
		log_server('error', tid, traceback.format_exc())
		to_send = error_list[10]
	return to_send, False


# Handle client - main client's thread loop
def handle_client(sock, addr):
	global all_clients_to_disconnect
	global log_file_name
	global write_socket_dict

	cont = True
	finish = False
	log_server('program', -1, f'New Client {addr}')
	while not finish:
		if all_clients_to_disconnect:
			send_with_size(sock, tid, 'Server going down for maintenance',  'server', log_file_name)
			break
		try:

			byte_data = recv_by_size(sock, 'server', log_file_name)
			if byte_data == b'':                             # If received data
				log_server('program', -1, f'Seems client disconnected')
				break
			err_size = check_length(byte_data)
			if err_size != b'':                                             # If incorrect data size
				to_send = err_size                                          # send back error
			to_send, finish = handle_request(byte_data, sock, tid)      # Handle request
			req = byte_data[9:13]
			if to_send != '' and req != 'SNDF' and req != 'SHWD':           # SNDF, SHWD sends response independently
				send_with_size(sock, to_send,  'server', log_file_name)
			if finish:                                                      # If user asked to disconnect
				cont = False
				time.sleep(1)
				break
		except socket.error as err:
			log_server('error', f'Socket Error exit client loop: err:  {err}')
			break
		except Exception as err:
			log_server('error', f'General Error %s exit client loop: {err}. {traceback.format_exc()}')
			break
		if not cont:
			break
	log_server('program', -1, f'Client exited.')
	sock.close()


# Main server's loop
def main():
	global all_clients_to_disconnect
	global max_users_of_program
	global server_ip
	global server_port

	global read_socket_list
	global write_socket_dict
	global error_list
	with open(log_file_name, 'w') as file_handle:
		file_handle.write('')
	threads_list = []
	srv_sock = socket.socket()
	srv_sock.bind((server_ip, server_port))

	rlist, wlist, elist = select.select(read_socket_list, write_socket_dict.keys(), error_list)
	for r_sck in rlist:
		if r_sck is srv_sock:
			sck, address = r_sck.accept()
		else:
			pass

	for w_sck in wlist:
		w_sck.send(write_socket_dict[w_sck])
		write_socket_dict.pop(w_sck)
	# pass elist...

	srv_sock.listen(max_connections_at_once)

#   next line release the port
	srv_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
	log_server('program', -1, 'Server up, waiting for connections')
	tid = 1
	while True:
		if tid-1 < max_users_of_program:  # If number of connected users less than maximum number of users allowed
			cli_sock, addr = srv_sock.accept()
			t = threading.Thread(target=handle_client, args=(cli_sock, str(tid), addr))
			t.start()
			tid += 1
			threads_list.append(t)
		else:  # If number of connected users more than maximum users allowed
			log_server('program', -1, 'Closing server, more than maximum users connected')
			break

	all_clients_to_disconnect = True
	log_server('program', -1, 'Waiting to all clients to die')
	for t in threads_list:
		t.join()
	srv_sock.close()
	log_server('program', -1, 'Server going down')


if __name__ == '__main__':
	main()
