import socket

sock = socket.socket()

ip = '127.0.0.1'  # Server ip
port = 1023       # Server port number

ip = input("Enter server IP number: ")
port = int(input("Enter server port number: "))

sock.connect((ip, port))

data = input('Write data to send:\n')
while data != 'q':  # If pressed q exit
    sock.send(data.encode())
    print('Sent >>>> ' + data)

    data = sock.recv(1024)  # Number of bytes to receive
    if data == b'':  # If server disconnected
        print("Server Disconnected")
        break
    print("Received <<<< " + data.decode())
    data = input('Write data to send:\n')
sock.close()
