import socket

srv_socket = socket.socket()

ip = '0.0.0.0'  # local ip
port = 1307     # 0 means get random port
srv_socket.bind((ip, port))

srv_socket.listen(5)  # Number of connections that can wait before being accepted

while True:
    (new_socket, address) = srv_socket.accept()

    while True:
        data = new_socket.recv(1024)  # Number of bytes to receive
        if data == b'':  # If client disconnected
            print("Client Disconnected")
            break

        print('Received <<< ' + data.decode())
        data_to_send = data.decode().upper()

        new_socket.send(data_to_send.encode())
        print('Sent >>>> ' + data_to_send)
    new_socket.close()
