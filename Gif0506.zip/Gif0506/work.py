from PIL import Image, ImageGrab
import time
import pyautogui





def main():
    screenshots_list = []
    count = 0
    time.sleep(2)  # 5 seconds of sleep
    for i in range(200):
        temp_screenshot = ImageGrab.grab()
        time.sleep(0.35)
        screenshots_list.append(temp_screenshot)
        og_final_screenshot = Image.new('RGBA', (1022,1027), (255,255,255,255))
        final_screenshot = og_final_screenshot.load()
    print('starting second stage')
    for screenshot in screenshots_list:
        scrn_data = screenshot.load()
        for x in range(451, 1473):
            for y in range(25, 1052):
                if 700 > sum(scrn_data[x, y]):
                    final_screenshot[x-451, y-25] = scrn_data[x, y]
    og_final_screenshot.show()


if __name__ == '__main__':
    main()
